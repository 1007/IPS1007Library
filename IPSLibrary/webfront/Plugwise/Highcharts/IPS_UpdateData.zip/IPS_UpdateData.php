<?php
    IPSUtils_Include ("Plugwise_Configuration.inc.php","IPSLibrary::config::hardware::Plugwise");
    
    if(!isset($_GET['Request'])) return false;
    
    $request = $_GET['Request'] ;
    
    IPS_logMessage("....",$request);
    
    $iScriptId = isset($_GET['scriptId']) ? (int)$_GET['scriptId'] : false; 

    if(!isset($_GET['lastTimeStamp'])) 
      {
      $startTime = time() - 60 * 60 * 2;
      } 
    else 
      {
      $startTime = (int) $_GET['lastTimeStamp'];
      }
    $endTime = time();


  if ( $request == "HC" )
    {        
    // ScriptId wurde �bergeben -> aktuelle Daten werden geholt
    if ($iScriptId != false) 
      {
        // Id des Config Scripts
        $ConfigScript = IPS_GetScript($iScriptId);
        include_once(IPS_GetKernelDir() . "scripts\\" .$ConfigScript['ScriptFile']);
        global $instances;
        
        $data = getLoggedData($CfgDaten['series'], $instances[0], $startTime, $endTime);
        
        header("Content-type: text/json");
        echo json_encode($data);
      }
    }

  if ( $request == "DATA1DATA2" )
    {
    
    echo time();
    }

    
function getLoggedData($Series, $id_AH, $startTime, $endTime) 
  {
  $ret = array();
  
  foreach ($Series as $Serie) {
            $logEntries = @AC_GetLoggedValues($id_AH, $Serie['Id'], $startTime, $endTime, 0 );
            foreach($logEntries as $logEntry) {
                $ret[] = array(CreateDateUTC($logEntry['TimeStamp']), $logEntry['Value']);
            }
        }
        return $ret;
    }
    
?>