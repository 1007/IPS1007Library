<?

	// Muss beim Neustart des Roomba einmal ausgefuehrt werden
 	command(START,0);


?>