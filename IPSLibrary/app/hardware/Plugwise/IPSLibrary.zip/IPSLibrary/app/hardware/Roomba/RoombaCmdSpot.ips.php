<?


	require_once("RoombaFuncpool.ips.php");

	go_spot();

?>