<?

 // Nachts keine Daten holen
$time = date("H:i");
if(($time > "23:00") || ($time < "04:00")) return;

// max Ausf�hrungszeit f�r Script in Sekunden
ini_set("max_execution_time", 75);
################################################################################

/*--------------------ab hier nichts mehr �ndern!-----------------------------*/

################################################################################
require_once IPS_GetKernelDir()."scripts\konfigurationWetter.ips.php";

$parentID = IPS_GetObject($IPS_SELF);
$parentID = $parentID['ParentID'];
$zaehlerID = @IPS_GetVariableIDByName("ftpFehlerzaehler", $parentID);
if(!IPS_VariableExists($zaehlerID))
{
   $zaehlerID = IPS_CreateVariable(1); // Variable Integer anlegen
    IPS_SetName($zaehlerID, "ftpFehlerzaehler"); // Der neu generierten ID einen Namen zuweisen
    IPS_SetParent($zaehlerID, $parentID); // nach Kategorie verschieben
}
$zaehler = GetValueInteger(IPS_GetVariableIDByName("ftpFehlerzaehler", $parentID));

if((!$kennung) || (!$region))
{
    echo " Es muss eine Kennung und Region ausgew�hlt sein!";
    return;
}

// Verbindungsaufbau
$conn_id = ftp_connect($ftp_server);
// Login mit Username und Passwort
$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
// Schalte passiven Modus ein
ftp_pasv($conn_id, true);

// Verbindung �berpr�fen
if ((!$conn_id) || (!$login_result))
{
    echo "FTP Verbindung ist fehlgeschlagen!\n";
    echo "Verbindungsaufbau zu $ftp_server mit Username $ftp_user_name versucht.";
     $zaehler = $zaehler+1;
     if($zaehler == 10)
     {
        SetValue($zaehlerID, 0);
        IPS_SetScriptTimer($IPS_SELF, 0);
        return;
    }
     IPS_SetScriptTimer($IPS_SELF, 60);
     SetValue($zaehlerID, $zaehler);
    return;
}
else
{
    echo "Verbunden zu $ftp_server mit Username $ftp_user_name"."\n";
    IPS_SetScriptTimer($IPS_SELF, 0);
    if($zaehler != 0) SetValue($zaehlerID, 0);
}

// Ins Verzeichnis wechseln
if (ftp_chdir($conn_id, "gds/specials/forecasts/text/"))
{
    echo "Aktuelles Verzeichnis: " . ftp_pwd($conn_id) ."\n";
}
else
{
    echo "Verzeichnis Wechsel ist fehlgeschlagen.\n";
}

// Inhaltsliste erstellen und Daten vergleichen
$ftp_nlist = ftp_nlist($conn_id, ".");
//print_r($ftp_nlist);

$tag = date("d");
$vergleich = array("VHDL50_DWEG_".$tag."0034","VHDL50_DWEG_".$tag."0234","VHDL50_DWEG_".$tag."0434","VHDL50_DWEG_".$tag."0534","VHDL50_DWEG_".$tag."0634",
                         "VHDL50_DWEG_".$tag."0734","VHDL50_DWEG_".$tag."0834","VHDL50_DWEG_".$tag."0934","VHDL50_DWEG_".$tag."1034","VHDL50_DWEG_".$tag."1134",
                         "VHDL50_DWEG_".$tag."1234","VHDL50_DWEG_".$tag."1334","VHDL50_DWEG_".$tag."1434","VHDL50_DWEG_".$tag."1534","VHDL50_DWEG_".$tag."1634",
                         "VHDL50_DWEG_".$tag."1734","VHDL50_DWEG_".$tag."1834","VHDL50_DWEG_".$tag."2034","VHDL50_DWEG_".$tag."2234");

$ergebnis = array_diff($vergleich, $ftp_nlist);
//print_r($ergebnis);
$textfile = array_diff($vergleich, $ergebnis);
//print_r($textfile);
$file = array_pop($textfile);
if($file == "")
{
    echo "Es liegen zur Zeit keine aktuelleren Berichte vor.\r\n";
}
else
{
    $time = substr($file, -6);
    //SetValue(34779, $time);
    if ($debug) echo "Letzte Aktualisierung: ".$time."\r\n";

    $tage = array("VHDL50_".$kennung,"VHDL51_".$kennung,"VHDL52_".$kennung,"VHDL53_".$kennung);
    // Dateien local
    $berichte = array("berichtHeute.txt", "berichtMorgen.txt", "berichtUebermorgen.txt", "berichtTag4.txt");

    for($i = 0; $i < count($tage); $i++)
    {
       $localFile = IPS_GetKernelDir()."webfront\user\WetterFtpDWD\berichte\\".$berichte[$i];
       $handleBerichte = fopen($localFile, 'wb+');
        if (ftp_fget($conn_id, $handleBerichte, $tage[$i].$time, FTP_ASCII))
        {
            echo $tage[$i].$time." wurde erfolgreich nach ".$localFile." geschrieben.\n";
        }
        else
        {
            echo "Download von ".$tage[$i].$time." zu ".$localFile." war nicht m�glich.\n";
        }
        $replaceBerichte = file_get_contents("../webfront/user/WetterFtpDWD/berichte/".$berichte[$i]);
        $umlaute = array("�","�","�","�","�","�","�");
        $replace = array("&auml;","&ouml;","&uuml;","&Auml;","&Ouml;","&Uuml;","&szlig;");
        $replaceBerichte = str_replace($umlaute, $replace, $replaceBerichte);
        $replaceBerichte = str_replace("Copyright (c) Deutscher Wetterdienst", "", $replaceBerichte);
        $replaceBerichte = preg_replace('/([\w]{4}[\d]{2}) ([\w]{4}) ([\d]{6})/', "", $replaceBerichte);
        //$replaceBerichte = preg_replace('/\b[A-Z]{1}+[a-z]{4,}\b.*([:].*)/', "", $replaceBerichte);
        $replaceBerichte = str_replace("<br></br>", "", $replaceBerichte);
        $replaceBerichte = str_replace("=", "", $replaceBerichte);
        $replaceBerichte = str_replace(chr(1), "", $replaceBerichte);
        $replaceBerichte = str_replace(chr(3), "", $replaceBerichte);
        // Datei zum �ndern �ffnen
        $handleBerichte = fopen($localFile, 'wb+');
        fwrite($handleBerichte, $replaceBerichte);
        //echo $replaceBerichte;
    }
    fclose($handleBerichte);
}
// in das dar�berliegende Verzeichnis wechseln, Karten downloaden
ftp_cdup($conn_id);
// Verzeichnis wechseln
ftp_chdir($conn_id, "maps/germany/");
echo "Aktuelles Verzeichnis: " . ftp_pwd($conn_id) ."\n";

$kartenImage = array($region."_morgen_frueh.jpg", $region."_morgen_spaet.jpg",
                            $region."_ueberm_frueh.jpg", $region."_ueberm_spaet.jpg",
                            $region."_tag4_frueh.jpg", $region."_tag4_spaet.jpg",
                            "Deutschland_morgen_spaet.jpg", "Deutschland_ueberm_spaet.jpg",
                            "Deutschland_tag4_spaet.jpg");
for($i = 0; $i < count($kartenImage); $i++)
{
   $karten = IPS_GetKernelDir()."webfront\user\WetterFtpDWD\karten\\".$kartenImage[$i];
    $handleKarten = @fopen($karten, 'wb+');
    if (ftp_fget($conn_id, $handleKarten, $kartenImage[$i], FTP_BINARY))
    {
        echo $kartenImage[$i]." wurde erfolgreich nach ".$karten." geschrieben.\n";
    }
    else
    {
        echo "Download von ".$kartenImage[$i]." zu ".$karten." war nicht m�glich.\n";
    }
}
fclose($handleKarten);

ftp_cdup($conn_id);
ftp_cdup($conn_id);
ftp_cdup($conn_id);
ftp_chdir($conn_id, "radar/");
echo "Aktuelles Verzeichnis: " . ftp_pwd($conn_id) ."\n";
$radarfilm = IPS_GetKernelDir()."webfront/user/WetterFtpDWD/radarfilm/Radarfilm_WEB_DL.gif";
$handleRadar = @fopen($radarfilm, 'wb+');
if (ftp_fget($conn_id, $handleRadar, "Radarfilm_WEB_DL.gif", FTP_BINARY))
{
    echo "Radarfilm_WEB_DL.gif wurde erfolgreich nach ".$radarfilm." geschrieben.\n";
}
else
{
    echo "Download von Radarfilm_WEB_DL.gif zu ".$radarfilm." war nicht m�glich.\n";
}
fclose($handleRadar);

ftp_cdup($conn_id);
ftp_chdir($conn_id, "observations/maps/germany/");
echo "Aktuelles Verzeichnis: " . ftp_pwd($conn_id) ."\n";
$mapList = ftp_nlist($conn_id, ".");
rsort($mapList);
$map = $mapList[0];
$mapact = substr($map, -18);
$act = array($region, "Deutschland");

for($i = 0; $i < count($act); $i++)
{
   $kartenact = IPS_GetKernelDir()."webfront\user\WetterFtpDWD\karten\\".$act[$i].".jpg";
    $handleMap = @fopen($kartenact, 'wb+');
    if (ftp_fget($conn_id, $handleMap, $act[$i].$mapact, FTP_BINARY))
    {
        echo $act[$i].$mapact." wurde erfolgreich nach ".$kartenact." geschrieben.\n";
    }
    else
    {
        echo "Download von ".$act[$i].$mapact." zu ".$kartenact." war nicht m�glich.\n";
    }
}
fclose($handleMap);

ftp_cdup($conn_id);
ftp_cdup($conn_id);
ftp_cdup($conn_id);
ftp_chdir($conn_id, "forecasts/biomet/maps/temp/");
echo "Aktuelles Verzeichnis: " . ftp_pwd($conn_id) ."\n";
$biometList = ftp_nlist($conn_id, ".");
$heute = date("d");
$temp = array_search('gt_brd36_'.$heute.'0740.gif', $biometList);
if($temp === false)
{
    echo "Es sind keine aktuelleren Daten vorhanden.\r\n";
}
else
{
    $temp = $biometList[$temp];
    $tempmap = substr($temp, 0, 8);
    $biometact = IPS_GetKernelDir()."webfront\user\WetterFtpDWD\warnungen\\".$tempmap.".gif";
    $handleBiomap = @fopen($biometact, 'wb+');
    if (ftp_fget($conn_id, $handleBiomap, $temp, FTP_BINARY))
    {
        echo $temp. " wurde erfolgreich nach ".$biometact." geschrieben.\n";
    }
    else
    {
        echo "Download von ".$temp." zu ".$biometact." war nicht m�glich.\n";
    }
    fclose($handleBiomap);
}
// FTP-Verbindung schliessen
ftp_close($conn_id);

WFC_Reload(40525);


?>