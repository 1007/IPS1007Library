<?
	Include "IPSLogger.ips.php";





function ipslog($typ,$script,$text)
	{

	if ( $typ == "INFO" )    { IPSLogger_Inf($script, $text); return; }
   if ( $typ == "ERROR" )   { IPSLogger_Err($script, $text); return; }
	if ( $typ == "FATAL" )   { IPSLogger_Fat($script, $text); return; }
	if ( $typ == "WARNING" ) { IPSLogger_Wrn($script, $text); return; }
	if ( $typ == "DEBUG" )   { IPSLogger_Dbg($script, $text); return; }
	if ( $typ == "COMMENT" ) { IPSLogger_Com($script, $text); return; }
	if ( $typ == "TEST" )    { IPSLogger_Tst($script, $text); return; }
	if ( $typ == "TRACE" )   { IPSLogger_Trc($script, $text); return; }

	$text = "Unknown Logtyp:". $typ . "-". $text ;
	IPSLogger_Wrn($script, $text);

	}

?>