<?

   $InstallScriptObjectArray        = IPS_GetObject($IPS_SELF);
	$InstallParentScriptObjectArray  = IPS_GetObject($InstallScriptObjectArray['ParentID']);

	// Add IPSLogger Category
	// ======================
	if ($InstallParentScriptObjectArray['ObjectName'] == "IPSLogger") {
		$ID_IPSLoggerCategory = $InstallScriptObjectArray['ParentID'];
	} else {
		$ID_IPSLoggerCategory = IPS_CreateCategory();
		IPS_SetName($ID_IPSLoggerCategory, "IPSLogger");
		IPS_SetParent($IPS_SELF, $ID_IPSLoggerCategory);
	}
	echo 'Category IPSLogger='.$ID_IPSLoggerCategory."\n";

	// Add IPSLogger Instance
	// ======================
	$ID_IPSLoggerInstance = @IPS_GetInstanceIDByName("IPSLogger", $ID_IPSLoggerCategory);
	if ($ID_IPSLoggerInstance === false) {
		$ID_IPSLoggerInstance	= IPS_CreateInstance("{485D0419-BE97-4548-AA9C-C083EB82E61E}");
		IPS_SetName($ID_IPSLoggerInstance, "IPSLogger");
		IPS_SetParent($ID_IPSLoggerInstance, $ID_IPSLoggerCategory);
	}
	echo 'Instance IPSLogger='.$ID_IPSLoggerInstance."\n";

	// Profile Installation
	// --------------------
	CreateProfiles();

	/* Used Structure
	IPSLogger [Category]
	   IPSLogger [Instance]
	      Variables ...
		Scripts [Scripts]...
		Webfront [Category]
			HtmlOutput [Link to HtmlOut Variable]
			Settings [Category]
			   Out Enabled ... [Link to "Enabled" Switches]
				Widget [Category]
					Settings... [Links to Output specific Settings]
				Webfront [Category]
					Settings... [Links to Output specific Settings]
				IPS [Category]
					Settings... [Links to Output specific Settings]
				File [Category]
					Settings... [Links to Output specific Settings]
				Log4IPS [Category]
					Settings... [Links to Output specific Settings]
				EMail [Category]
					Settings... [Links to Output specific Settings]
	*/


	// Add IPSLogger Scripts
	// =====================
   $ID_ScriptIPSLogger                = CreateScript('IPSLogger',                 'IPSLogger.ips.php',                 $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerConstants       = CreateScript('IPSLogger_Constants',       'IPSLogger_Constants.ips.php',       $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerClearSingleOut  = CreateScript('IPSLogger_ClearSingleOut',  'IPSLogger_ClearSingleOut.ips.php',  $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerClearHtmlOut    = CreateScript('IPSLogger_ClearHtmlOut',    'IPSLogger_ClearHtmlOut.ips.php',    $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerPurgeLogFiles   = CreateScript('IPSLogger_PurgeLogFiles',   'IPSLogger_PurgeLogFiles.ips.php',   $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerSendMail        = CreateScript('IPSLogger_SendMail',        'IPSLogger_SendMail.ips.php',        $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerPhpErrorHandler = CreateScript('IPSLogger_PhpErrorHandler', 'IPSLogger_PhpErrorHandler.ips.php', $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerOutput          = CreateScript('IPSLogger_Output',          'IPSLogger_Output.ips.php',          $ID_IPSLoggerCategory);
   $ID_ScriptIPSLoggerChangeSettings  = CreateScript('IPSLogger_ChangeSettings',  'IPSLogger_ChangeSettings.ips.php',  $ID_IPSLoggerCategory);

	CreateTimer ('IPSLogger_PurgeLogFilesTimer', $ID_ScriptIPSLoggerPurgeLogFiles, 8);

	// Add IPSLogger Variables
	// =====================
	$ID_SingleOutEnabled  = CreateVariable('SingleOut_Enabled',  0 /*Boolean*/, $ID_IPSLoggerInstance, 100, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_SingleOutLevel    = CreateVariable('SingleOut_Level',    1 /*Integer*/, $ID_IPSLoggerInstance, 110, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_SingleOutMsg      = CreateVariable('SingleOut_Msg',      3 /*String*/,  $ID_IPSLoggerInstance, 120, '~HTMLBox',        0);
	$ID_HtmlOutEnabled    = CreateVariable('HtmlOut_Enabled',    0 /*Boolean*/, $ID_IPSLoggerInstance, 200, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_HtmlOutLevel      = CreateVariable('HtmlOut_Level',      1 /*Integer*/, $ID_IPSLoggerInstance, 210, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_HtmlOutMsgCount   = CreateVariable('HtmlOut_MsgCount',   1 /*Integer*/, $ID_IPSLoggerInstance, 220, 'IPSLogger_MsgCount', $ID_ScriptIPSLoggerChangeSettings);
	$ID_HtmlOutMsgId      = CreateVariable('HtmlOut_MsgId',      1 /*Integer*/, $ID_IPSLoggerInstance, 230, 'IPSLogger_MsgId', 0);
	$ID_HtmlOutMsgList    = CreateVariable('HtmlOut_MsgList',    3 /*String*/,  $ID_IPSLoggerInstance, 240, '~HTMLBox',        0);
	$ID_IPSOutEnabled     = CreateVariable('IPSOut_Enabled',     0 /*Boolean*/, $ID_IPSLoggerInstance, 300, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_IPSOutLevel       = CreateVariable('IPSOut_Level',       1 /*Integer*/, $ID_IPSLoggerInstance, 310, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_FileOutEnabled    = CreateVariable('FileOut_Enabled',    0 /*Boolean*/, $ID_IPSLoggerInstance, 400, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_FileOutLevel      = CreateVariable('FileOut_Level',      1 /*Integer*/, $ID_IPSLoggerInstance, 410, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_FileOutDays       = CreateVariable('FileOut_Days',       1 /*Integer*/, $ID_IPSLoggerInstance, 420, 'IPSLogger_Days',  $ID_ScriptIPSLoggerChangeSettings);
	$ID_Log4IPSOutEnabled = CreateVariable('Log4IPSOut_Enabled', 0 /*Boolean*/, $ID_IPSLoggerInstance, 500, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_Log4IPSOutLevel   = CreateVariable('Log4IPSOut_Level',   1 /*Integer*/, $ID_IPSLoggerInstance, 510, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_Log4IPSOutDays    = CreateVariable('Log4IPSOut_Days',    1 /*Integer*/, $ID_IPSLoggerInstance, 520, 'IPSLogger_Days',  $ID_ScriptIPSLoggerChangeSettings);
	$ID_EMailOutEnabled   = CreateVariable('EMailOut_Enabled',   0 /*Boolean*/, $ID_IPSLoggerInstance, 600, '~Switch',         $ID_ScriptIPSLoggerChangeSettings);
	$ID_EMailOutLevel     = CreateVariable('EMailOut_Level',     1 /*Integer*/, $ID_IPSLoggerInstance, 610, 'IPSLogger_Level', $ID_ScriptIPSLoggerChangeSettings);
	$ID_EMailOutSendDelay = CreateVariable('EMailOut_SendDelay', 1 /*Integer*/, $ID_IPSLoggerInstance, 620, 'IPSLogger_Delay', $ID_ScriptIPSLoggerChangeSettings);
	$ID_EMailOutMsgList   = CreateVariable('EMailOut_MsgList',   3 /*String*/,  $ID_IPSLoggerInstance, 630, '~TextBox',        0);


	$ID_CategoryWebFront         = CreateCategory('WebFront', $ID_IPSLoggerCategory, 300);
	IPS_SetHidden($ID_CategoryWebFront, true);
	$ID_CategorySettings         = CreateCategory('Settings',$ID_CategoryWebFront, 100);
	$ID_CategorySettingsWidget   = CreateCategory('Widget',  $ID_CategorySettings, 100);
	$ID_CategorySettingsWebFront = CreateCategory('WebFront',$ID_CategorySettings, 200);
	$ID_CategorySettingsIPS      = CreateCategory('IPS',     $ID_CategorySettings, 300);
	$ID_CategorySettingsFile     = CreateCategory('File',    $ID_CategorySettings, 400);
	$ID_CategorySettingsLog4IPS  = CreateCategory('Log4IPS', $ID_CategorySettings, 500);
	$ID_CategorySettingsEMail    = CreateCategory('EMail',   $ID_CategorySettings, 600);

	CreateLink('Logging Window',  $ID_HtmlOutMsgList,  $ID_CategoryWebFront, 10);

	CreateLink('Output Widget',   $ID_SingleOutEnabled,  $ID_CategorySettings, 10);
	CreateLink('Output WebFront', $ID_HtmlOutEnabled,    $ID_CategorySettings, 20);
	CreateLink('Output IPS',      $ID_IPSOutEnabled,     $ID_CategorySettings, 30);
	CreateLink('Output File',     $ID_FileOutEnabled,    $ID_CategorySettings, 40);
	CreateLink('Output Log4IPS',  $ID_Log4IPSOutEnabled, $ID_CategorySettings, 50);
	CreateLink('Output EMail',    $ID_EMailOutEnabled,   $ID_CategorySettings, 60);

	CreateLink('Output Enabled',   $ID_SingleOutEnabled,             $ID_CategorySettingsWidget,   10);
	CreateLink('Logging Level',    $ID_SingleOutLevel,               $ID_CategorySettingsWidget,   20);
	CreateLink('Last Message',     $ID_SingleOutMsg,                 $ID_CategorySettingsWidget,   30);
	CreateLink('Clear Message',    $ID_ScriptIPSLoggerClearSingleOut,$ID_CategorySettingsWidget,   40);
	CreateLink('Output Enabled',   $ID_HtmlOutEnabled,               $ID_CategorySettingsWebFront, 10);
	CreateLink('Logging Level',    $ID_HtmlOutLevel,                 $ID_CategorySettingsWebFront, 20);
	CreateLink('Message Count',    $ID_HtmlOutMsgCount,              $ID_CategorySettingsWebFront, 30);
	CreateLink('Last MessageID',   $ID_HtmlOutMsgId,                 $ID_CategorySettingsWebFront, 40);
	CreateLink('Clear Output',     $ID_ScriptIPSLoggerClearHtmlOut,  $ID_CategorySettingsWebFront, 50);
	CreateLink('Message List',     $ID_HtmlOutMsgList,               $ID_CategorySettingsWebFront, 60);
	CreateLink('Output Enabled',   $ID_IPSOutEnabled,                $ID_CategorySettingsIPS,      10);
	CreateLink('Logging Level',    $ID_IPSOutLevel,                  $ID_CategorySettingsIPS,      20);
	CreateLink('Output Enabled',   $ID_FileOutEnabled,               $ID_CategorySettingsFile,     10);
	CreateLink('Logging Level',    $ID_FileOutLevel,                 $ID_CategorySettingsFile,     20);
	CreateLink('Purge Files after',$ID_FileOutDays,                  $ID_CategorySettingsFile,     30);
	CreateLink('Execute Purge',    $ID_ScriptIPSLoggerPurgeLogFiles, $ID_CategorySettingsFile,     40);
	CreateLink('Output Enabled',   $ID_Log4IPSOutEnabled,            $ID_CategorySettingsLog4IPS,  10);
	CreateLink('Logging Level',    $ID_Log4IPSOutLevel,              $ID_CategorySettingsLog4IPS,  20);
	CreateLink('Purge Files after',$ID_Log4IPSOutDays,               $ID_CategorySettingsLog4IPS,  30);
	CreateLink('Execute Purge',    $ID_ScriptIPSLoggerPurgeLogFiles, $ID_CategorySettingsLog4IPS,  40);
	CreateLink('Output Enabled',   $ID_EMailOutEnabled,              $ID_CategorySettingsEMail,    10);
	CreateLink('Logging Level',    $ID_EMailOutLevel,                $ID_CategorySettingsEMail,    20);
	CreateLink('Send Delay',       $ID_EMailOutSendDelay,            $ID_CategorySettingsEMail,    30);
	CreateLink('Message List',     $ID_EMailOutMsgList,              $ID_CategorySettingsEMail,    40);

   $FileContent = file_get_contents(IPS_GetKernelDir().'scripts/IPSLogger_Constants.ips.php', true);

	$FileContent = SetVariableConstant ("c_ID_SingleOutEnabled",   $ID_SingleOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_SingleOutLevel",     $ID_SingleOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_SingleOutMsg",       $ID_SingleOutMsg, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_HtmlOutEnabled",     $ID_HtmlOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_HtmlOutLevel",       $ID_HtmlOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_HtmlOutMsgCount",    $ID_HtmlOutMsgCount, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_HtmlOutMsgId",       $ID_HtmlOutMsgId, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_HtmlOutMsgList",     $ID_HtmlOutMsgList, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_IPSOutEnabled",      $ID_IPSOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_IPSOutLevel",        $ID_IPSOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_EMailOutEnabled",    $ID_EMailOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_EMailOutLevel",      $ID_EMailOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_EMailOutDelay",      $ID_EMailOutSendDelay, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_EMailOutMsgList",    $ID_EMailOutMsgList, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_FileOutEnabled",     $ID_FileOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_FileOutLevel",       $ID_FileOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_FileOutDays",        $ID_FileOutDays, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_Log4IPSOutEnabled",  $ID_Log4IPSOutEnabled, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_Log4IPSOutLevel",    $ID_Log4IPSOutLevel, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_Log4IPSOutDays",     $ID_Log4IPSOutDays, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_ScriptSendMail",     $ID_ScriptIPSLoggerSendMail, $FileContent);
	$FileContent = SetVariableConstant ("c_ID_ScriptPurgeLogFiles",$ID_ScriptIPSLoggerPurgeLogFiles, $FileContent);

   file_put_contents(IPS_GetKernelDir().'scripts/IPSLogger_Constants.ips.php', $FileContent);

	// Create Timer ...

	// Default Configuration
	include IPS_GetKernelDir().'scripts/IPSLogger.ips.php';
	define ("c_LogId", "AppLogInst");
	SetValue(c_ID_HtmlOutEnabled,   true);
	SetValue(c_ID_HtmlOutLevel,     c_LogLevel_All);
	SetValue(c_ID_HtmlOutMsgCount,  20);
	SetValue(c_ID_SingleOutEnabled, true);
	SetValue(c_ID_SingleOutLevel,   c_LogLevel_Warning);
	SetValue(c_ID_IPSOutEnabled,    true);
	SetValue(c_ID_IPSOutLevel,      c_LogLevel_All);
	SetValue(c_ID_FileOutEnabled,   false);
	SetValue(c_ID_FileOutLevel,     c_LogLevel_Debug);
	SetValue(c_ID_FileOutDays,      10);
	SetValue(c_ID_Log4IPSOutEnabled,false);
	SetValue(c_ID_Log4IPSOutLevel,  c_LogLevel_Debug);
	SetValue(c_ID_Log4IPSOutDays,   10);
	SetValue(c_ID_EMailOutEnabled,  false);
	SetValue(c_ID_EMailOutLevel,    c_LogLevel_Error);
	SetValue(c_ID_EMailOutDelay,    120);

	//  Some Test Messages
	IPSLogger_Fat(c_LogId, 'Test for a Fatal Error');
	IPSLogger_Err(c_LogId, 'Test for a Error ...');
	IPSLogger_Wrn(c_LogId, 'Test for a Warning');
 	IPSLogger_Inf(c_LogId, 'Test for a Information Message ...');
 	IPSLogger_Dbg(c_LogId, 'Test for a Debug Message ...');
 	IPSLogger_Com(c_LogId, 'Test for a Communication Message ...');
 	IPSLogger_Trc(c_LogId, 'Test for a Trace Message ...');
 	IPSLogger_Tst(c_LogId, 'Test for a Test Message ...');


   // ------------------------------------------------------------------------------------------------
	function SetVariableConstant ($Name, $ID, $FileContent) {
		$pos = strpos($FileContent, $Name);
		if ($pos === false) {
		  echo "Error - ".$Name." could NOT be found in FileContent!\n";
		}
		$pos = $pos + strlen($Name);
		while (substr($FileContent, $pos, 1) < "0" or substr($FileContent, $pos, 1) > "9") {
			$pos = $pos+1;
		}
		return substr($FileContent, 0, $pos).$ID.substr($FileContent, $pos+5);
	}



   // ------------------------------------------------------------------------------------------------
	function CreateLink ($Name, $Link, $Parent, $Position) {
	   $LinkId = @IPS_GetLinkIDByName($Name, $Parent);
	   if ($LinkId === false) {
 			$LinkId = IPS_CreateLink();
   		IPS_SetName($LinkId, $Name);
			IPS_SetLinkChildID($LinkId, $Link);
   		IPS_SetParent($LinkId, $Parent);
   		IPS_SetPosition($LinkId, $Position);
	   }
		echo 'Link '.$Name.'='.$LinkId."\n";
		return $LinkId;
	}

   // ------------------------------------------------------------------------------------------------
	function CreateTimer ($Name, $Parent, $Hour) {
	   $TimerId = @IPS_GetEventIDByName($Name, $Parent);
	   if ($TimerId === false) {
 			$TimerId = IPS_CreateEvent(1 /*Cyclic Event*/);
   		IPS_SetName($TimerId, $Name);
   		IPS_SetParent($TimerId, $Parent);
			if (!IPS_SetEventCyclic($TimerId, 2 /**Daily*/, 1,0,0,0,0)) {
				echo "IPS_SetEventCyclic failed !!!\n";
			}
			if (!IPS_SetEventCyclicTimeBounds($TimerId, mktime($Hour, 0, 0), 0)) {
				echo "IPS_SetEventCyclicTimeBounds failed !!!\n";
			}
   		IPS_SetEventActive($TimerId, true);
		}
		echo 'Timer '.$Name.'='.$TimerId."\n";
		return $TimerId;
	}

   // ------------------------------------------------------------------------------------------------
	function CreateCategory ($Name, $Parent, $Position) {
	   $CategoryId = @IPS_GetCategoryIDByName($Name, $Parent);
	   if ($CategoryId === false) {
 			$CategoryId = IPS_CreateCategory();
   		IPS_SetName($CategoryId, $Name);
   		IPS_SetParent($CategoryId, $Parent);
   		IPS_SetPosition($CategoryId, $Position);
	   }
		echo 'Category '.$Name.'='.$CategoryId."\n";
		return $CategoryId;
	}

   // ------------------------------------------------------------------------------------------------
	function CreateVariable ($Name, $Type, $Parent, $Position, $Profile, $Action) {
	   $VariableId = @IPS_GetVariableIDByName($Name, $Parent);
	   if ($VariableId === false) {
 			$VariableId = IPS_CreateVariable($Type);
   		IPS_SetName($VariableId, $Name);
   		IPS_SetParent($VariableId, $Parent);
   		IPS_SetPosition($VariableId, $Position);
   		if ($Profile <> "") {
	  			IPS_SetVariableCustomProfile($VariableId, $Profile);
   		}
   		if ($Action <> 0) {
   			IPS_SetVariableCustomAction($VariableId, $Action);
   		}
		}
		echo 'VariableId '.$Name.'='.$VariableId."\n";
		return $VariableId;
	}

   // ------------------------------------------------------------------------------------------------
	function CreateScript ($Name, $File, $Parent) {
		$ScriptId = @IPS_GetObjectIDByName($Name, $Parent);
		if ($ScriptId ===false) {
			$ScriptId = IPS_CreateScript(0);
   		IPS_SetName($ScriptId, $Name);
 			IPS_SetScriptFile($ScriptId, $File);
			IPS_SetParent($ScriptId, $Parent);
		}
		echo 'Script '.$Name.'='.$ScriptId."\n";
		return $ScriptId;
	}

	function CreateProfiles() {
		@IPS_CreateVariableProfile("IPSLogger_Level", 1);
		IPS_SetVariableProfileText("IPSLogger_Level", "", "");
		IPS_SetVariableProfileValues("IPSLogger_Level", 0, 0, 0);
		IPS_SetVariableProfileDigits("IPSLogger_Level", 0);
		IPS_SetVariableProfileIcon("IPSLogger_Level", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 0, "Fatal", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 1, "Error", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 2, "Warning", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 3, "Information", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 4, "Debug", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 5, "Communication", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 6, "Trace", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 7, "Test", "");
		IPS_SetVariableProfileAssociation("IPSLogger_Level", 8, "All", "");

		@IPS_CreateVariableProfile("IPSLogger_MsgCount", 1);
		IPS_SetVariableProfileText("IPSLogger_MsgCount", "", " Msg's");
		IPS_SetVariableProfileValues("IPSLogger_MsgCount", 5, 100, 5);
		IPS_SetVariableProfileDigits("IPSLogger_MsgCount", 0);
		IPS_SetVariableProfileIcon("IPSLogger_MsgCount", "");

		@IPS_CreateVariableProfile("IPSLogger_MsgId", 1);
		IPS_SetVariableProfileText("IPSLogger_MsgId", "", "");
		IPS_SetVariableProfileValues("IPSLogger_MsgId", 0, 0, 0);
		IPS_SetVariableProfileDigits("IPSLogger_MsgId", 0);
		IPS_SetVariableProfileIcon("IPSLogger_MsgId", "");

		@IPS_CreateVariableProfile("IPSLogger_Delay", 1);
		IPS_SetVariableProfileText("IPSLogger_Delay", "", " Seconds");
		IPS_SetVariableProfileValues("IPSLogger_Delay", 0, 600, 30);
		IPS_SetVariableProfileDigits("IPSLogger_Delay", 0);
		IPS_SetVariableProfileIcon("IPSLogger_Delay", "");

		@IPS_CreateVariableProfile("IPSLogger_Days", 1);
		IPS_SetVariableProfileText("IPSLogger_Days", "", " Tage");
		IPS_SetVariableProfileValues("IPSLogger_Days", 0, 100, 5);
		IPS_SetVariableProfileDigits("IPSLogger_Days", 0);
		IPS_SetVariableProfileIcon("IPSLogger_Days", "");
	}




?>