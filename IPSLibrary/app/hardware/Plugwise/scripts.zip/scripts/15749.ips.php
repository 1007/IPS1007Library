<?

 $remoteRepository = 'C:\\git\\IPSLibrary\\';
$component = 'IPSEDIP';

//IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
//$moduleManager = new IPSModuleManager($component,$remoteRepository);
//$moduleManager->LoadModule($remoteRepository);
//$moduleManager->InstallModule($remoteRepository);


$remoteRepository = 'https://raw.github.com/brownson/IPSLibrary/master/';
$component = 'IPSEDIP';

IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
$moduleManager = new IPSModuleManager($component,$remoteRepository);
$moduleManager->LoadModule($remoteRepository);
$moduleManager->InstallModule($remoteRepository);

?>