<?

 //F�gen Sie hier ihren Skriptquellcode ein

	require_once(IPS_GetScriptID("Funcpool").".ips.php");

	//say("Anruf von Verena B�ttner");




return;


$box3_mac ="77:97:1c:3f:62:f1";

slim_text($box3_mac, "Hallo Welt", "IP-Symcon ist toll", 10);

function slim_text($box , $text1 , $text2 , $time)
{
$TX_BUF = $box." display " .rawurlencode($text1)." ".rawurlencode($text2)." ".$time.chr(13);
//Etwas �ber den COM Port senden
$result = CSCK_SendText(10773, $TX_BUF);
}


//$result = CSCK_SendText(10773, $box3_mac.' playlist play '.chr(13));

//echo $result;


?>