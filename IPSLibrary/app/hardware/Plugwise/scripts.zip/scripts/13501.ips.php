<?

 	$component = "WithingsInfo";

	IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component);
   $moduleManager->LoadModule('C:\\git\\IPSLibrary\\');

   $moduleManager->InstallModule('C:\\git\\IPSLibrary\\');


?>