<?

 FS20_SwitchDuration(19105,true,10);
 

?>