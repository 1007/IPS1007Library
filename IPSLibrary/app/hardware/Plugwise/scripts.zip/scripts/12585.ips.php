<?

   require_once(IPS_GetScriptID("Funcpool").".ips.php");

	//refreshfeed();


	IPS_RunScript("DBox");
	
	monitorschoner();
	
	
function monitorschoner()
	{
	
	require_once(IPS_GetScriptID("Verwaltung.Elo").".ips.php");
	elo(false);

	}
	
?>