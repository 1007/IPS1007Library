<?

 	$zufall = rand(1,100);

	SetValueInteger( 24888,$zufall);


?>