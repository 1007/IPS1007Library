<?


 	echo $IPS_VALUE;
 
set
?>