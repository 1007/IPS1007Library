<?
   require_once(IPS_GetScriptID("Funcpool").".ips.php");
	require_once IPS_GetScriptID("Verwaltung.Email").".ips.php";


   $root_temp	= IPS_GetObjectIDByName("TEMPERATUR",0);
   
	$instance = $IPS_VARIABLE ;
	//$instance = I_BATTERIE_WOHNEN_OFEN;

	$name = IPS_GetName($instance);

	if ( $name == "BAD.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"BAD","","");return;};
	if ( $name == "SCHLAF.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"SCHLAF","","");return;};
	//if ( $name == "AUSSEN.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"AUSSEN","","");return;};
	if ( $name == "ARBEIT.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"ARBEIT","","");return;};
	if ( $name == "TREPPE.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"TREPPE","","");return;};
	if ( $name == "WOHNEN.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"WOHNEN","","");return;};
	if ( $name == "WOHNEN.AUFLADUNG.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"WOHNEN","AUFLADUNG","");return;};
	if ( $name == "ARBEIT.AUFLADUNG.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"ARBEIT","AUFLADUNG","");return;};


	if ( $name == "KUECHE.KUEHLSCHRANK.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"KUECHE","","KUEHLSCHRANK");return;};
	if ( $name == "KUECHE.TIEFKUEHLSCHRANK.TF.BATTERIE" ) { do_batterie($root_temp,$instance,"KUECHE","","TIEFKUEHLSCHRANK");return;};

	echo "\nName : $name nicht gefunden";
	

function do_batterie($root_temp,$instance,$raum,$aufladung,$geraet)
	{

	$raum_instance     = IPS_GetObjectIDByName($raum,$root_temp);
	$status_instance   = IPS_GetObjectIDByName("STATUS",$raum_instance);

	if ( $geraet != "")
		$object = $raum.".".$geraet;
	else
	   $object = $raum;
	
	$leer_instance     = IPS_GetVariableIDByName($object.".TF.ERROR.BATTERIE",$status_instance);

   $instance_error_bat  = "$raum.TF.ERROR.BATTERIE";
	$instance_bat  		= "$raum.TF.BATTERIE";
	
	$string = $object;
	if( $aufladung == "AUFLADUNG" ) $string = $string .".".$aufladung ;
	
	$string = $string . ".TF.ERROR.BATTERIE";
	
	$leer_instance    = IPS_GetVariableIDByName($string,$status_instance);

	
	// Batterie leer wenn true
	if ( GetValueBoolean($instance) == true )
   	{ 
   	// bereits gemeldet
      if ( 	GetValueBoolean($leer_instance)  == false )
      	{
         email_send("Nachricht von Sam","Batterie ".$object." ".$aufladung." ist leer");

			SetValueBoolean($leer_instance, true);
			}
		}
		
	}
	

?>