<?

 /*******************************************************************************************************************************

Meldungsanzeige im WebFront
===========================

Dieses Skript dient zur Verwaltung einer Meldungsliste im WebFront. Meldungen k�nnen hinzugef�gt und entfernt werden.
Es ist auch m�glich, Meldungen zu einem bestimmten Zeitpunkt automatisch l�schen zu lassen, sowie das L�schen von Meldungen
durch Klick im WebFront zu aktivieren.


Installation:
-------------

Dieses Skript richtet automatisch alle n�tigen Objekte bei manueller Ausf�hrung ein. Eine weitere manuelle Ausf�hrung setzt
alle ben�tigten Objekte wieder auf den Ausgangszustand.

- Neues Skript erstellen
- Diesen PHP-Code hineinkopieren
- Skript Abspeichern
- Skript Ausf�hren


Meldung durch ein anderes Skript hinzuf�gen lassen:
---------------------------------------------------

$number = IPS_RunScriptWaitEx(xxxxx, array('action' => 'add', 'text' => 'Test', 'expires' => time() + 60, 'removable' => true));
Die R�ckgabe des Aufrufes ist die Identifikationsnummer der neuen Nachricht, bei Misserfolg wird der Wert 0 zur�ckgegeben.

Parameter:
- 'text': Meldungstext
- 'expires' (optional): Zeitpunkt des automatischen L�schens der Meldung als Unix-Timestamp. Ist der Wert kleiner als
    die aktuelle Timestamp, wird nicht automatisch gel�scht.
- 'removable' (optional): Anzeige eines Buttons zum L�schen der Meldung im WebFront.


Meldung durch ein anderes Skript l�schen lassen:
------------------------------------------------

$success = IPS_RunScriptWaitEx(xxxxx, array('action' => 'remove', 'number' => 123));
Bei erfolgreichem L�schen wird der Wert 1 zur�ckgegeben, bei Misserfolg der Wert 0.

Parameter:
- 'number': Identifikationsnummer der zu l�schenden Meldung


Alle vorhandenen Meldungen durch ein anderes Skript l�schen lassen:
-------------------------------------------------------------------

$success = IPS_RunScriptWaitEx(xxxxx, array('action' => 'removeAll'));
Bei erfolgreichem L�schen wird der Wert 1 zur�ckgegeben, bei Misserfolg der Wert 0.

*******************************************************************************************************************************/


switch ($IPS_SENDER)
{
    case 'Execute':
        install();
        break;

    case 'RunScript':
        $result = 0;
        switch ($action)
        {
            case 'remove':
                if (isset($number) && $number > 0)
                {
                    $result = removeMessage($number);
                }
                break;
                case 'rmMsgNum':
                if (isset($msgnum) && $msgnum > 0)
                {
                          $result = removeMsgNum($msgnum);
                     }
                     break;

            case 'add':
                if (!(isset($expires) && $expires > time())) { $expires = 0; }
                if (!(isset($removable) && $removable === true)) { $removable = false; }
                if (!(isset($msgnum) && $msgnum > 0)) { $msgnum = 0; }
                if (!(isset($img) && $img != '')) { $img = ''; }
                if (isset($text) && is_string($text) && $text != '')
                {
                    $result = addMessage($text, $expires, $removable, $msgnum, $img);
                }
                break;

            case 'removeAll':
                $result = removeAllMessages();
                break;
        }
        echo $result;
        break;

    case 'TimerEvent':
        $number = explode('#', IPS_GetName($IPS_EVENT));
        $number = $number[1];
        IPS_DeleteEvent($IPS_EVENT);
        removeMessage($number);
        break;
}

function removeAllMessages ()
{
    global $IPS_SELF;

    $ParentID = IPS_GetParent($IPS_SELF);
    $DataID = IPS_GetVariableIDByName('Daten', $ParentID);
    $MessagesID = IPS_GetVariableIDByName('Meldungen', $ParentID);
    $LastNumberID = IPS_GetVariableIDByName('letzte Meldungsnummer', $ParentID);

    $ids = IPS_GetChildrenIDs($IPS_SELF);
    foreach ($ids as $id)
    {
        if (IPS_EventExists($id) && substr(IPS_GetName($id), 0, 16) == 'Remove Message #')
        {
            IPS_DeleteEvent($id);
        }
    }

    SetValueString($DataID, json_encode(array()));
    SetValueString($MessagesID, 'Keine Meldungen vorhanden!');
    SetValueInteger($LastNumberID, 0);

    return 1;
}

function removeMsgNum($msgnum) {
/* Loescht Meldungen anhand der Meldungsnummer, es werden dabei alle Meldungen mit der gleichen Nummer geloescht */
    global $IPS_SELF;

    $ParentID = IPS_GetParent($IPS_SELF);
    $DataID = IPS_GetVariableIDByName('Daten', $ParentID);

    $result = 0;
     $i = 0;
     $j = 0;
    $data = json_decode(GetValueString($DataID), true);

     if(!empty($msgnum)) {
         foreach($data as $dataid => $dataval) {
              if($dataval['msgnum'] == $msgnum) {
                if(removeMessage($dataid)) $i++;
                $j++;
             }
          }
          if ($i == $j) $result = 1;
     }
  return $result;
}

function removeMessage ($number)
{
    global $IPS_SELF;

    $ParentID = IPS_GetParent($IPS_SELF);
    $DataID = IPS_GetVariableIDByName('Daten', $ParentID);

    $result = 0;

    if (IPS_SemaphoreEnter($IPS_SELF.'DataUpdate', 2000))
    {
        $data = json_decode(GetValueString($DataID), true);

          if (isset($data[$number]))
        {
            unset($data[$number]);
            $eventID = @IPS_GetEventIDByName('Remove Message #'.$number, $IPS_SELF);
            if ($eventID !== false)
            {
                IPS_DeleteEvent($eventID);
            }
            SetValueString($DataID, json_encode($data));
            $result = 1;
        }
        else
        {
            throwException('Could not remove message #'.$number.': Unknown message number!');
        }

        IPS_SemaphoreLeave($IPS_SELF.'DataUpdate');
        renderData($data);
    }
    else
    {
        throwException('Could not remove message #'.$number.': Semaphore timeout!');
    }

    return $result;
}

function addMessage ($text, $expires, $removable, $msgnum, $img)
{
    global $IPS_SELF;

    $ParentID = IPS_GetParent($IPS_SELF);
    $DataID = IPS_GetVariableIDByName('Daten', $ParentID);
    $LastNumberID = IPS_GetVariableIDByName('letzte Meldungsnummer', $ParentID);

    $number = 0;

    if (IPS_SemaphoreEnter($IPS_SELF.'DataUpdate', 2000))
    {
        $data = json_decode(GetValueString($DataID), true);
        if (!is_array($data))
        {
            $data = array();
        }
        $number = GetValueInteger($LastNumberID) + 1;
        $data[$number] = array('text' => utf8_encode($text), 'expires' => $expires, 'removable' => $removable, 'msgnum' => $msgnum, 'img' => $img);
        if ($expires > time())
        {
            $eventID = IPS_CreateEvent(1);
            IPS_SetParent($eventID, $IPS_SELF);
            IPS_SetName($eventID, 'Remove Message #'.$number);
            IPS_SetEventCyclic($eventID, 1, 0, 0, 0, 0, 0);
            IPS_SetEventCyclicDateBounds($eventID, mktime(0, 0, 0, date('n', $expires), date('j', $expires), date('Y', $expires)), 0);
            IPS_SetEventCyclicTimeBounds($eventID, mktime(date('H', $expires), date('i', $expires), date('s', $expires)), 0);
            IPS_SetEventActive($eventID, true);
        }
        SetValueString($DataID, json_encode($data));
        SetValueInteger($LastNumberID, $number);
        IPS_SemaphoreLeave($IPS_SELF.'DataUpdate');
        renderData($data);
    }
    else
    {
        throwException('Could not add message: Semaphore timeout!');
    }

    return $number;
}

function install ()
{
    global $IPS_SELF;

    IPS_SetHidden($IPS_SELF, true);

    $ParentID = IPS_GetParent($IPS_SELF);

    $instanceID = 0;
    if (IPS_InstanceExists($ParentID))
    {
        $instance = IPS_GetInstance($ParentID);
        if ($instance['ModuleInfo']['ModuleID'] == '{485D0419-BE97-4548-AA9C-C083EB82E61E}')
        {
            $instanceID = $ParentID;
        }
    }
    if ($instanceID == 0)
    {
        $instanceID = IPS_CreateInstance('{485D0419-BE97-4548-AA9C-C083EB82E61E}');
        IPS_SetParent($instanceID, $ParentID);
        IPS_SetName($instanceID, 'Meldungen');
        IPS_SetParent($IPS_SELF, $instanceID);
        $ParentID = $instanceID;
    }

    $DataID = @IPS_GetVariableIDByName('Daten', $ParentID);
    if ($DataID === false)
    {
        $DataID = IPS_CreateVariable(3);
        IPS_SetParent($DataID, $ParentID);
        IPS_SetName($DataID, 'Daten');
    }
    SetValueString($DataID, json_encode(array()));

    $MessagesID = @IPS_GetVariableIDByName('Meldungen', $ParentID);
    if ($MessagesID === false)
    {
        $MessagesID = IPS_CreateVariable(3);
        IPS_SetParent($MessagesID, $ParentID);
        IPS_SetName($MessagesID, 'Meldungen');
        IPS_SetVariableCustomProfile($MessagesID, '~HTMLBox');
    }
    SetValueString($MessagesID, 'Keine Meldungen vorhanden!');

    $LastNumberID = @IPS_GetVariableIDByName('letzte Meldungsnummer', $ParentID);
    if ($LastNumberID === false)
    {
        $LastNumberID = IPS_CreateVariable(1);
        IPS_SetParent($LastNumberID, $ParentID);
        IPS_SetName($LastNumberID, 'letzte Meldungsnummer');
    }
    SetValueInteger($LastNumberID, 0);

    $ids = IPS_GetChildrenIDs($IPS_SELF);
    foreach ($ids as $id)
    {
        if (IPS_EventExists($id) && substr(IPS_GetName($id), 0, 16) == 'Remove Message #')
        {
            IPS_DeleteEvent($id);
        }
    }
}

function renderData ($data)
{
    global $IPS_SELF;

    $ParentID = IPS_GetParent($IPS_SELF);
    $DataID = IPS_GetVariableIDByName('Daten', $ParentID);
    $MessagesID = IPS_GetVariableIDByName('Meldungen', $ParentID);

    $content = "";

    if (count($data) == 0)
    {
        $content = 'Keine Meldungen vorhanden!';
    }
    else
    {
        $content = '<table style="width: 100%;"><tbody>';
        foreach ($data as $number => $message)
        {
                if ($message['img']) {
                  $cont_img = '<img src="data/icon.php?name='.$message['img'].'&theme=png" class="iconImage" />';
                } else {
                  $cont_img = '&nbsp;';
                }
            $content .= '<tr>';
            if ($message['removable'])
            {
                $content .= '<td style="width:20px;">'.$cont_img.'</td><td style="line-height: 25px;">'.utf8_decode($message['text']).'</td><td align="right"><div onclick="dojo.xhrGet({ url: \'user/removeMessage.php?ts=\' + (new Date()).getTime() + \'&ScriptID='.$IPS_SELF.'&number='.$number.'\' });" style="border:1px solid #3B3B4D; margin:0px; padding:3px; text-align:center; width: 100px;">OK</div></td>';
            }
            else
            {
                $content .= '<td style="width:20px;">'.$cont_img.'</td><td style="line-height: 25px;" colspan="2">'.utf8_decode($message['text']).'</td>';
            }
            $content .= '</tr>';
        }
        $content .= '</tbody></table>';
    }

    SetValueString($MessagesID, $content);
}

function throwException ($message)
{
    global $IPS_SELF;

    IPS_LogMessage($IPS_SELF, $message);
}

?>