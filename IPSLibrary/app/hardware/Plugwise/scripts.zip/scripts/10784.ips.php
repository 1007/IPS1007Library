<?

 //F�gen Sie hier ihren Skriptquellcode ein

	$var = 44329;
	$t =  $IPS_SENDER;
	
	$a = 16292 ;
	//$t = GetValueString($var);
	$t = $IPS_VALUE;
	echo $t ;
	//$t = USCK_GetBindIPAddress($a);
	//$t = USCK_GetText($a);

	//$r = USCK_GetIPS ($a);
	//print_r($r);
	
	//IPS_LogMessage (1007,$t);

	

?>