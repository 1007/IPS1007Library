<?

    include_once IPS_GetKernelDir()."\scripts\IPSLibrary\app\core\IPSUtils\IPSUtils.inc.php";
    IPSUtils_Include("IPSLogger_PhpErrorHandler.inc.php", "IPSLibrary::app::core::IPSLogger");
?>