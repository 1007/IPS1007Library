<?

	$anzahl  = 10 ;
	$pfad 	= IPS_GetKernelDir() . "webfront\\rss\\";
	$datafile= $pfad . "rssdata.txt";
	$rssfile = $pfad . "rss.xml";
	$now 		= date("H:i");
	//$z = rand(0,1000);
	$titel0 = "$now Temperaturen";
	$description0 = "Aussen:7.5 Arbeit:18.0 <br> Wohnen:18.8 Bad:10.0";

	$newtitel = "$now";
	$newdescription = "Roomba <br> gestartet";

	$result = make_rss_feed($datafile,$rssfile,$anzahl,
										$titel0,$description0,
										$newtitel,$newdescription);
	
	
function make_rss_feed($datafile,$rssfile,$anzahl,
								$titel0,$description0,
								$newtitel,$newdescription)
	{
	
	$error = 0;
	

	if ( !file_exists($datafile)) touch($datafile);
	$olddata = file($datafile);
	
	$anzahlold = count($olddata);
	if ( $anzahlold<$anzahl)
		$anzahl = $anzahlold;

	$newzeile = "<item>".
					"<title>".$newtitel."</title>".
					"<description>".$newdescription."</description>".
					"</item>";

	$newdata[0] = $newzeile.chr(13).chr(10);
	for ($x=1;$x<=($anzahl-1);$x++)
		$newdata[$x] = $olddata[$x-1];
		
	if ( !$handle = fopen($datafile,"w"))	{ $error = 1; return $error;}
	foreach ( $newdata as $zeile ) { 
	   if ( !fwrite($handle,$zeile )) 		{ $error = 2; return $error;}}
	fclose($handle);

	$rssdata[0] = "<?xml version='1.0' encoding='ISO-8859-1'?>".chr(13).chr(10);
	$rssdata[1] = "<rss version='0.91'>".chr(13).chr(10);
	$rssdata[2] = "<channel>".chr(13).chr(10);
	$rssdata[3] = "<title>IPSymcon Newsticker</title><description>Homeserver</description>".chr(13).chr(10);
	$rssdata[4] = "<item><title>".$titel0."</title><description>".$description0."</description></item>".chr(13).chr(10);
	$rssdata[4] = str_replace("<br>","\n",$rssdata[4]);
	
	for ($x=0;$x<$anzahl;$x++)
		$rssdata[$x+5] = str_replace("<br>","\n",$newdata[$x]);
	$rssdata[$anzahl+5] = "</channel>".chr(13).chr(10);
	$rssdata[$anzahl+6] = "</rss>".chr(13).chr(10);

	if ( !$handle = fopen($rssfile,"w")) 	{ $error = 3; return $error;}
	foreach ( $rssdata as $zeile ){ echo "\n$zeile";echo "?";
	   if ( !fwrite($handle,$zeile )) 		{ $error = 4; return $error;}}
	fclose($handle);
	
	return $error;
	
	}




?>