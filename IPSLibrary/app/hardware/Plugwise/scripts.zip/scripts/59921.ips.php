<?

 	$kerneldir = IPS_GetKernelDir();

	$dir = $kerneldir . "webfront\\img\\";
	$file = $dir . "roomba.png";
	$wohnung = $dir . "wohnung.png";

	$dir = $kerneldir . "logs\\";
	$log = $dir . "roomba.log";
	
	//echo "\n" . $dir;
	//echo "\n" . $file;

	$hoehe = 1800;
	$breite = 1200;


	$im = imagecreatetruecolor($breite,$hoehe)
      or die('Cannot Initialize new GD image stream');

	$hg = imagecreatefrompng($wohnung);

	$weiss   = ImageColorAllocate($im, 255, 255, 255);
	$green 	= imagecolorallocate($im,   0, 255,   0);
	$navy    = imagecolorallocate($im, 0x00, 0x00, 0x80);
	$grey    = imagecolorallocate($im, 0xC0, 0xC0, 0xC0);

	$startx = 800;
	$starty = 1200;

	$array = array(
						array(100,0),
						array(100,-90)
						//array(-100,0),
						//array(-100,90)

						);

	$data = file($log);
	$data = explode(chr(13),$data[0]);
	$inc = array();
	$zaehler = 0;
	foreach(  $data as $line )
	   {
		$line = explode (",",$line);
		$inc[$zaehler] = $line;
		$zaehler ++;
		}
		
		
	//print_r($inc);
	imagefilledarc($im, $startx, $starty, 15, 15, 0, 360, $weiss, IMG_ARC_PIE);

	$aktwinkel = 0;
	$aktweg = 0;
	
	$oldinclinks  = $inc[0][3];
	$oldincrechts = $inc[0][4];

	echo "\nStart".$oldinclinks."-".$oldincrechts;


	foreach(  $inc as $line )
	   {
		
		$wegaenderung    = $line[1];
		$winkelaenderung = $line[2];

		$aktinclinks  = $oldinclinks  - $line[3];
		$aktincrechts = $oldincrechts - $line[4];

		$p1 = 20000;
		if ( $aktinclinks > $p1 )
		   $aktinclinks = $aktinclinks - 65535;
		if ( $aktinclinks < -$p1 )
		   $aktinclinks = $aktinclinks + 65535;

		if ( $aktincrechts > $p1 )
		   $aktincrechts = $aktincrechts - 65535;
		if ( $aktincrechts < -$p1 )
		   $aktincrechts = $aktincrechts + 65535;

		$aktincdiff   = $aktinclinks - $aktincrechts;

		$aktincsum    = ( $aktinclinks + $aktincrechts) / 2;

		echo "\ninclinksold:".$oldinclinks."-aktinclinks:".$aktinclinks."--" .$line[3];

		$winkelradian = (2 * $aktincdiff) / 258 ;
		$winkelgrad   = (360 * $aktincdiff) / (258 * Pi());

		$wegaenderung = ( $aktinclinks + $aktincrechts) / 20;

		if ( $winkelgrad > 360 )
		   $winkelgrad = $winkelgrad - 360 ;
		if ( $winkelgrad < -360 )
		   $winkelgrad = $winkelgrad + 360 ;

		$aktwinkel = $aktwinkel - $winkelgrad;
		//$aktwinkel =  $winkelgrad;

		if ( $aktwinkel > 360 )
		   $aktwinkel = $aktwinkel - 360 ;
		if ( $aktwinkel < -360 )
		   $aktwinkel = $aktwinkel + 360 ;

		//echo "\nDiff:" . $aktincdiff ." - Radian:".$winkelradian." - Grad:" . $winkelgrad ;
		//echo "\naktlinks:".$aktinclinks." - aktrechts:". $aktincrechts ."-----".$line[3]."-".$oldinclinks."-".$aktinclinks;

		$oldinclinks  = $line[3];
		$oldincrechts = $line[4];
		
		
      $gk = $wegaenderung * sin(deg2rad($aktwinkel));
      $ak = $wegaenderung * cos(deg2rad($aktwinkel));

		$x = $startx - $gk ;
		$y = $starty + $ak;

		//echo "\nWeg: " . $wegaenderung ." - Winkel : " .$winkelaenderung ."[".$aktwinkel."] - Winkelgrad : " .$winkelgrad ;
		   
		imageline ( $im , $startx , $starty , $x , $y , $green );
		imagefilledarc($im, $startx, $starty, 5, 5, 0, 360, $weiss, IMG_ARC_PIE);
		echo "X:".$x."Y:".$y;
		$startx = $x;
		$starty = $y;

	   }
	imagefilledarc($im, $startx, $starty, 15, 15, 0, 360, $grey, IMG_ARC_PIE);

	// Roomba
   imagefilledarc($im, 500, 50, 50, 50, 0, 360, $weiss, IMG_ARC_PIE);

	//imagecopymerge($im, $hg, 0, 0, 0, 0, 1000, 1000, 100);


	imagepng($im,$file);
	imagedestroy ( $im );

?>