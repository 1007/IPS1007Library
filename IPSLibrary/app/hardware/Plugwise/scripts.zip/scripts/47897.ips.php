<?

	//***************************************************************************
	//
	// Variablentypen :
	//                      0  -  Boolean
	//                      1  -
	//                      2  -  Float
	//
	//***************************************************************************

 	//echo "\nWebfront:".$IPS_VARIABLE."-".$IPS_VALUE;

	if ( !isset($IPS_VARIABLE)) { echo "Error" ; return; }
	
	$array = IPS_GetVariable($IPS_VARIABLE);
	$typ =  $array['VariableValue']['ValueType'];

	//print_r($array);
	//echo "\n[$typ]";

	if ( $typ == 0 ) SetValueBoolean($IPS_VARIABLE,$IPS_VALUE);
	if ( $typ == 1 ) SetValueInteger($IPS_VARIABLE,$IPS_VALUE);
	if ( $typ == 2 ) SetValueFloat($IPS_VARIABLE,$IPS_VALUE);
	if ( $typ == 3 ) SetValueString($IPS_VARIABLE,$IPS_VALUE);


?>