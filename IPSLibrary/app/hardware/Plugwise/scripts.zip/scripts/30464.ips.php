<?

//IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
//$moduleManager = new IPSModuleManager('IPSWecker','https://raw.github.com/MCS-51/IPSLibrary/Development/');
//$moduleManager->LoadModule('', true);


IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
$moduleManager = new IPSModuleManager('IPSWecker','https://raw.github.com/MCS-51/IPSLibrary/Development/');
$moduleManager->InstallModule();

//IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
//$moduleManager = new IPSModuleManager($component,$remoteRepository);
//$moduleManager->LoadModule($remoteRepository);


?>