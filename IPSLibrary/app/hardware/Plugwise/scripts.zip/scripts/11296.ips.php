<?

	$x = GetValue(37817);
	$y = GetValue(31159);
	$z = $x - $y ;
	SetValue(11090,$z);
	
	
?>