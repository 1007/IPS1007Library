<?

	$resFile = fopen( "C:/IP-symcon2/counter.txt", "w+");

	for ($i=0; $i < 1000 ; $i++)
		{
 		fwrite($resFile, 65);
		}
	fclose($resFile);

?>