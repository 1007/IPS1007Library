<?


   require_once(IPS_GetScriptID("Funcpool.DBox").".ips.php");
   require_once(IPS_GetScriptID("Funcpool").".ips.php");

   
   //echo $IPS_VALUE;
   $string = $IPS_VALUE;
   
 
 	$c = explode(";",$string);

	$timestamp 	= $c[0];
 	$command   	= $c[1];
   $nummer     = $c[3];
   
   //echo $command;
   //echo $nummer;
   
   if ( $command == "RING" )
      {
      dbox_control(DBOX2_IP,DBOXCONTROL_VOLUME,"20",1);
      dbox_control(DBOX3_IP,DBOXCONTROL_VOLUME,"20",1);
      newfeed("Telefon","Ankommender Telefonanruf: $nummer");
      $text = WWWReader_RetrievePage(40685,"http://whocallsme.com/Phone-Number.aspx/$nummer");
      preg_match_all('|<div class="oos_p6">(.*)</div>|siU',$text,$ar);

		$text = "Telefonanruf von " . $nummer . "\n";
		for($x=0; $x < count($ar[0]); $x++)
	   	{
	   	$text = $text . "\n" .$ar[0][$x];
	   	$text = $text . "\n-";
	   	}
      email($text,"");
      
      }
   if ( $command == "DISCONNECT" )
      {
      dbox_control(DBOX2_IP,DBOXCONTROL_VOLUME,"100",1);
      dbox_control(DBOX3_IP,DBOXCONTROL_VOLUME,"100",1);
		}

 

?>