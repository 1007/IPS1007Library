<?

 //Start writing your scripts between the brackets
 
 
  require_once("FUNCPOOL.IPS.PHP");
  
  email("Es hat geklingelt");
  
 

?>