<?




function elo($status)
	{
	// $status = false   alle 5 Minuten
	// $status = true    Piri ausgeloest
	
	return;
	
	
	$root_system 	 = IPS_GetObjectIDByName("SYSTEM",IPS_GetObjectIDByName("DATEN",0));
	
	$now = time();
   $instance = IPS_GetObjectIDByName("ARBEIT",IPS_GetObjectIDByName("EINGAENGE",0));
   $instance = IPS_GetObjectIDByName("EINGANG.ARBEIT.PIRI.DATA",IPS_GetObjectIDByName("EINGANG.ARBEIT.PIRI",$instance));
	$ist = IPS_GetVariable($instance);

	$ist_updated = $ist['VariableUpdated'];
	$diff_false = $now - $ist_updated;

	$instance_wakeup 	= IPS_GetObjectIDByName("MONITOR_WAKEUP",$root_system);

	$ist_wakeup = IPS_GetVariable($instance_wakeup);

	$ist_updated_wakeup = $ist_wakeup['VariableUpdated'];

	$diff_true = $now - $ist_updated_wakeup;
	
	if ( $status == false )
	   {
	   // alle 5 Minuten
		// Pirizeit abfragen
	
		if ( $diff_false > 1800 )
			{
			// Monitor aus
			$cmd = IPS_GetKernelDir()."nircmd.exe";
			$param = "monitor off";
			IPS_ExecuteEx($cmd, $param, false, false, 0);
			SetValueBoolean($instance_wakeup,false);
			}
		}

	if ( $status == true )
	   {
		// Piri ausgeloest
		//
			
      $off = GetValueBoolean($instance_wakeup);
      
		if ($diff_true > 1200 OR !$off )
			{
			// Monitor ein
			IPS_ExecuteEx("C:\Programme\EloTouchSystems\EloSetOptions.exe","", false, true,0);
			SetValueBoolean($instance_wakeup,true);
			}

		
		}
	
	}
	

?>