<?
//******************************************************************************
// 	email puffern wenn Versand fehlschlaegt
// 	Timeraufruf alle x Minuten um gepufferte Mails zu senden oder mit script
//    $root_id = Wo sollen die Mail gepuffert werden
//    $smtp_id = SMTP Object-ID
//
//    Benutzung email senden:
//
//                require_once IPS_GetScriptID("Verwaltung.Email").".ips.php";
//                email_send("subject","text");
//
//
//    Benutzung email resend:
//
//                require_once IPS_GetScriptID("Verwaltung.Email").".ips.php";
//                email_resend();
//******************************************************************************

	$debug = false;
	
   $root_id = 56334;
	$smtp_id = 56594;

	if ( $debug ) echo "Verwaltung email";
	
	if ( isset($IPS_SENDER) )
		{
		if ( $IPS_SENDER == "TimerEvent" ) email_resend();
		if ( $IPS_SENDER == "Execute" )    email_resend();
		}
		
	
function email_send($subject,$text,$anhang)
	{
   $root_id = 56334;
	$smtp_id = 56594;
	$debug = false;
	$root_daten = IPS_GetObjectIDByName("DATEN",0);
	$status_instance = IPS_GetObjectIDByName("EINSTELLUNGEN",$root_daten);

	$send = GetValueBoolean(IPS_GetVariableIDByName("EINSTELLUNGEN.EMAIL.SENDEN",$status_instance));

	if (!$send) return;

	if(file_exists($anhang))
    	$status = SMTP_SendMailAttachment($smtp_id,$subject,$text,$anhang);
	else
		$status = SMTP_SendMail($smtp_id,$subject,$text);

	if ( !$status )
		{
		if ($debug ) echo "email Fehlgeschlagen";
		email_puffern($subject,$text,$anhang); 		// fehlgeschlagen
		}

	}
	
function email_puffern($subject,$text,$anhang)
	{
   $root_id = 56334;
	$smtp_id = 56594;

	$subject_id = IPS_CreateVariable(3);
	IPS_SetName($subject_id,$subject);
	IPS_SetParent($subject_id,$root_id);
	SetValueString($subject_id,$text);
	}

function email_resend()
	{
   $root_id = 56334;
	$smtp_id = 56594;

	//echo "Start".$root_id;
	$root_daten = IPS_GetObjectIDByName("DATEN",0);
	$status_instance = IPS_GetObjectIDByName("EINSTELLUNGEN",$root_daten);

	$send = GetValueBoolean(IPS_GetVariableIDByName("EINSTELLUNGEN.EMAIL.SENDEN",$status_instance));

	if (!$send) return;

	$puffer = IPS_GetChildrenIDs($root_id);
	if ( !$puffer ) return ;

	$subject_id = $puffer[0];
	$subject = IPS_GetName($subject_id);
	$text = GetValueString($subject_id);

   $status = SMTP_SendMail($smtp_id,$subject,$text);
	if ( $status ) IPS_DeleteVariable($subject_id);			// erfolgreich

	}
	
 
?>