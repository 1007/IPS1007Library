<?

			//$cmd = IPS_GetKernelDir()."nircmd.exe";
			//$param = "monitor off";
			//IPS_ExecuteEx($cmd, $param, false, false, 0);

 //IPS_ExecuteEx("C:\Programme\EloTouchSystems\EloSetOptions.exe","", false, true,0);
 //print_r(Sys_GetSpooler());

 FS20_SwitchDuration(46636, TRUE,60);
 
?>