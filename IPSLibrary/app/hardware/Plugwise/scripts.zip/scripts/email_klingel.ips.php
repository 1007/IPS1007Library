<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : email.ips.php
Trigger  : 
Interval : 
*/

  /*
*******************************
IP-SYMCON Event Scripting
*******************************
*/
//(C) bY CSS - M&M April 2005
//File: EMail.ips.php
//Trigger: TEMP_Vorlauf
//*** Achtung ***
//Wenn das Script per Execute aus den Event Scripts gestartet wird
//kann ein Script Timeout vorkommen
//Das beeinflusst aber nicht die Funktion im Timer Modus,
//sondern nur die fehlende Ausgabe im "Output" Fenster
//------------------------------------------------------------------------------

//Mail konfiguration
$mailserver = "smtp.strato.de";
//Benutzername/Passwort
$username = "home@inisnet.de";
$password = "k7pmde";
//Absender
$sendermail = "home@inisnet.de";
$sendername = "IP-SYMCON";
//Emp�nger
$receivemail = "juergen.gerharz@inisnet.de";
$receivename = "Juergen Gerharz";
//Betreff
$subject = "IPS-HOME";
//Meldung
$message ="Meldung von IP-Symcon,\r\n\r\n";
$message.="Es hat geklingelt !\r\n\r\n";


   //--- Script f�r Mailversand ---
   //* Keine weitere Konfiguration n�tig

   //Klasse f�r Mailversand importieren
   //(c) by http://phpmailer.sourceforge.net/
   include("class.smtp.php");

   //Object erstellen
   $mail = new SMTP();

   //Zum SMTP Server verbinden
   if(!$mail->Connect($mailserver)) {
       echo "Error connecting to MAIL SERVER";
      exit;
   }

   //Handshake
   if(!$mail->Hello()) {
       echo "Error in HELO";
       exit;
   }

   //Anmelden
   if(!$mail->Authenticate($username, $password)) {
       echo "Error in AUTH";
       exit;
   }

   //Mail generieren
   $CRLF = "\r\n";
   $header ="From: \"$sendername\" <$sendermail>".$CRLF;
   $header.="To: \"$receivename\" <$receivemail>".$CRLF;
   $header.="Subject: $subject".$CRLF;
   $header.=$CRLF;

   //Absender angeben
   if(!$mail->Mail($sendermail)) {
       echo "Sender not Accepted";
   } else {      //emp�nger
       if(!$mail->Recipient($receivemail)) {
         echo "Receptor not accepted!";
      } else {
           if(!$mail->Data($header.$message)) {
                 echo "Error Sending MAIL!";
           }
      }
   }



?>
