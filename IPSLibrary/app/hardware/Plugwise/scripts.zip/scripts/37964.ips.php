<?
/*
    IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
    $moduleManager = new IPSModuleManager('IPSModuleManager', 'https://raw.github.com/brownson/IPSLibrary/Development/');
    $moduleManager->LoadModule();
    $moduleManager->InstallModule();
*/
	
    IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
    $moduleManager = new IPSModuleManager('IPSLogger', 'https://raw.github.com/brownson/IPSLibrary/Development/');
    $moduleManager->LoadModule('',true);
    $moduleManager->InstallModule();
    $moduleManager = new IPSModuleManager('IPSComponent', 'https://raw.github.com/brownson/IPSLibrary/Development/');
    $moduleManager->UpdateModule('',true);
    $moduleManager = new IPSModuleManager('IPSMessageHandler', 'https://raw.github.com/brownson/IPSLibrary/Development/');
    $moduleManager->UpdateModule('',true);
?>