<?

	$dir = IPS_GetKernelDir();
	$dir = $dir . "\\scripts\\IPSLibrary\\\app\\core\\IPSComponent\\";
	$class = "IPSComponent.class.php";
	$file = $dir . $class;

	
 	include($file);
	outVarsMethods('IPSComponent');
	
	
	function outVarsMethods($class) {
  echo '<p><strong>'.$class.' - Variablen:</strong><br />';
  $aVars = get_class_vars($class);
  foreach($aVars as $k => $v) {
    echo "[$k] => $v <br />";
  }
  echo '</p><p><strong>'.$class.' - Methoden:</strong><br />';
  $aMethods = get_class_methods($class);
  sort($aMethods);
  foreach($aMethods as $k => $v) {
    echo "[$k] => $v <br />";
  }
  echo '</p>';
}

?>