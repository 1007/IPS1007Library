<?
	$debug = false ;
	
	$id = 33146;
	$time = 1 ;
	
	$zufall = rand(1,4);

	//PJ_RunProgram($id, 0);
	//return;
	if ( $debug ) echo $zufall ;
	
	if ( $zufall == 1 )
 		PJ_DimRGBW($id,0,$time,255,$time,0,$time,0,0);
	if ( $zufall == 2 )
 		PJ_DimRGBW($id,255,$time,0,$time,0,$time,0,0);
	if ( $zufall == 3 )
 		PJ_DimRGBW($id,255,$time,255,$time,0,$time,0,0);
	if ( $zufall == 4 )
 		PJ_DimRGBW($id,0,$time,0,$time,255,$time,0,0);



 	sleep(1);
 	
	$time_r = 90 ;
	$time_g = 90 ;
	$time_b = 90 ;

 	PJ_DimRGBW($id,0,$time_r,0,$time_g,0,$time_b,0,0);

 

?>