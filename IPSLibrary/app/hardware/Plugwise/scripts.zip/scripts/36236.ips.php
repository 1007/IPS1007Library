<?

	$var[1] = 28905;
	$var[2] = 34783;
	$var[3] = 59265;
	$var[4] = 56926;
	$var[5] = 47857;
	$var[6] = 16616;

	for ( $x=1;$x<7;$x++)
	   {
		$obj[$x] = IPS_GetVariable($var[$x]);
		$temp[$x] = $obj[$x]['VariableValue']['ValueFloat'];
		$time[$x] = date("d.m.Y H:i",$obj[$x]['VariableUpdated']);
		$prof[$x] = $obj[$x]['VariableCustomProfile'];
		$obj[$x]  = IPS_GetObject($var[$x]);
		$name[$x] = $obj[$x]['ObjectName'];
		}
		
	$s = "<style type='text/css'>";
	$s = $s . "table.test { width: 100%; border-collapse: true;}";
	$s = $s . "Test { border: 1px solid #444455; }</style>";
	$s = $s . "<table class='test'>";
	
	for ( $x=1;$x<7;$x++)
		{
		$s = $s . "<tr>";
		$s = $s . "<td style='background: #223344;' colspan='2'>$time[$x]</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'><h4>$temp[$x]</td>";
		$s = $s . "<td style='background: #223344;' colspan='2'>Grad</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'>$name[$x]</td>";
		$s = $s . "<td style='background: #223344;' colspan='2'>$prof[$x]</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'>IP-Symcon</td>";
		$s = $s . "</tr>";
		$s = $s . "<tr>";
		}

	SetValueString(18594,$s);

?>