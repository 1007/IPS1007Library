<?

define("DBOX2_IP","192.168.11.2");
define("DBOX3_IP","192.168.11.3");

   
   
function checkip($ip)
   {


   $status = Sys_Ping($ip,1000);
	//echo "Status: [$status]";
	
   if ( $status != "" )
		$erg = true;
	else
	   $erg = false;
	
	if ( $ip == DBOX2_IP )
		{
      $VarID = IPS_GetVariableID("DBOX2.STATUS.ONLINE");
   	SetValue($VarID, $erg);
		}
	if ( $ip == DBOX3_IP )
		{
      $VarID = IPS_GetVariableID("DBOX3.STATUS.ONLINE");
   	SetValue($VarID, $erg);
		}

	return $erg;
	
   }
   


   
function dbox_getdate($ip)
   {
   echo "\n--$ip--\n";
	$ok = false;
	if ( $ip == DBOX2_IP )
		{
   	$VarID = IPS_GetVariableID("DBOX2.DATA");
   	SetValue($VarID, "");
		$instance = I_WWWDBOX2;
		$ok = true;
		}
	if ( $ip == DBOX3_IP )
		{
   	$VarID = IPS_GetVariableID("DBOX3.DATA");
   	SetValue($VarID, "");
		$instance = I_WWWDBOX3;
		$ok = true;
		}

	if ( $ok == false )
		return false;
		
 	
   if (checkip($ip))
      {

   	$text = WWWReader_RetrievePage($instance, "http://$ip/control/getdate");
		echo $text;
		SetValue($VarID, $text);
		}

 	
/*
   if (checkip($ip))
      {
      $text = WWWReader_RetrievePage($instance, "http://$dbox/control/getdate");
      SetValue($VarID, $text);
      return true;
      }
   else
      {
      return false;
      }
      
*/
   }
   
   
function dbox_epg($dbox,$command)
   {
   if (checkip($dbox))
      {
      WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/epg?$command");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }
   }

function dbox_shutdown($dbox)
   {
   if (checkip($dbox))
      {
      WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/shutdown");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }

   }
function dbox_message($dbox,$s,$cmd)
   {
   if (checkip($dbox))
      {
      if ( $cmd )
         WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/message?nmsg=$s");
      else
         WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/message?popup=$s");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }
   }
function dbox_timer($dbox)
   {
   if (checkip($dbox))
      {
      WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/timer");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }
   }

function dbox_getbouquets($dbox)
   { 
   if (checkip($dbox))
      {
      WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/getbouquets");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }
   }

function dbox_getbouquet($dbox,$id)
   {
   
   $instance = I_WWWDBOX2;
   
   
   if (checkip($dbox))
      {
      WWWReader_SetPage($instance,"http://$dbox/control/getbouquet?bouquet=$id&mode=TV");
      IPS_ApplyChanges($instance);
      WWWReader_UpdatePage($instance);
      return true;
      }
   else
      {
      return false;
      }
   }
   
   
function dbox_zapto($dbox,$id)
   {
   if (checkip($dbox))
      {
      WWWReader_SetPage(I_WWWDBOX,"http://$dbox/control/zapto?$id");
      IPS_ApplyChanges(I_WWWDBOX);
      WWWReader_UpdatePage(I_WWWDBOX);
      return true;
      }
   else
      {
      return false;
      }
   }

?>