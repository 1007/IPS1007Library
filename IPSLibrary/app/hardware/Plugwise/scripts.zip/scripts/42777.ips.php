<?

	//require_once("DEF_INSTANCEN.ips.php");

	// Folgenden "Vorarbeiten"
	// Instance WWWReader erstellen und InstanceID hier eintragen
	define("DBOX_INSTANCE",31723) ;
	// DBox IPs hier eintragen
	define("DBOX2_IP","192.168.10.2");
	define("DBOX3_IP","192.168.10.3");
	// Ein paar Variablen erstellen
	// DBOX2.DATA     								String
	// DBOX2.STATUS.OFFLINE.TIMESTAMP 			Integer
	// DBOX2.STATUS.OFFLINE.TIMESTAMP.DIFF 	Integer
	// DBOX2.STATUS.ONLINE                    Boolean
	// DBOX2.STATUS.ONLINE.TIMESTAMP          Integer
	// DBOX2.STATUS.STANDBY                   Integer
	


	define("DBOX2_DATA","DBOX2.DATA");
	define("DBOX3_DATA","DBOX3.DATA");
	define("DBOX2_STATUS","DBOX2.STATUS.ONLINE");
	define("DBOX3_STATUS","DBOX3.STATUS.ONLINE");

	define("DBOXCONTROL_STATUS"			,0);
	define("DBOXCONTROL_DATUM"				,1);
	define("DBOXCONTROL_ZEIT"				,2);
	define("DBOXCONTROL_MESSAGE"			,3);
	define("DBOXCONTROL_POPUP"				,4);
	define("DBOXCONTROL_SHUTDOWN"			,5);
	define("DBOXCONTROL_TIMER"				,6);
	define("DBOXCONTROL_BOUQUETS"			,7);
	define("DBOXCONTROL_BOUQUET"			,8);
	define("DBOXCONTROL_EPG"				,9);
	define("DBOXCONTROL_ZAPTO"				,10);
	define("DBOXCONTROL_CHANNELLIST"		,11);
	define("DBOXCONTROL_STANDBY"			,12);
	define("DBOXCONTROL_VOLUME"			,13);
	define("DBOXCONTROL_SETMODE"			,14);
	define("DBOXCONTROL_GETMODE"			,15);
	define("DBOXCONTROL_INFO"				,16);
	define("DBOXCONTROL_GETBOUQUETSXML"	,17);
	define("DBOXCONTROL_GETSERVICESXML"	,18);
	define("DBOXCONTROL_LCD"				,19);
	define("DBOXCONTROL_RCEM"				,20);

	

//**************************************************************************
//    DBox Funktionen
//**************************************************************************
function dbox_control($ip,$control,$string,$debug)
	{
	
	
	switch($control)
	   {
			case DBOXCONTROL_STATUS:
			         checkip($ip,$string,$debug);
			         break;
			case DBOXCONTROL_DATUM:
                  dbox_getdate($ip,$string,$debug);
			         break;
	   	case DBOXCONTROL_ZEIT:
	   	      	dbox_gettime($ip,$string,$debug);
						break;
			case DBOXCONTROL_MESSAGE:
						dbox_message($ip,$string,$debug);
						break;
			case DBOXCONTROL_POPUP:
						dbox_popup($ip,$string,$debug);
						break;
			case DBOXCONTROL_SHUTDOWN:
						dbox_shutdown($ip,$string,$debug);
						break;
			case DBOXCONTROL_TIMER:
						dbox_timer($ip,$string,$debug);
						break;
			case DBOXCONTROL_BOUQUETS:
						dbox_getbouquets($ip,$string,$debug);
						break;
			case DBOXCONTROL_BOUQUET:
						dbox_getbouquet($ip,$string,$debug);
						break;
			case DBOXCONTROL_EPG:
						dbox_epg($ip,$string,$debug);
						break;
			case DBOXCONTROL_ZAPTO:
						dbox_zapto($ip,$string,$debug);
						break;
			case DBOXCONTROL_CHANNELLIST:
						dbox_channellist($ip,$string,$debug);
						break;
			case DBOXCONTROL_STANDBY:
						dbox_standby($ip,$string,$debug);
						break;
			case DBOXCONTROL_VOLUME:
						dbox_volume($ip,$string,$debug);
						break;
			case DBOXCONTROL_SETMODE:
						dbox_setmode($ip,$string,$debug);
						break;
			case DBOXCONTROL_GETMODE:
						dbox_getmode($ip,$string,$debug);
						break;
			case DBOXCONTROL_INFO:
						dbox_info($ip,$string,$debug);
						break;
			case DBOXCONTROL_GETBOUQUETSXML:
						dbox_getbouquetsxml($ip,$string,$debug);
						break;
			case DBOXCONTROL_GETSERVICESXML:
						dbox_getservicesxml($ip,$string,$debug);
						break;
			case DBOXCONTROL_LCD:
						dbox_lcd($ip,$string,$debug);
						break;
			case DBOXCONTROL_RCEM:
						dbox_rcem($ip,$string,$debug);
						break;



	      default:
	               echo "\nUnknown DBox Control\n";
                  break;
	   
	   }


	$dbox_data = "dasdads";
	if ( $ip == DBOX2_IP )
	   { $dbox_data = GetValueString("DBOX2.DATA"); }
	if ( $ip == DBOX3_IP )
	   { $dbox_data = GetValueString("DBOX3.DATA");  }

	return $dbox_data;



	}
//**************************************************************************



//**************************************************************************
//
//**************************************************************************
function get_instance_dboxdata($ip)
	{
	$ok = false;
	if ( $ip == DBOX2_IP )
	   { $dbox_data = DBOX2_DATA; $ok = true; }
	if ( $ip == DBOX3_IP )
	   { $dbox_data = DBOX3_DATA; $ok = true; }

	if ( $ok == false )
	   return false;
	   
   $VarID = IPS_GetVariableID($dbox_data);
   SetValue($VarID, "");
   	
	return $VarID;
	}
//**************************************************************************

//**************************************************************************
// checken ob Box online
//**************************************************************************
function checkip($ip,$string,$debug)
   {
	$debug = false;
	$ok = false;
	if ( $ip == DBOX2_IP )
		{
		$ok = true;
		$dboxstring = "DBOX2";
		$status_instance = DBOX2_STATUS;
		$timestamp_instance_online 	= "DBOX2.STATUS.ONLINE";
		$timestamp_instance 				= "DBOX2.STATUS.OFFLINE.TIMESTAMP";
		$timestamp_instance_diff 		= "DBOX2.STATUS.OFFLINE.TIMESTAMP.DIFF";
		$timestamp_instance_offline 	= "DBOX2.STATUS.ONLINE.TIMESTAMP";
		}
	if ( $ip == DBOX3_IP )
		{
		$ok = true;
		$dboxstring = "DBOX3";
		$status_instance = DBOX3_STATUS;
		$timestamp_instance_online 	= "DBOX3.STATUS.ONLINE";
		$timestamp_instance 				= "DBOX3.STATUS.OFFLINE.TIMESTAMP";
		$timestamp_instance_diff 		= "DBOX3.STATUS.OFFLINE.TIMESTAMP.DIFF";
		$timestamp_instance_offline 	= "DBOX3.STATUS.ONLINE.TIMESTAMP";
		}
	if ( $ok == false )
	   return false;

 	$timestamp   =  time();

	$online 	= IPS_GetVariable(IPS_GetVariableID($timestamp_instance_online));
	$online_updated 	=	$online['VariableUpdated'];
	
	$diff = $timestamp - $online_updated;
	SetValueInteger($timestamp_instance_diff,$diff);
	SetValueInteger($timestamp_instance_offline,$diff);
	
	//print_r($timer);
	
	if ( $debug )echo "\n$dboxstring";
	//$timestamp =  GetValueInteger("LastTimer");
	
	
	$online_diff = ($timestamp - $online_updated)/60;
	
	$VarID = IPS_GetVariableID($status_instance);
   $bool = GetValueBoolean($VarID);
	$timestampoffline = GetValueInteger($timestamp_instance);
	$diff = $timestamp - $timestampoffline;
	
	
	
	if ( $debug )echo "-diff:$diff VARiD=$VarID-";

	$ok = false;
	
	if ( $bool == true OR $diff > 100 )
		{
		if ( $debug ) echo "\nping";
		$status = Sys_Ping($ip,1000);
		SetValueInteger($timestamp_instance,$timestamp);
		//$status = 1;
		if ( $debug ) echo "\nStatus:[$online_diff]-pingantwort = $status";

		$ok_old = GetValueBoolean($VarID);
		
		//if ( $ok_old == true ) echo "\nOK-old true= [$ok_old]";
		//if ( $ok_old == false ) echo "\nOK-old false= [$ok_old]";

		if ( $status == 1 )
		   {
		   //echo "-Status=1-$VarID";
		   if ( $ok_old == false )
		      {//echo "-Status=1";
				SetValueBoolean($VarID,true);
				
				}
			$ok = true;
			}
		else
		   {
         //echo "-Status=0-$VarID";
		   if ( $ok_old == true )
				{ //echo "-Status=0";
				SetValueBoolean($VarID,false);
				
				}
			$ok = false;
			}
		}
		   

	return $ok;
	
   }
//*************************************************************************

//*************************************************************************
// aktuelles Datum lesen
//*************************************************************************
function dbox_getdate($ip,$string,$debug)
   {
	$ok = false;
	$text = "";
	
	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;
	   
   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getdate");
	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;
	   
   }
//****************************************************************************

//*************************************************************************
// aktuelle Zeit lesen
//*************************************************************************
function dbox_gettime($ip,$string,$debug)
   {
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/gettime");
	if ( $debug )
	   echo "\n$text\n";
	   
	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************

//*************************************************************************
// Message auf DBox ausgeben
//*************************************************************************
function dbox_message($ip,$string,$debug)
   {
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/message?nmsg=$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************
//*************************************************************************
// Popup auf DBox ausgeben
//*************************************************************************
function dbox_popup($ip,$string)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/message?popup=$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************
//*************************************************************************
// DBox runterfahren
//*************************************************************************
function dbox_shutdown($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/shutdown");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************

//*************************************************************************
// DBox Timer auslesen
//*************************************************************************
function dbox_timer($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/timer");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************

//*************************************************************************
// DBox Alle Bouquets auslesen
//
//
//*************************************************************************
function dbox_getbouquets($ip,$string,$debug)
   {
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getbouquets");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************

//*************************************************************************
// DBox Alle Sender aus einem einzelnen Bouquet auslesen
//
//
//*************************************************************************
function dbox_getbouquet($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getbouquet?bouquet=$string&mode=TV");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************


//*************************************************************************
// DBox EPG auslesen
//
//*************************************************************************
function dbox_epg($ip,$string,$debug)
   {
   
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/epg?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************

//*************************************************************************
// DBox umschalten
//
//
//*************************************************************************
function dbox_zapto($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/zapto?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Kanalliste ausgeben
//
//
//*************************************************************************
function dbox_channellist($ip,$string,$debug)
   {

	$ok = false;
	$text = "";
	
	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/channellist");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Standby
//
//
//*************************************************************************
function dbox_standby($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/standby?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Volume
//
//
//*************************************************************************
function dbox_volume($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/volume?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Setmode
//
//
//*************************************************************************
function dbox_setmode($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/setmode?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Getmode
//
//
//*************************************************************************
function dbox_getmode($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getmode");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox Info
//
//
//*************************************************************************
function dbox_info($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/info?$string");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox bouquets.xml auslesen
//
//
//*************************************************************************
function dbox_getbouquetsxml($ip,$string,$debug)
   {
	
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getbouquetsxml");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox services.xml auslesen
//
//
//*************************************************************************
function dbox_getservicesxml($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, "http://$ip/control/getservicesxml");

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;


   }
//****************************************************************************

//*************************************************************************
// DBox LCD-Display ansteuern
//
//
//*************************************************************************
function dbox_lcd($ip,$string,$debug)
   {

	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

	$string = "http://$ip/control/lcd?$string";

   if (checkip($ip,"",0))
   	{
   	//echo "\nIP $ip OK";
   	//echo DBOX_INSTANCE;
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE, $string);

		if ( $debug )
			{
			echo "\n$string" ;
	   	echo "\n$text";
			}
		}
		
	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//****************************************************************************


//*************************************************************************
// Fernbedienung emulieren
//*************************************************************************
function dbox_rcem($ip,$string,$debug)
   {
	$ok = false;
	$text = "";

	$data = get_instance_dboxdata($ip);

	if ( $data == false )	return false;

	$string = "http://$ip/control/rcem?$string";
	echo $string ;
   if (checkip($ip,"",0))
   	$text = WWWReader_RetrievePage(DBOX_INSTANCE,$string );

	if ( $debug )
	   echo "\n$text\n";

	SetValue($data, $text);

	if ( $text == "" ) return false; else return true;

   }
//*************************************************************************


//******************************************************************************
// Bilder hochladen
//******************************************************************************
function dbox_upload($dbox,$file)
	{

	$debug = false;
	
	$ftp_server = $dbox;
	$benutzername = "root";
	$passwort = "";
	$lokale_datei = $file;
	$zieldatei = "/tmp/$file";

	if($debug) echo "\n$lokale_datei";
	
	// Die Verbindung herstellen
	$connection_id = ftp_connect($ftp_server);

	// Mit Benutzername und Kennwort anmelden
	$login_result = ftp_login($connection_id, $benutzername, $passwort);

	// �berpr�fen ob alles gutgegangen ist
	if ((!$connection_id) || (!$login_result))
		{
  		if($debug) echo "\nFtp-Verbindung nicht hergestellt!";
  		if($debug) echo "\nVerbindung mit ftp_server als Benutzer $benutzername nicht m�glich!";
  		die;
		}
	else
		{
  		if($debug) echo "\nVerbunden mit ftp_server als Benutzer $benutzername";
		}
		
	// Hochladen der datei

	chdir('C:\Programme\IP-SYMCON2\media');
	//echo  getcwd();

	// turn passive mode on
	ftp_pasv($connection_id, true);


	$upload = ftp_put($connection_id, $zieldatei, 'ips1007.png', FTP_BINARY);
	
	// Upload-Status �berpr�fen
	if (!$upload)
		{
  		if($debug) echo "\nFtp upload war fehlerhaft!";
		}
	else
		{
  		if($debug) echo "\nDatei $lokale_datei auf $dbox als $zieldatei geschrieben";
		}

	// Schlie�en der Verbindung
	ftp_quit($connection_id);

	}
	
//******************************************************************************

?>