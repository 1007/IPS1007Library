<?

  // Profile definieren
  
	define("PROFIL_NULL_MODUS"		,	0);
	define("PROFIL_FRUEHSCHICHT"	,	1);
	define("PROFIL_SPAETSCHICHT"	,	2);
	define("PROFIL_NACHTSCHICHT"	,	3);
	define("PROFIL_NORMALSCHICHT"	,	4);
	define("PROFIL_WOCHENENDE"		,	5);
	define("PROFIL_URLAUB"			,	6);
	define("PROFIL_ANWESEND"		,	7);
	define("PROFIL_ABWESEND"		,	8);



function get_profil_string($profil)
   {
   $string = "";

   if ( $profil == PROFIL_NULL ) 			$string = "NULL_MODUS";
   if ( $profil == PROFIL_FRUEHSCHICHT ) 	$string = "FRUEHSCHICHT";
   if ( $profil == PROFIL_SPAETSCHICHT ) 	$string = "SPAETSCHICHT";
   if ( $profil == PROFIL_NACHTSCHICHT ) 	$string = "NACHTSCHICHT";
   if ( $profil == PROFIL_NORMALSCHICHT ) $string = "NORMALSCHICHT";
   if ( $profil == PROFIL_WOCHENENDE ) 	$string = "WOCHENENDE";
   if ( $profil == PROFIL_URLAUB ) 			$string = "URLAUB";
   if ( $profil == PROFIL_ANWESEND ) 		$string = "ANWESEND";
   if ( $profil == PROFIL_ABWESEND ) 		$string = "ABWESEND";


   return $string;
   }


?>