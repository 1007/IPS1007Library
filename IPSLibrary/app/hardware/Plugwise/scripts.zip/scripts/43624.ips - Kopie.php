<?

	$debug = false;
	
	
	//return;
	
 	$instr=GetValueString("Buffer");

	$laenge = strlen($instr);

	if ( $debug )
		{
		$datenstr="";
		echo "\n$instr";

		for($i=0; $i<strlen($instr); $i++) {
 			$datenstr.=strtoupper(ord($instr{$i}))." ";
    		}

		{echo "\nLaenge:$laenge";echo "\n$datenstr";}
	   }
	   

	if ( $laenge == 80 )
	   packet_group_100($instr);
	   
	// Stream
	if (ord($instr[0]) == 19 )
	   {
	   //Checksumme testen
	   $checksumme = 0;
	   for($x=0;$x<$laenge;$x++)
	      {
	      $checksumme = $checksumme + ord($instr[$x]);
			}
		// Wenn Checksumme 256 dann OK
		// Fehler in OI Doku - 19 muss mitgezaehlt werden
		if ( $checksumme == 256 )
		   {
			$anzahl = ord($instr[1]);  // Anzahl der Bytes
		   $zeiger = 0;
		   if ($debug) echo "\nAnzahl:$anzahl";
			// Stream zerlegen
			while ( $zeiger < $anzahl )
				{
				$Byte = "";
				$ok = false;
  				$opcode =  ord($instr[$zeiger+2]);
  				switch($opcode)
  				   {
  				   case 52:    $Byte = array($instr[$zeiger+2+1]);
  				   				$zeiger = $zeiger + 2;
  				               $ok = true;
  				               packet_52($Byte);
					  				break;
  				   case 53:    $Byte = array($instr[$zeiger+2+1]);
  				   				$zeiger = $zeiger + 2;
  				               $ok = true;
  				               packet_53($Byte);
					  				break;
  				   default:    echo "\nUnknown Opcode[$opcode] raus";
  				               
  				               break;
  				   }
				if ( !$ok ) break;
			
				}
			// Stream zerlegen Ende
		   }
		else
			if ($debug) echo "\nChecksumme:$checksumme NOK";
	   }



function packet_52($Byte)
	{
	//Packet ID: 52	Infrared Character Left"
	$b1 = u_0bis255(52,$Byte[0]);
	SetValueInteger("Infrared Character Left",$b1);
	}
	
function packet_53($Byte)
	{
	//Packet ID: 53	Infrared Character Right
	$b1 = u_0bis255(53,$Byte[0]);
	SetValueInteger("Infrared Character Right",$b1);
	}
	


	   
//******************************************************************************
// Achtung kann nicht als Stream aufgerufen werden da zu lang bei 19200 Baud
//******************************************************************************
function packet_group_100($Byte)
	{
	$debug = false;

	//BYTE 0		   Packet ID: 7	Bumps and Wheel Drops
	$b1 = u_0bis255(7,$Byte[0]);
	SetValueInteger("Bumps and Wheel Drops",$b1);
	if ( ($b1 & 1) == 1 ) SetValueBoolean("Bumps and Wheel Drops Bump Right",true); else SetValueBoolean("Bumps and Wheel Drops Bump Right",false);
	if ( ($b1 & 2) == 2 ) SetValueBoolean("Bumps and Wheel Drops Bump Left",true); else SetValueBoolean("Bumps and Wheel Drops Bump Left",false);
	if ( ($b1 & 4) == 4 ) SetValueBoolean("Bumps and Wheel Drops Wheel Drop Right",true); else SetValueBoolean("Bumps and Wheel Drops Wheel Drop Right",false);
	if ( ($b1 & 8) == 8 ) SetValueBoolean("Bumps and Wheel Drops Wheel Drop Left",true); else SetValueBoolean("Bumps and Wheel Drops Wheel Drop Left",false);

	//BYTE 1       Packet ID: 8	Wall
	$b1 = u_0bis1(8,$Byte[1]);
	SetValueBoolean("Wall",$b1);

	//BYTE 2       Packet ID: 9	Cliff Left
	$b1 = u_0bis1(9,$Byte[2]);
	SetValueBoolean("Cliff Left",$b1);

	//BYTE 3       Packet ID: 10	Cliff Front Left
	$b1 = u_0bis1(10,$Byte[3]);
	SetValueBoolean("Cliff Front Left",$b1);

	//BYTE 4       Packet ID: 11	Cliff Front Right
	$b1 = u_0bis1(11,$Byte[4]);
	SetValueBoolean("Cliff Front Right",$b1);

	//BYTE 5       Packet ID: 12	Cliff Right
	$b1 = u_0bis1(12,$Byte[5]);
	SetValueBoolean("Cliff Right",$b1);

	//BYTE 6       Packet ID: 13	Virtual Wall
	$b1 = u_0bis1(13,$Byte[6]);
	SetValueBoolean("Virtual Wall",$b1);

	//BYTE 7       Packet ID: 14	Wheel Overcurrents
	$b1 = u_0bis255(14,$Byte[7]);
	SetValueInteger("Wheel Overcurrents",$b1);
	if ( ($b1 & 1) == 1 ) SetValueBoolean("Wheel Overcurrents Side Brush",true); else SetValueBoolean("Wheel Overcurrents Side Brush",false);
	if ( ($b1 & 4) == 4 ) SetValueBoolean("Wheel Overcurrents Main Brush",true); else SetValueBoolean("Wheel Overcurrents Main Brush",false);
	if ( ($b1 & 8) == 8 ) SetValueBoolean("Wheel Overcurrents Right Wheel",true); else SetValueBoolean("Wheel Overcurrents Right Wheel",false);
	if ( ($b1 &16) ==16 ) SetValueBoolean("Wheel Overcurrents Left Wheel",true); else SetValueBoolean("Wheel Overcurrents Left Wheel",false);

	//BYTE 8       Packet ID: 15	Schmutzsensor
	$b1 = u_0bis255(15,$Byte[8]);
	SetValueInteger("Dirt Detect",$b1);

	//BYTE 9       Packet ID: 16	Unused
	$b1 = u_0bis255(16,$Byte[9]);

	//BYTE 10  	   Packet ID: 17	Infrared Character Omni
	$b1 = u_0bis255(17,$Byte[10]);
	SetValueInteger("Infrared Character Omni",$b1);

	//BYTE 11      Packet ID: 18	Buttons
	$b1 = u_0bis255(18,$Byte[11]);
	SetValueInteger("Buttons",$b1);
	if ( ($b1 & 1) == 1 ) SetValueBoolean("Buttons Clean",true); else SetValueBoolean("Buttons Clean",false);
	if ( ($b1 & 2) == 2 ) SetValueBoolean("Buttons Spot",true); else SetValueBoolean("Buttons Spot",false);
	if ( ($b1 & 4) == 4 ) SetValueBoolean("Buttons Dock",true); else SetValueBoolean("Buttons Dock",false);
	if ( ($b1 & 8) == 8 ) SetValueBoolean("Buttons Minute",true); else SetValueBoolean("Buttons Minute",false);
	if ( ($b1 &16) ==16 ) SetValueBoolean("Buttons Hour",true); else SetValueBoolean("Buttons Hour",false);
	if ( ($b1 &32) ==32 ) SetValueBoolean("Buttons Day",true); else SetValueBoolean("Buttons Day",false);
	if ( ($b1 &64) ==64 ) SetValueBoolean("Buttons Schedule",true); else SetValueBoolean("Buttons Schedule",false);
	if ( ($b1 &128)==128) SetValueBoolean("Buttons Clock",true); else SetValueBoolean("Buttons Clock",false);

	//BYTE 12-13	Packet ID: 19	Distanz
	$b1 = u_32768bis32767(20,$Byte[12],$Byte[13]);
	SetValueInteger("Distance", $b1);

	//BYTE 14-15	Packet ID: 20	Winkel
	$b1 = u_32768bis32767(20,$Byte[14],$Byte[15]);
	SetValueInteger("Angle", $b1);

	//BYTE 16    	Packet ID: 21	Ladestatus
	$b1 = u_0bis255(21,$Byte[16]);
	SetValueInteger("Charging State",$b1);
	if ( $b1 == 0 ) SetValueBoolean("Charging State Not Charging",true); else SetValueBoolean("Charging State Not Charging",false);
	if ( $b1 == 1 ) SetValueBoolean("Charging State Reconditioning Charging",true); else SetValueBoolean("Charging State Reconditioning Charging",false);
	if ( $b1 == 2 ) SetValueBoolean("Charging State Full Charging",true); else SetValueBoolean("Charging State Full Charging",false);
	if ( $b1 == 3 ) SetValueBoolean("Charging State Trickle Charging",true); else SetValueBoolean("Charging State Trickle Charging",false);
	if ( $b1 == 4 ) SetValueBoolean("Charging State Waiting",true); else SetValueBoolean("Charging State Waiting",false);
	if ( $b1 == 5 ) SetValueBoolean("Charging State Charging Fault Condition",true); else SetValueBoolean("Charging State Charging Fault Condition",false);

	//BYTE 17-18	Packet ID: 22	Batteriespannung
	$b1 = u_0bis65535(23,$Byte[17],$Byte[18]);
	SetValueInteger("Voltage", $b1);
	
	//BYTE 19-20	Packet ID: 23	Batteriestrom
	$b1 = u_32768bis32767(23,$Byte[19],$Byte[20]);
	SetValueInteger("Current", $b1);

	//BYTE 21		Packet ID: 24	Batterietemperatur
	$b1 = u_128bis127(24,$Byte[21]);
	SetValueInteger("Temperatur", $b1);

	//BYTE 22-23	Packet ID: 25	Batterieaufladung
	$b1 = u_0bis65535(25,$Byte[22],$Byte[23]);
	SetValueInteger("Battery Charge", $b1);

	//BYTE 24-25	Packet ID: 26	Batteriekapazitaet
	$b1 = u_0bis65535(26,$Byte[24],$Byte[25]);
	SetValueInteger("Battery Capacity", $b1);

	//BYTE 26-27	Packet ID: 27	Wall Signal
	$b1 = u_0bis65535(27,$Byte[26],$Byte[27]);
	SetValueInteger("Wall Signal", $b1);

	//BYTE 28-29   Packet ID: 28	Cliff Left Signal
	$b1 = u_0bis65535(28,$Byte[28],$Byte[29]);
	SetValueInteger("Cliff Left Signal", $b1);

	//BYTE 30-31   Packet ID: 29	Cliff Front Left Signal
	$b1 = u_0bis65535(29,$Byte[30],$Byte[31]);
	SetValueInteger("Cliff Front Left Signal", $b1);

	//BYTE 32-33   Packet ID: 30	Cliff Front Right Signal
	$b1 = u_0bis65535(30,$Byte[32],$Byte[33]);
	SetValueInteger("Cliff Front Right Signal", $b1);

	//BYTE 34-35   Packet ID: 31	Cliff Right Signal
	$b1 = u_0bis65535(31,$Byte[34],$Byte[35]);
	SetValueInteger("Cliff Right Signal", $b1);

	//BYTE 36-38   Packet ID: 32-33	Unused
	
	//BYTE 39      Packet ID: 34	Ladequelle
	$b1 = u_0bis255(34,$Byte[39]);
	SetValueInteger("Charging Sources Available",$b1);
	if ( ($b1 & 1) == 1 ) SetValueBoolean("Charging Sources Available Internal Charger",true); else SetValueBoolean("Charging Sources Available Internal Charger",false);
	if ( ($b1 & 2) == 2 ) SetValueBoolean("Charging Sources Available Home Base",true); else SetValueBoolean("Charging Sources Available Home Base",false);

	//BYTE 40      Packet ID: 35	OI Mode
	$b1 = u_0bis255(35,$Byte[40]);
	SetValueInteger("OI Mode",$b1);
	if ( $b1 == 0 ) SetValueBoolean("OI Mode Off",true); else SetValueBoolean("OI Mode Off",false);
	if ( $b1 == 1 ) SetValueBoolean("OI Mode Passive",true); else SetValueBoolean("OI Mode Passive",false);
	if ( $b1 == 2 ) SetValueBoolean("OI Mode Safe",true); else SetValueBoolean("OI Mode Safe",false);
	if ( $b1 == 3 ) SetValueBoolean("OI Mode Full",true); else SetValueBoolean("OI Mode Full",false);

	//BYTE 41      Packet ID: 36	Lied Nummer
	$b1 = u_0bis255(36,$Byte[41]);
	SetValueInteger("Song Number",$b1);

	//BYTE 42      Packet ID: 37	Lied
	$b1 = u_0bis255(37,$Byte[42]);
	SetValueInteger("Song Playing",$b1);

	//BYTE 43      Packet ID: 38	Anzahl Stream Pakete
	$b1 = u_0bis255(38,$Byte[43]);
	SetValueInteger("Number of Stream Packets",$b1);

	//BYTE 44-45   Packet ID: 39	Request Velocity
	$b1 = u_32768bis32767(39,$Byte[44],$Byte[45]);
	SetValueInteger("Requested Velocity", $b1);

	//BYTE 46-47   Packet ID: 40	Request Radius
	$b1 = u_32768bis32767(40,$Byte[46],$Byte[47]);
	SetValueInteger("Requested Radius", $b1);

	//BYTE 48-49   Packet ID: 41	Request Right Velocity
	$b1 = u_32768bis32767(41,$Byte[48],$Byte[49]);
	SetValueInteger("Requested Right Velocity", $b1);

	//BYTE 50-51   Packet ID: 42	Request Left Velocity
	$b1 = u_32768bis32767(42,$Byte[50],$Byte[51]);
	SetValueInteger("Requested Left Velocity", $b1);

   //BYTE 52-53   Packet ID: 43	Right Encoder Counts
	$b1 = u_0bis65535(43,$Byte[52],$Byte[53]);
	SetValueInteger("Right Encoder Counts", $b1);

   //BYTE 54-55   Packet ID: 44	Left Encoder Counts
	$b1 = u_0bis65535(44,$Byte[54],$Byte[55]);
	SetValueInteger("Left Encoder Counts", $b1);

	//BYTE 56      Packet ID: 45	Light Bumper
	$b1 = u_0bis255(45,$Byte[56]);
	SetValueInteger("Light Bumper",$b1);
	if ( ($b1 & 1) == 1 ) SetValueBoolean("Light Bumper Left",true); else SetValueBoolean("Light Bumper Left",false);
	if ( ($b1 & 2) == 2 ) SetValueBoolean("Light Bumper Front Left",true); else SetValueBoolean("Light Bumper Front Left",false);
	if ( ($b1 & 4) == 4 ) SetValueBoolean("Light Bumper Center Left",true); else SetValueBoolean("Light Bumper Center Left",false);
	if ( ($b1 & 8) == 8 ) SetValueBoolean("Light Bumper Center Right",true); else SetValueBoolean("Light Bumper Center Right",false);
	if ( ($b1 &16) ==16 ) SetValueBoolean("Light Bumper Front Right",true); else SetValueBoolean("Light Bumper Front Right",false);
	if ( ($b1 &32) ==32 ) SetValueBoolean("Light Bumper Right",true); else SetValueBoolean("Light Bumper Right",false);

	//BYTE 57-58   Packet ID: 46	Light Bump Left Signal
	$b1 = u_0bis65535(46,$Byte[57],$Byte[58]);
	SetValueInteger("Light Bump Left Signal", $b1);

	//BYTE 59-60   Packet ID: 47	Light Bump Front Left Signal
	$b1 = u_0bis65535(47,$Byte[59],$Byte[60]);
	SetValueInteger("Light Bump Front Left Signal", $b1);

	//BYTE 61-62   Packet ID: 48	Light Bump Center Left Signal
	$b1 = u_0bis65535(48,$Byte[61],$Byte[62]);
	SetValueInteger("Light Bump Center Left Signal", $b1);

	//BYTE 63-64   Packet ID: 49	Light Bump Center Right Signal
	$b1 = u_0bis65535(49,$Byte[63],$Byte[64]);
	SetValueInteger("Light Bump Center Right Signal", $b1);

	//BYTE 65-66   Packet ID: 50	Light Bump Front Right Signal
	$b1 = u_0bis65535(50,$Byte[65],$Byte[66]);
	SetValueInteger("Light Bump Front Right Signal", $b1);

	//BYTE 67-68   Packet ID: 51	Light Bump Right Signal
	$b1 = u_0bis65535(51,$Byte[67],$Byte[68]);
	SetValueInteger("Light Bump Right Signal", $b1);

	//BYTE 69  	   Packet ID: 52	Infrared Character Left
	$b1 = u_0bis255(52,$Byte[69]);
	SetValueInteger("Infrared Character Left",$b1);

	//BYTE 70      Packet ID: 53	Infrared Character Right
	$b1 = u_0bis255(53,$Byte[70]);
	SetValueInteger("Infrared Character Right",$b1);

	//BYTE 71-72  	Packet ID: 54	Left Motor Current
	$b1 = u_32768bis32767(54,$Byte[71],$Byte[72]);
	SetValueInteger("Left Motor Current", $b1);

	//BYTE 73-74  	Packet ID: 55	Right Motor Current
	$b1 = u_32768bis32767(55,$Byte[73],$Byte[74]);
	SetValueInteger("Right Motor Current", $b1);

	//BYTE 75-76  	Packet ID: 56	Main Brush Motor Current
	$b1 = u_32768bis32767(56,$Byte[75],$Byte[76]);
	SetValueInteger("Main Brush Motor Current", $b1);

	//BYTE 77-78  	Packet ID: 57	Side Brush Motor Current
	$b1 = u_32768bis32767(57,$Byte[77],$Byte[78]);
	SetValueInteger("Side Brush Motor Current", $b1);

	//BYTE 79      Packet ID: 58	Stasis
	$b1 = u_0bis1(58,$Byte[79]);
	SetValueBoolean("Stasis",$b1);

	}



function u_0bis65535($id,$b1,$b2)
	{
	$b1 = ord($b1);$b2 = ord($b2);
	$b1 = $b2 + $b1*256;
	return $b1;
	}
function u_32768bis32767($id,$b1,$b2)
	{
	$b1 = ord($b1);$b2 = ord($b2);
	if ( $b1 & 128 )$b1 = ($b1 & 127)-128;
	$b1 = $b2 + $b1*256;
	return $b1;
	}
function u_128bis127($id,$b1)
	{
	$b1 = ord($b1);
	if ( $b1 & 128 ){$b1 = ($b1 & 127)-128; echo $b1;}
	return $b1;
	}
function u_0bis255($id,$b1)
	{
	$b1 = ord($b1);
	return $b1;
	}
function u_0bis1($id,$b1)
	{
	$b1 = ord($b1);
	if ( $b1 == 1 )
	   $b1 = true;
	else
	   $b1 = false;
	return $b1;
	}
	
?>