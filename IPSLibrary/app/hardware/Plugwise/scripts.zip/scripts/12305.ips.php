<?

define("StartDateiName", "..\start.iwd"); //Dateiname fr Start Datei definieren
define("StopDateiName", "..\stop.iwd"); //Dateiname fr Stop Datei definieren

//erst mal alle Dateileichen lschen
@unlink (StartDateiName);
@unlink (StopDateiName);

$inhalt = date("d.m.y - H:i");
$datei = fopen(StopDateiName, "a");
fwrite ($datei, $inhalt);
fclose($datei);



?>