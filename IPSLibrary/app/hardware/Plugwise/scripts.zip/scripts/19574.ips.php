<?
	$root = 35923;

	$obj  = IPS_GetObject($root);

	//print_r($obj);

	for ( $x=0;$x<count($obj['ChildrenIDs']);$x++)
	   { echo "<br>" . $x;
	   //print_r(IPS_GetObject($obj['ChildrenIDs'][$x]));
	   }

	$s = "<style type='text/css'>";
	$s = $s . "table.test { width: 100%; border-collapse: true;}";
	$s = $s . "Test { border: 1px solid #444455; }</style>";
	$s = $s . "<table class='test'>";

	for ( $x=0;$x<count($obj['ChildrenIDs']);$x++)
		{ echo "<br>" . $x;
		$id = $obj['ChildrenIDs'][$x]; echo "<br>" . $id ;
		$subobj = IPS_GetObject($id);
		//print_r($subobj);
		$name = $subobj['ObjectName']; 
		$icon = $subobj['ObjectIcon']; 
		
		$icon1 = "<img src='./img/icons/".$icon.".png'>";

		echo "--".$icon1."--" ;
		
		$s = $s . "<tr>";
		$s = $s . "<td style='background: #223344;' colspan='2'>".$name."</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'><h4>$name</td>";
		$s = $s . "<td style='background: #223344;' colspan='2'>$icon1</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'>$name</td>";
		$s = $s . "<td style='background: #223344;' colspan='2'>$name</td>";
		$s = $s . "<td style='background: #774477;' colspan='2'>IP-Symcon</td>";
		$s = $s . "</tr>";
		$s = $s . "<tr>";
		}

	SetValueString(18594,$s);

	WFC_SwitchPage(40525,"root");

?>