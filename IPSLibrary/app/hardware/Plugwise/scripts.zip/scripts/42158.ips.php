<?

 	//Start writing your scripts between the brackets
	define (COM8 , 55153);
	define (COM7 , 58653);

	define ('CR',chr(13));

	COMPort_SendText(COM7,"#ZF 5".CR );
	COMPort_SendText(COM8,"#ZF 5".CR );

	COMPort_SendText(COM7,"#ZZ 1,1".CR);
	COMPort_SendText(COM8,"#ZZ 1,1".CR);

	$tag 	= 	date("d.m.Y");
	$zeit =  date("H:i:s");

	COMPort_SendText(COM7, "#ZL,5,2,".$tag.CR);
	COMPort_SendText(COM8, "#ZL,5,2,".$tag.CR);

	COMPort_SendText(COM7, "#ZR,335,2,".$zeit.CR);
	COMPort_SendText(COM8, "#ZR,335,2,".$zeit.CR);


   $s  = IPS_GetScript(IPS_GetScriptID("edip_refresh"));
   require_once($s['ScriptFile']);




?>