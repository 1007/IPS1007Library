<?

 	$remoteRepository = 'https://raw.github.com/1007/IPSLibrary/Informationen/';
 	$component = 'WithingsInfo';

	IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
	$moduleManager = new IPSModuleManager($component,$remoteRepository);
	$moduleManager->LoadModule($remoteRepository);

?>