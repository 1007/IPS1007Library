<?

	if( $_IPS['EVENT'] == 50914 )
		echo "test";

?>