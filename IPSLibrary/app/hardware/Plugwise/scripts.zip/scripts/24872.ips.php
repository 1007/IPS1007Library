<?

//Hier bitte die ID der RGBW-Instanz �ndern!!
$id                 =     33146;





        $Rot = 25;
        $Zeit_Rot = 10;

        $Gruen = 0;
        $Zeit_Gruen = 10;

        $Blau = 0;
        $Zeit_Blau = 10;

    PJ_DimRGBW($id,$Rot,$Zeit_Rot,$Gruen,$Zeit_Gruen,$Blau,$Zeit_Blau,0,0);
    PJ_RunProgram($id,6);
?>