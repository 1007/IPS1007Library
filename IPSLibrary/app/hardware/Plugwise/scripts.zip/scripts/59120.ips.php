<?


	IPS_Execute("C:\Programme\IP-SYMCON2\elostart.bat","",false,false);


?>