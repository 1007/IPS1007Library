<?

require_once("class.bahn.php"); // Klasse einbinden

//Ab hier nichts mehr �ndern
$object = IPS_GetObject($IPS_SELF);
$parentID = $object['ParentID'];

// abfragenamen ver�ndern
//IPS_SetName($parentID, "Bahnverbindung von ".date("H:i",time()));

// Neue Instanz
//Parameter 1 ist der Bahnhof oder die Haltestelle
//(es muss kein Bahnhof sein, Bushaltestelle gehen auch)
// Parameter 2 ist die Art der Tafel: "Abfahrt" oder "Ankunft"
// TODO: Anpassen
$bahn=new bahn("R�sselsheim Bahnhof","Abfahrt");


// Hier werden Verkehrsmittel ausgeschlossen
/*
$bahn->TypeBUS(false);
$bahn->TypeTRAM(false);
$bahn->TypeICE(false);
$bahn->TypeIC(false);
$bahn->TypeRE(false);
$bahn->TypeSBAHN(false);
$bahn->TypeUBAHN(false);
$bahn->TypeFAEHRE(false);
*/

// Hier werden Datum und Zeit gesetzt.
// Werden die nicht gesetzt wird die/das aktuelle Zeit/Datum genommen
/*
$bahn->datum("17.5.2010");
$bahn->zeit("1:00");
*/

// Jetzt das Ergebniss holen!
$abfragestatus=$bahn->fetch();
if($abfragestatus){
    // Array mit den Informationen ausgeben:
    //print_r($bahn->timetable);
    // TODO: Anpassen
    AnzeigeAufbereiten($bahn,"R�sselsheim Bahnhof",$parentID,20);
}

// zweite Anzeigentafel
// TODO: Anpassen
$bahn=new bahn("Boellenseeplatz","Abfahrt");
$abfragestatus=$bahn->fetch();
if($abfragestatus){
    // Array mit den Informationen ausgeben:
    print_r($bahn->timetable);
    // TODO: Anpassen
    AnzeigeAufbereiten($bahn,"Ankunft Lehrte",$parentID,0);
}

// anzeige aufbereiten in eine html box
// $bahn - ergebnis der class.bahn.php
// $name - Variablen Bezeichnung. Muss f�r ein Object identisch sein
// $parentID - oberklasse oder dummy object id
// $wegezeit - eine wegezeit in minuten zum bahnhof. oder =0
function AnzeigeAufbereiten($bahn, $name,$parentID, $wegezeit)
{
    $VARIABLEN_TEXT=$name;
    $WEGEZEIT = $wegezeit; //in minuten, wenn 0 dann nicht farblich markieren

    // Anzeige aufbereiten
    $str = "<table width='90%' align='center'>"; // Farbe anpassen oder style entfernen
    $str .= "<tr><td></td><td><b>Zug</b></td><td><b>Zeit</b></td><td><b>Diff.</b></td><td><b>Richtung</b></td><td><b>Gleis</b></td><td><b>Aktuelles</b></td></tr>";

    $pos = 0;
    for($i=0; $i<sizeof($bahn->timetable); $i++)
    {
        //$eintrag = explode(";", $bahn->timetable[$i]);
        $caller = $bahn->timetable[$i]["type"];
        switch($caller) {
           case "SBAHN":
              $eintrag[0] = "<img src=/user/bahn/sbahn_24x24.gif>";
              break;
           case "BUS":
              $eintrag[0] = "<img src=/user/bahn/bus_24x24.gif>";
              break;
           case "RE":
              $eintrag[0] = "<img src=/user/bahn/re_24x24.gif>";
              break;
           case "ICE":
              $eintrag[0] = "<img src=/user/bahn/ice_24x24.gif>";
              break;
           case "TRAM":
              $eintrag[0] = "<img src=/user/bahn/tram_24x24.gif>";
              break;
            default:
               $eintrag[0] = "";
               break;
        }
        $colour="white"; // yellow or red, white ist der normalfall
        $eintrag[1] = $bahn->timetable[$i]["train"];
        $eintrag[2] = $bahn->timetable[$i]["time"];

        // differenz zur aktuellen zeit ausrechnen.
        $timestampField = strtotime($bahn->timetable[$i]["time"]);
        $timestampNow = time();//+1*60*60;
        //echo date("H:i",$timestampNow)."-";
        //echo date("H:i",$timestampField)."/";

        $diff = $timestampField - $timestampNow;
        //echo $diff." * ";
        if ($diff >0)
        {
            $eintrag[3] = $uhrzeit = date("H:i",$diff-1*60*60);
            if ($diff > $WEGEZEIT*60)
            {
               $colour="white";
               // einfach keine farbe definieren
            }
            else
            {
               $colour="yellow";
               $eintrag[3]="<font color='#FFFF00'>".$eintrag[3];
            }
        }
        else
        {
          // nicht mehr zu schaffen da zeit abgelaufen
          $eintrag[3] = "--:--";
          if ($WEGEZEIT <>0)
              $eintrag[3]="<font color='#FF0000'>".$eintrag[3];
        }
        $eintrag[4] = $bahn->timetable[$i]["route_ziel"];
        $eintrag[5] = $bahn->timetable[$i]["platform"];
        $eintrag[6] = $bahn->timetable[$i]["ris"];

            $str .= "<tr>";
            foreach($eintrag as $data)
                $str .= '<td>'.$data.'</td>';
            $str .= "</tr>";

            $pos++;

        if($pos >= 6)
            break;
    }
    $str .= "</table>";

    $vid = CreateVariableByName($parentID, $VARIABLEN_TEXT, 3);
    IPS_SetIcon($vid, "Distance");
    IPS_SetVariableCustomProfile($vid, "~HTMLBox");
    SetValue($vid, $str);
}

function CreateVariableByName($id, $name, $type)
{
    global $IPS_SELF;
    $vid = @IPS_GetVariableIDByName($name, $id);
    if($vid === false)
    {
        $vid = IPS_CreateVariable($type);
        IPS_SetParent($vid, $id);
        IPS_SetName($vid, $name);
        IPS_SetInfo($vid, "this variable was created by script #$IPS_SELF");
    }
    return $vid;
}


?>