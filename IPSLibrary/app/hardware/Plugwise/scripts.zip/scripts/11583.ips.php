<?

// Installation:
//1. Bei $LEDid die ID der RGBW-868 Instanz eintragen.
//2. Script mit dem Aus�hren-Button oder Runscript starten.
//3. Alles so sch�n bunt hier!

//An-Ausschalten mit:
//1. "Ausf�hren" Button im Editor oder
//2. IPS_runscript (diese Script-ID) oder
//3. direktes �ndern der Variablen "Aktiv" auf true oder false


$LEDid=33146;
$fade=7; //Fadetime / Zeit bis zur n�chsten Farbe in Sek.

if(($IPS_SENDER == "Runscript")or($IPS_SENDER == "Execute")){
   $aktivid = @IPS_GetVariableIDByName("Aktiv", $IPS_SELF);
   if($aktivid===false) {
      $aktivid = IPS_CreateVariable(0);
      IPS_SetParent($aktivid, $IPS_SELF);
      IPS_SetName($aktivid, "Aktiv");
   }
    $eid = @IPS_GetEventIDByName("Aktiv-Event", $IPS_SELF);
   if($eid===false) {
      $eid = IPS_CreateEvent(0);
      IPS_SetEventTrigger($eid, 1, $aktivid);
      IPS_SetParent($eid, $IPS_SELF);
      IPS_SetName($eid, "Aktiv-Event");
      IPS_SetEventActive($eid, true);
   }
   SetValue ($aktivid, (GetValue($aktivid) ? false:true));
    }

if($IPS_SENDER == "Variable")    {
   $aktivid = @IPS_GetVariableIDByName("Aktiv", $IPS_SELF);
   $aktiv=GetValue($aktivid);
    if($aktiv){
       IPS_SetScriptTimer($IPS_SELF, 1);
        }
    else{
       IPS_SetScriptTimer($IPS_SELF, 0);
       PJ_DimRGBW($LEDid,0,0,0,0,0,0,0,0);
       }
    }

if($IPS_SENDER == "TimerEvent"){
    $rot=rand(0,255);$gruen=rand(0,255);$blau=rand(0,255);
    PJ_DimRGBW($LEDid,$rot,$fade,$gruen,$fade,$blau,$fade,0,0);
    IPS_SetScriptTimer($IPS_SELF, $fade);
    }

?>