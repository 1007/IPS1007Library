<?

   $script = IPS_GetScriptID("Funcpool.Raumdefinitionen");
	require_once "$script.ips.php";

   $script = IPS_GetScriptID("Funcpool.Profildefinitionen");
	require_once "$script.ips.php";

//							Profile		Raum	Uhrzeit		Temperatur res res
$t_daten  = array(
				//	PROFILE FRUEHSCHICHT
				 0  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"00:00",	10.1,	0,	0),
 				 1  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"05:05",	10.1,	0,	0),
  				 2  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"22:00",	10.2,	0,	0),
  				 5  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"00:00",	12.1,	0,	0),
 				 6  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"08:05",	18.1,	0,	0),
  				 7  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"19:00",	12.1,	0,	0),
  				10  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"00:00",	12.1,	0,	0),
 				11  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"04:15",	23.0,	0,	0),
  				12  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"05:05",	13.1,	0,	0),
  				13  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"15:00",	20.1,	0,	0),
				14  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"21:00",	13.1,	0,	0),
				15  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"21:00",	13.1,	0,	0),
				16  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"21:00",	13.1,	0,	0),

  				//	PROFILE SPAETSCHICHT
				20   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"00:00",	10.2,	0,	0),
 				21   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"16:05",	10.2,	0,	0),
  				22   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"19:00",	10.2,	0,	0),
  				25   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"00:00",	12.2,	0,	0),
 				26   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"09:05",	15.2,	0,	0),
  				27   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"12:00",	12.2,	0,	0),
  				30   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"00:00",	22.0,	0,	0),
 				31   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"01:00",	12.0,	0,	0),
  				32   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"08:00",	22.2,	0,	0),
				33   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"12:00",	12.3,	0,	0),
				34   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"22:00",	22.3,	0,	0),


  				//	PROFILE NACHTSCHICHT
				40  => array(PROFIL_NACHTSCHICHT,RAUM_BAD,		"00:00",	10.3,	0,	0),
 				41  => array(PROFIL_NACHTSCHICHT,RAUM_BAD,		"16:05",	10.3,	0,	0),
  				42  => array(PROFIL_NACHTSCHICHT,RAUM_BAD,		"19:00",	10.3,	0,	0),
  				45  => array(PROFIL_NACHTSCHICHT,RAUM_WOHNEN,	"00:00",	12.3,	0,	0),
 				46  => array(PROFIL_NACHTSCHICHT,RAUM_WOHNEN,	"16:05",	15.3,	0,	0),
  				47  => array(PROFIL_NACHTSCHICHT,RAUM_WOHNEN,	"19:00",	12.3,	0,	0),
  				50  => array(PROFIL_NACHTSCHICHT,RAUM_ARBEIT,	"00:00",	12.3,	0,	0),
 				51  => array(PROFIL_NACHTSCHICHT,RAUM_ARBEIT,	"16:05",	17.3,	0,	0),
  				52  => array(PROFIL_NACHTSCHICHT,RAUM_ARBEIT,	"19:00",	12.3,	0,	0),

				//	PROFILE NORMALSCHICHT
				60  => array(PROFIL_NORMALSCHICHT,RAUM_BAD,		"00:00",	10.4,	0,	0),
 				61  => array(PROFIL_NORMALSCHICHT,RAUM_BAD,		"04:10",	10.4,	0,	0),
  				62  => array(PROFIL_NORMALSCHICHT,RAUM_BAD,		"04:30",	10.4,	0,	0),
  				65  => array(PROFIL_NORMALSCHICHT,RAUM_WOHNEN,	"00:00",	12.4,	0,	0),
 				66  => array(PROFIL_NORMALSCHICHT,RAUM_WOHNEN,	"16:05",	15.4,	0,	0),
  				67  => array(PROFIL_NORMALSCHICHT,RAUM_WOHNEN,	"19:00",	12.4,	0,	0),
  				70  => array(PROFIL_NORMALSCHICHT,RAUM_ARBEIT,	"00:00",	12.4,	0,	0),
 				71  => array(PROFIL_NORMALSCHICHT,RAUM_ARBEIT,	"16:05",	17.4,	0,	0),
  				72  => array(PROFIL_NORMALSCHICHT,RAUM_ARBEIT,	"19:00",	12.4,	0,	0),

 				//	PROFILE WOCHENENDE
				100 => array(PROFIL_WOCHENENDE,RAUM_BAD,		   "00:01",	10.0,	0,	0),
 				101 => array(PROFIL_WOCHENENDE,RAUM_BAD,		   "03:20",	10.0,	0,	0),
  				102 => array(PROFIL_WOCHENENDE,RAUM_BAD,		   "18:07",	10.0,	0,	0),
  				105 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"00:00",	15.5,	0,	0),
 				106 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"09:00",	20.0,	0,	0),
  				107 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"19:00",	15.5,	0,	0),
  				110 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"00:00",	18.5,	0,	0),
 				111 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"08:00",	21.0,	0,	0),
  				112 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"21:00",	18.5,	0,	0),

				//	PROFILE NULL_MODUS
				120 => array(PROFIL_NULL_MODUS,RAUM_BAD,		   "00:01",	10.0,	0,	0),
 				121 => array(PROFIL_NULL_MODUS,RAUM_BAD,		   "16:05",	10.0,	0,	0),
  				122 => array(PROFIL_NULL_MODUS,RAUM_BAD,		   "18:07",	10.0,	0,	0),
  				125 => array(PROFIL_NULL_MODUS,RAUM_WOHNEN,		"00:00",	15.0,	0,	0),
 				126 => array(PROFIL_NULL_MODUS,RAUM_WOHNEN,		"09:00",	15.0,	0,	0),
  				127 => array(PROFIL_NULL_MODUS,RAUM_WOHNEN,		"19:00",	15.0,	0,	0),
  				130 => array(PROFIL_NULL_MODUS,RAUM_ARBEIT,		"00:00",	15.0,	0,	0),
 				131 => array(PROFIL_NULL_MODUS,RAUM_ARBEIT,		"08:00",	15.0,	0,	0),
  				132 => array(PROFIL_NULL_MODUS,RAUM_ARBEIT,		"21:00",	15.0,	0,	0),


				//	PROFILE URLAUB
				140 => array(PROFIL_URLAUB,RAUM_BAD,		   "00:01",	10.0,	0,	0),
 				141 => array(PROFIL_URLAUB,RAUM_BAD,		   "16:05",	10.0,	0,	0),
  				142 => array(PROFIL_URLAUB,RAUM_BAD,		   "18:07",	10.0,	0,	0),
  				145 => array(PROFIL_URLAUB,RAUM_WOHNEN,		"00:00",	15.0,	0,	0),
 				146 => array(PROFIL_URLAUB,RAUM_WOHNEN,		"09:00",	15.0,	0,	0),
  				147 => array(PROFIL_URLAUB,RAUM_WOHNEN,		"19:00",	15.0,	0,	0),
  				150 => array(PROFIL_URLAUB,RAUM_ARBEIT,		"00:00",	15.0,	0,	0),
 				151 => array(PROFIL_URLAUB,RAUM_ARBEIT,		"08:00",	15.0,	0,	0),
  				152 => array(PROFIL_URLAUB,RAUM_ARBEIT,		"21:00",	15.0,	0,	0),

				//	PROFILE ABWESEND
				160 => array(PROFIL_ABWESEND,RAUM_BAD,		   "00:01",	10.0,	0,	0),
 				161 => array(PROFIL_ABWESEND,RAUM_BAD,		   "16:05",	10.0,	0,	0),
  				162 => array(PROFIL_ABWESEND,RAUM_BAD,		   "18:07",	10.0,	0,	0),
  				165 => array(PROFIL_ABWESEND,RAUM_WOHNEN,		"00:00",	15.0,	0,	0),
 				166 => array(PROFIL_ABWESEND,RAUM_WOHNEN,		"09:00",	15.0,	0,	0),
  				167 => array(PROFIL_ABWESEND,RAUM_WOHNEN,		"19:00",	15.0,	0,	0),
  				170 => array(PROFIL_ABWESEND,RAUM_ARBEIT,		"00:00",	15.0,	0,	0),
 				171 => array(PROFIL_ABWESEND,RAUM_ARBEIT,		"08:00",	15.0,	0,	0),
  				172 => array(PROFIL_ABWESEND,RAUM_ARBEIT,		"21:00",	15.0,	0,	0),

				//	PROFILE ANWESEND
				180 => array(PROFIL_ANWESEND,RAUM_BAD,		   "00:01",	10.0,	0,	0),
 				181 => array(PROFIL_ANWESEND,RAUM_BAD,		   "16:05",	10.0,	0,	0),
  				182 => array(PROFIL_ANWESEND,RAUM_BAD,		   "18:07",	10.0,	0,	0),
  				185 => array(PROFIL_ANWESEND,RAUM_WOHNEN,		"00:00",	15.0,	0,	0),
 				186 => array(PROFIL_ANWESEND,RAUM_WOHNEN,		"09:00",	15.0,	0,	0),
  				187 => array(PROFIL_ANWESEND,RAUM_WOHNEN,		"19:00",	15.0,	0,	0),
  				190 => array(PROFIL_ANWESEND,RAUM_ARBEIT,		"00:00",	15.0,	0,	0),
 				191 => array(PROFIL_ANWESEND,RAUM_ARBEIT,		"08:00",	15.0,	0,	0),
  				192 => array(PROFIL_ANWESEND,RAUM_ARBEIT,		"21:00",	15.0,	0,	0),

 				//
  				999 => array(0,			0,			"00:00",		0,		0,	0)
  				);






?>