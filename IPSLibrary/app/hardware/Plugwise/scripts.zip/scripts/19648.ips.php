<?php
/**
RegVar-Script f�r APCUPSD status text
www.tdressler.net/ipsymcon
V0.8 26.01.2011
*/
 #######Begin Config
 //IPS Variablen IDs
 $regvars=array(30034);
 $GLOBALS['parent']=53528; //parent ID of master category
 $GLOBALS['catname']='APCUPSD'; //master category name
 $GLOBALS['idname']='SERIALNO'; //unique ID parameter

 $logfile='apc.log';
 ######End Config
/*
hardcoded NOMPOWER values related to Modelname digit value
							 !!!
first line Smart-UPS 700 ->480W
*/
 $nomvals=array(
   700=>480,
 	750=>500, //smart ups xxx
	1000=>670,
 	1500=>980,
 	2200=>1580,
 	3000=>2700,
 	420=>260, //Smart ups SC xxx
 	450=>280,
 	620=>390,
 	350=>210, //Back UPS CS/ES
 	400=>240,
 	500=>300,
 	550=>330,
	800=>540); //Back UPS RS

$GLOBALS['nomvals']=$nomvals;
$vartypes=array(  			'ID'=>array('type'=>3,'profile'=>''),
						         'VoltIn'=>array('type'=>1,'profile'=>'~Volt.230'),
						         'FreqIn'=>array('type'=>2,'profile'=>'Freq.netz'),
						         'VoltOut'=>array('type'=>1,'profile'=>'~Volt.230'),
						         'LoadPct'=>array('type'=>1,'profile'=>'~Battery.100'),
						         'Watt'=>array('type'=>1,'profile'=>'~Watt.3680'),
						         'NomPower'=>array('type'=>1,'profile'=>'~Watt.3680'),
						         'TimeLeft'=>array('type'=>2,'profile'=>'Time.min'),
						         'LastOn'=>array('type'=>3,'profile'=>'~String'),
						         'Model'=>array('type'=>3,'profile'=>'~String'),
						         'Name'=>array('type'=>3,'profile'=>'~String'),
						         'Status'=>array('type'=>3,'profile'=>'~String'),
                           'Temperatur'=>array('type'=>2,'profile'=>'~Temperature'),
                           'OnLine'=>array('type'=>0,'profile'=>'~Alert.Reversed')
								);

	 $GLOBALS['vartypes']=$vartypes;
 	$GLOBALS['varids']=null;

 	//NonStandard Profiles (needed for Webfront)
	check_profile('Time.min',2,null,' min',null,null,null,1);
	check_profile('Freq.netz',2,null,' Hz',45,55,1,1);

	//Standard-Regvar Handling
	if ($IPS_SENDER == "RegisterVariable")
		{
		$reg=$IPS_INSTANCE;
   	// bereits im Puffer der Instanz vorhandene Daten in $data kopieren
  		$data  = RegVar_GetBuffer($reg);
  		// neu empfangene Daten an $data anh�ngen
  		$data .= $IPS_VALUE;
  		RegVar_SetBuffer($reg, $data);
		}
	else
		{
		foreach($regvars as $reg)
			{
			$in=null;
		 	$id=IPS_GetParent($reg);
			//echo "\n" .$id;
			//Nicht registervariable, also manuell
			//socket �ffnen
			CSCK_SetOpen($id,true);
			IPS_ApplyChanges($id);
			   
			//befehl senden
			RegVar_SendText($reg,chr(0).chr(6)."status");
			//warten
			sleep (1);
			//Socket schliessen
			CSCK_SetOpen($id,false);
			
			IPS_ApplyChanges($id);
			//R�ckgabe abholen
			$in  = RegVar_GetBuffer($reg);
			//RegVar bereinigen
			RegVar_SetBuffer($reg, "");
			//Ausgabe in Array wandeln
	   	$apc=format_data($in);
			//loggen
			logge($logfile,$apc);
			//parsen
	   	if (isset($apc['APC']) && preg_match("/^(\d+),(\d+),(\d+)/",$apc['APC']))
				{
				parse_apc($apc);
				}
			else
				{
		   	$msg='no valid data';
				if (isset($apc['APC'])) ':'.$msg.$apc['APC'];
					ips_logmessage('APC',$msg);
				}
			}
	}

/**
* parses APCUPSD status parameter
* @param array APC parameter
*/
function parse_apc($apc) {

	$catname=$GLOBALS['catname'];
	$nomvals=$GLOBALS['nomvals'];
	$idname=$GLOBALS['idname'];
	//extract data into array

	//Status auswerten
	$vartypes=$GLOBALS['vartypes'];
	$varids=null;
	//define null values as default
	$status=null;
	$model=null;
	$name=null;
	$lv=null;
	$lf=null;
	$ov=null;
	$lpct=null;
	$temp=null;
	$np=null;
	$dev=null;
	$load=null;
	$online=null;
	//try to update values with real parameter from APC
	if (isset($apc[$idname])){
		$dev=$apc[$idname];
	}else{
	   IPS_LOGMessage('APC',"Identifier $idname not found");
	   return;
	}
	if (isset($apc['LINEV'])) { list($lv,$rest)=explode(' ',$apc['LINEV'],2);}
	if (isset($apc['LINEFREQ'])) {list($lf,$rest)=explode(' ',$apc['LINEFREQ'],2);}
	if (isset($apc['OUTPUTV'])){ list($ov,$rest)=explode(' ',$apc['OUTPUTV'],2);}
	if (isset($apc['LOADPCT'])){list($lpct,$rest)=explode(' ',$apc['LOADPCT'],2);}
	if (isset($apc['ITEMP'])){list($temp,$rest)=explode(' ',$apc['ITEMP'],2);}
   if (isset($apc['MODEL'])) {$model=$apc['MODEL'];}
   if (isset($apc['STATUS'])) {$status=$apc['STATUS'];}
   if (isset($apc['UPSNAME'])) {$name=$apc['UPSNAME'];}
   if (isset($apc['TIMELEFT'])){ list($tl,$rest)=explode(' ',$apc['TIMELEFT'],2);}
	//retrieve nominal power from APC
	if (isset($apc['NOMPOWER'])) {
			   //value is supplied by APC
				list($np,$rest)=explode(' ',$apc['NOMPOWER'],2);
	}else{
			   //try to use hardcoded power table based on digits in model name(ex. SMART UPS 750)
			   if (!is_null($model)) {
					preg_match("/(\d{3,4})/",$model,$result);
					if (isset($result[0]) && (isset($nomvals[$result[0]]))){
						$np=$nomvals[$result[0]];
						//IPS_Logmessage('APC',"$model: NOMPOWER from Model=$np");
					}
	 			}
	}

	//format last on battery value, if any
	if (isset($apc['XONBATT'])) {
				list($date,$time, $rest)=explode(' ',$apc['XONBATT'],4);
	}else{
				$date='none';
				$time='';
	}
	$online=($status=='ONLINE');
	$sensorname=$model;
	if ((is_null($model)) || (is_null($dev))) {
			   IPS_Logmessage('APC',"Missing Modelname ($model) od DeviceID($dev)");
	}else{
	      $GLOBALS['varids']=null;
         //IPS_Logmessage('APC',"Dev:$dev Name: $sensorname");
			get_ips_vars($dev,$vartypes,$catname,$sensorname);
			$varids=$GLOBALS['varids'];
			if (is_null($varids)) {
			   //Error, no vars created
	   		IPS_LogMessage($catname,'No VarIDs!');
			}else{
				//give $np a pseudo value to fill variable, if not found until now
			   if (is_null($np)){ $np=500;}
            //NominalPower defined in IPS has priority over Device Value
				$np=(isset($varids['NomPower']['val']) &&($varids['NomPower']['val']>0))?$varids['NomPower']['val']:$np;
				//calculate current power based on nominal power and load percent values if available
				if ((! is_null($np)) && (! is_null($lpct))) {
					$load=$np*$lpct/100;
				}
			//store
				storevars($varids,'OnLine',$online);
				storevars($varids,'Status',$status);
				storevars($varids,'Model',$model);
				storevars($varids,'Name',$name);
				storevars($varids,'NomPower',intval($np));
				storevars($varids,'LastOn',"$date $time");
				storevars($varids,'VoltIn',intval($lv));
				storevars($varids,'FreqIn',floatval($lf));
				storevars($varids,'VoltOut',intval($ov));
				storevars($varids,'LoadPct',intval($lpct));
				storevars($varids,'Watt',intval($load));
				storevars($varids,'TimeLeft',floatval($tl));
				storevars($varids,'Temperatur',floatval($temp));
			}
	}
}
/**
* Check if is Varaible available and store value
* deletes variable if value is null, meens parameter not supplied by apc
* recreate variable if value is set, but no variable ID, means value supplied now
* @param array current variable ids in tree
* @param string name of variable
* @param variant value to store
*/
function storevars($ids,$name,$val) {
	$vartypes=$GLOBALS['vartypes'];
	$parent=$ids['%parent%']['id'];
	$vid=isset($ids[$name]['id'])?$ids[$name]['id']:null;
	//IPS_Logmessage('APC',"$vid:$name=$val"); //debug
	if (is_null($val)) {
	   if (isset($vid)) {
	      if (IPS_VariableExists($vid)) IPS_DeleteVariable($vid);
		}
	}else{
	   //check value variable id
		if (is_null($vid)) {
		   //not there, recreate
		   $vid=createvarfromtypes($name,$parent);
		   $pname=IPS_GetName($parent);
		   IPS_Logmessage('APC',"$pname: Variable $name not found, recreated as ID $vid");
		}
		//recheck
		if (isset($vid)) {
			if (IPS_VariableExists($vid)) SetValue($vid,$val);
		}
	}
}
/**
* creates variables with help of typinfo array by name
* @param string name of variable
* @param integer parent ID of parent object
*/
function createvarfromtypes($name,$parent) {
	$vartypes=$GLOBALS['vartypes'];
	$typ=isset($vartypes[$name]['type'])?$vartypes[$name]['type']:null;
   $vid=null;
   if (($name>'')&&($parent>-1) && (!is_null($typ))) {
		$vid=IPS_CreateVariable($typ);
		ips_setname($vid,$name);
		ips_setParent($vid,$parent);
		if (isset($vartypes[$name]['profile'])) {
      	$profile=$vartypes[$name]['profile'];
			IPS_SetVariableCustomProfile($vid,$profile);
		}
		$GLOBALS['varids'][$name]['id']=$vid;
		$GLOBALS['varids'][$name]['val']=0;
      ips_logmessage('APC',"Created Var $name: Parent:$parent, Type:$typ, ID:$vid");
   }else{
      ips_logmessage('APC',"Missing Values for create Var $name: Parent:$parent, Type:$typ");
	}
	return $vid;
}
/**
* IPS Variablen handler
* creates variables as needed
* returns assoc. Array with IPS Variable ID and Value
* @param integer Sensor Address
* @param array Array with Variable Names, Types and Profiles
* @param string Sensor Group Master Categorie Name
* @param string Sensor default name, will be extended with $addr
*/
function get_ips_vars($addr,$vartypes,$cat,$sens) {
 	$varids=null;
 	$parent=(isset($GLOBALS['parent']) && IPS_ObjectExists($GLOBALS['parent']))?$GLOBALS['parent']:0;
	//master category
	 $master=@IPS_GetObjectIDByName($cat,$parent);
	//no master cat, create new
	 if (!$master) {
   	$master=IPS_CreateCategory();
   	IPS_SetName($master,$cat);
   	IPS_SetParent($master,$parent);
		if ($master>0) {
	   	IPS_LogMessage('APC', "Master category created, ID=$master\n");
   	}else{
			IPS_LogMessage('APC', "Can't create Master Category\n");
			return null;
		}
 	}
	//check childrens for varable with name "ID"
  $id=0;
  if ($master>0) {
  //get chilren sensors
   $Sensors=IPS_GetChildrenIDs($master);
   foreach($Sensors as $sid) {
   	$name=IPS_GetName($sid);
      //print "$sid:".$name."\n"; //debug
		//get vars for each sensor
		$vars=IPS_GetChildrenIDs($sid);
      foreach($vars as $vid) {
       $obj=IPS_GetObject($vid);
         $vname=$obj['ObjectName'];
         $typ=$obj['ObjectType'];
          //Variable
          if ($typ==2) { //Variable
         	//if ID, here is the address
         	if ($vname="ID") {
         		$i=GetValue($vid);
         		//go out if matches, $id returns the sensor categorie id
         		if ($i===$addr) {
         	   	$id=$sid;
         	   	break;
         		}
         	}
         }
      }
      if ($id>0) break;
   }
   //if variable ID doesnt exists assume we have to create all
	if ($id==0) {
		//Sensor with address $addr not found in IPS, create new sensor
	   $id=ips_createCategory();
	   ips_setName($id,$sens);
	   ips_setParent($id,$master);
		//creates all needed variables for the new sensor
		foreach (array_keys($vartypes) as $name) {
		   $vid=createvarfromtypes($name,$id);
         //preload variables
			SetValue($vid,0);
    		$varids[$name]['id']=$vid;
      	$varids[$name]['val']=0;
			//Store address in $ID for next time
         if ($name=='ID') {
	         SetValue($vid,$addr);
   	      $varids[$name]['val']=$addr;
			}
		}
	}else{
	   //found matching cat, collect ids and vals for this sensor
	   $vars=IPS_GetChildrenIDs($id);
      foreach($vars as $vid) {
         $obj=IPS_GetObject($vid);
         $name=$obj['ObjectName'];
         $typ=$obj['ObjectType'];
         if ($typ==2) { //Variable
         	$val=GetValue($vid);
         	$varids[$name]['id']=$vid;
         	$varids[$name]['val']=$val;
         }
      }
	}
	//store parent
	$varids['%parent%']['id']=$id;
	$GLOBALS['varids']=$varids;
	//returns IDs and Values of this Sensor, Name is Key
	return $varids;
 }
}
/**
*
* @param string $text output from apcupsd
* @return array $apc Array Key/Values
*/
function format_data($text){
   	$entry=explode("\n",$text); //Satztrenner
		$apc=array();
		foreach($entry as $line) {
		   if (! $line || strlen($line)<2) continue;
			$p1=ord($line[0]); //immer 00
			$p2=ord($line[1]); //Kennziffer
			if ($p2>0) {
					$content=substr($line,2);
					//Key /Value Paare durch ':' getrennt
					if (strpos($content,":")>0) {
						list($key,$value)=explode(":",$content,2);
						$apc[trim($key)]=trim($value);
					}
			}
		}
		return $apc;
}
//#############################
/**
* do simple logging
* @param string $logfile Filename for logfile
* @param string $text
* @returns void
*/

function logge($logfile,$apc) {
	if (strlen($logfile)>0) {
		$log=fopen($logfile,"a+");
		if ($log) {
	   	$d=date("r");
	   	fwrite($log,"#--------------------------\r\n");
	      foreach ($apc as $key=>$value) {
         	fwrite($log, "$key:$value\r\n");
         }
 			fflush($log);
			fclose($log);
		}
	}
}
/**
* Get ID by name if exists, else create
* @Param String Name
* @param integer Parent-ID
* @param integer Variable Typ (0..3)
* @return integer ID
*/
function getVid($name,$par,$typ) {
	$vid = @IPS_GetVariableIDByName($name, $par);
	if ($vid === false) {
		$vid=IPS_CreateVariable($typ);
		ips_setname($vid,$name);
		ips_setParent($vid,$par);
		setValue($vid,'');
	}
	return $vid;
}
/**
* Check profile by name if exists, else create
* @Param String Name
* @param integer Variable Typ (0..3)
* @param String prefix befor value
* @param String suffix after value
* @param integer min value
* @param integer max value
* @param integer step value
* @param integer digits for formatting
*/

function check_profile($pname,$typ,$prefix,$suffix,$min,$max,$step,$digit=0) {
if (!IPS_VariableProfileExists($pname)) {
	if (IPS_CreateVariableProfile($pname,$typ)) {
	   IPS_SetVariableProfileText($pname,$prefix,$suffix);
		if (isset($min) && isset($max) && isset($step)) {
	   	IPS_SetVariableProfileValues($pname,$min,$max,$step);
	   }
	  	if (isset($digit)) {
	   	IPS_SetVariableProfileDigits($pname,$digit);
	   }
 	}
}
}
?>