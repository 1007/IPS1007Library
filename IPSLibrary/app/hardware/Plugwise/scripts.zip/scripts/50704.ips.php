<?


	$text = WWWReader_RetrievePage(40685,"http://whocallsme.com/Phone-Number.aspx/0891247114371");

	//echo $text;
	
	preg_match_all('|<div class="oos_p6">(.*)</div>|siU',$text,$ar);
	//print_r($ar);
	$text = "";
	for($x=0; $x < count($ar[0]); $x++)
	   {
	   $text = $text . "\n" .$ar[0][$x];
	   $text = $text . "\n-";
	   }

	echo $text;


?>