<?

 $address = "192.168.10.254";
 $address = "fritz.box";
 
//Ab hier nichts mehr �ndern
$object = IPS_GetObject($IPS_SELF);
$parentID = $object['ParentID'];

$contentRecv = 'POST /upnp/control/WANCommonIFC1 HTTP/1.1
Cache-Control: no-cache
Connection: Close
Pragma: no-cache
Content-Type: text/xml; charset="utf-8"
User-Agent: Microsoft-Windows/6.1 UPnP/1.0
SOAPAction: "urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1#GetTotalBytesReceived"
Content-Length: '.(302+strlen($address)).'
Host: '.$address.':49000

<?xml version="1.0"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><SOAP-ENV:Body><m:GetTotalBytesReceived xmlns:m="urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1"/></SOAP-ENV:Body></SOAP-ENV:Envelope>
';

$contentSent = 'POST /upnp/control/WANCommonIFC1 HTTP/1.1
Cache-Control: no-cache
Connection: Close
Pragma: no-cache
Content-Type: text/xml; charset="utf-8"
User-Agent: Microsoft-Windows/6.1 UPnP/1.0
SOAPAction: "urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1#GetTotalBytesSent"
Content-Length: '.(298+strlen($address)).'
Host: '.$address.':49000

<?xml version="1.0"?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><SOAP-ENV:Body><m:GetTotalBytesSent xmlns:m="urn:schemas-upnp-org:service:WANCommonInterfaceConfig:1"/></SOAP-ENV:Body></SOAP-ENV:Envelope>
';

//Installer
if ($IPS_SENDER == "Execute")
{
    IPS_SetHidden($IPS_SELF, true);
    IPS_SetName($IPS_SELF, "Auslese-Skript");
    $parentObject = IPS_GetObject($parentID);
    if ($parentObject['ObjectType'] !== 1)
    {
        $instanceID = IPS_CreateInstance("{485D0419-BE97-4548-AA9C-C083EB82E61E}");
        IPS_SetParent($instanceID, $parentID);
        $parentID = $instanceID;
        IPS_SetParent($IPS_SELF, $parentID);
        IPS_SetName($instanceID, "FritzBox-Auslastung");
        IPS_SetIcon($instanceID, "Gauge");
    }
    IPS_SetScriptTimer($IPS_SELF, 10);

    if(!IPS_VariableProfileExists("InternetSpeed_kbs")) {
       IPS_CreateVariableProfile("InternetSpeed_kbs", 2);
       IPS_SetVariableProfileText("InternetSpeed_kbs", "", " kb/s");
       IPS_SetVariableProfileDigits("InternetSpeed_kbs", 2);
    }
}

$totalRecv = GetTextBetween(SendPacket($contentRecv), "<NewTotalBytesReceived>", "<\/NewTotalBytesReceived>");
$totalSent = GetTextBetween(SendPacket($contentSent), "<NewTotalBytesSent>", "<\/NewTotalBytesSent>");
$vidRecv = CreateVariableByName($parentID, "TotalRecv", 2, 1, "", true);
$vidSent = CreateVariableByName($parentID, "TotalSent", 2, 2, "", true);

$varRecv = IPS_GetVariable($vidRecv);
$varSent = IPS_GetVariable($vidSent);





SetValue($vidRecv, $totalRecv);
SetValue($vidSent, $totalSent);

$time = microtime(true);

$vidDn = CreateVariableByName($parentID, "Downstream", 2, 3, "InternetSpeed_kbs");
$vidUp = CreateVariableByName($parentID, "Upstream", 2, 4, "InternetSpeed_kbs");

$wert =  ($totalRecv - $varRecv['VariableValue']['ValueFloat']) / (($time - $varRecv['VariableUpdated'])) / 1024 ;
//echo $wert;
if ( $wert > 0 )
SetValue($vidDn, ($totalRecv - $varRecv['VariableValue']['ValueFloat']) / (($time - $varRecv['VariableUpdated'])) / 1024);

$wert =  ($totalSent - $varSent['VariableValue']['ValueFloat']) / (($time - $varSent['VariableUpdated'])) / 1024 ;
//echo $wert;
if ( $wert > 0 )
SetValue($vidUp, ($totalSent - $varSent['VariableValue']['ValueFloat']) / (($time - $varSent['VariableUpdated'])) / 1024);


//echo $totalRecv - $varRecv['VariableValue']['ValueFloat']) / (($time - $varRecv['VariableUpdated'])) / 1024;
$diff = $totalRecv - $varRecv['VariableValue']['ValueFloat'];
if ( $diff < 0 ) echo "[$totalRecv][" . $varRecv['VariableValue']['ValueFloat'] . "][$diff]";

function SendPacket($content) {
    global $address;
    $port = 49000;


	
	//echo $address;
    //$fp = fsockopen ($address, $port, $errno, $errstr, 10);
    $fp = fsockopen ("192.168.10.254", $port, $errno, $errstr, 10);
    
    if (!$fp) {
        echo "------------------- $errstr ($errno)<br />\n";
    } else {
        fputs ($fp, $content);
        $ret = "";
        while (!feof($fp)) {
            $ret.= fgets($fp,128);
        }
        fclose($fp);
    }
    
    if(!(strpos($ret, "200 OK") === false))
	 	{
       return $ret;
    	}
	else
		{
       die("Invalid Response");
    	}
}

function GetTextBetween($string, $start, $end){
    preg_match_all( "/$start(.*)$end/U", $string, $match );
    return $match[1][0];
}

function CreateVariableByName($id, $name, $type, $position, $profile="", $hidden=false)
{
    global $IPS_SELF;
    $vid = @IPS_GetVariableIDByName($name, $id);
    if($vid === false)
    {
        $vid = IPS_CreateVariable($type);
        IPS_SetParent($vid, $id);
        IPS_SetName($vid, $name);
        IPS_SetPosition($vid, $position);
        IPS_SetHidden($vid, $hidden);
        IPS_SetVariableCustomProfile($vid, $profile);
        IPS_SetInfo($vid, "this variable was created by script #$IPS_SELF");
    }
    return $vid;
}


?>