<?

if($_IPS['SENDER'] == "RunScript")
{
	$IPS_SENDER = $_IPS['SENDER'];
	$IPS_SELF = $_IPS['SELF'];
	$IPS_THREAD = $_IPS['THREAD'];
	foreach($_IPS as $key => $val)
	{
		if(!in_array($key, Array("SENDER", "SELF", "THREAD")))
		{
			${$key} = $val;
		}
	}
} else {
	foreach($_IPS as $key => $val)
	{
		${"IPS_".$key} = $val;
	}
}
 
switch($_IPS['SENDER'])
{
	case "HeatingControl":
		$HC_INSTANCES = $_IPS['INSTANCES'];
		$HC_INVERTS = $_IPS['INVERTS'];
		$HC_VALUE = $_IPS['VALUE'];
		break;
	case "ShutterControl":
		$SC_INSTANCE = $_IPS['INSTANCE'];
		$SC_INSTANCE2 = $_IPS['INSTANCE2'];
		$SC_DIRECTION = $_IPS['DIRECTION'];
		$SC_DURATION = $_IPS['DURATION'];
		break;
	case "ISDN":
		$ISDN_CONNECTION = $_IPS['CONNECTION'];
		$ISDN_EVENT = $_IPS['EVENT'];
		$ISDN_DATA = $_IPS['DATA'];
		break;
	case "WebFront":
		$REMOTE_ADDR = $_IPS['REMOTE_ADDR'];
		break;
	case "Designer":
		$REMOTE_ADDR = $_IPS['REMOTE_ADDR'];
		$REMOTE_HOST = $_IPS['REMOTE_HOST'];
		break;
}
 
if (!function_exists('IPS_StatusVariableExists'))	
{
	function IPS_StatusVariableExists($InstanceID, $VariableIdent)
	{
		return !(@IPS_GetObjectIDByIdent($VariableIdent, $InstanceID) === false);
	}
}

if (!function_exists('IPS_GetStatusVariable'))	
{
	function IPS_GetStatusVariable($InstanceID, $VariableIdent)
	{
	   $id = IPS_GetObjectIDByIdent($VariableIdent, $InstanceID);
	   $v = IPS_GetVariable($id);
	   return Array(
			"VariableID" => $id,
			"VariableIdent" => $VariableIdent,
			"VariableName" => "N/A",
			"VariablePosition" => 0,
			"VariableProfile" => $v['VariableProfile'],
			"VariableType" => $v['VariableValue']['ValueType'],
			"VariableHasAction" => ($v['VariableAction'] > 0),
			"VariableUseAction" => ($v['VariableAction'] > 0)
		);
	}
}

if (!function_exists('IPS_GetStatusVariableIdents'))	
{
	function IPS_GetStatusVariableIdents($InstanceID)
	{
		$r = Array();
		$cids = IPS_GetChildrenIDs($InstanceID);
		foreach($cids as $cid)
		{
		   $o = IPS_GetObject($cid);
		   if($o['ObjectIdent'] != "")
			  $r[] = $o['ObjectIdent'];
		}
		return $r;
	}
}

if (!function_exists('IPS_GetStatusVariableID'))	
{
	function IPS_GetStatusVariableID($InstanceID, $VariableIdent)
	{
		return IPS_GetObjectIDByIdent($VariableIdent, $InstanceID);
	}		
}

if (!function_exists('IPS_SetLinkChildID'))	
{
	function IPS_SetLinkChildID($LinkID, $TargetID)
	{
		return IPS_SetLinkTargetID($LinkID, $TargetID);
		//trigger_error("The function SetLinkChildID was renamed and is now deprecated. Use SetLinkTargetID instead.", E_USER_WARNING);
	}		
}

if (!function_exists('IPS_HasInstanceParent'))	
{
	function IPS_HasInstanceParent($InstanceID)
	{
		return (IPS_GetInstance($InstanceID)['ConnectionID'] > 0);
	}		
}

if (!function_exists('IPS_GetInstanceParentID'))	
{
	function IPS_GetInstanceParentID($InstanceID)
	{
		return IPS_GetInstance($InstanceID)['ConnectionID'];
	}		
}

if (!function_exists('IPS_HasInstanceChildren'))	
{
	function IPS_HasInstanceChildren($InstanceID)
	{
		return sizeof(IPS_GetInstanceChildrenIDs($InstanceID)) > 0;
	}		
}

if (!function_exists('IPS_GetInstanceChildrenIDs'))	
{
	function IPS_GetInstanceChildrenIDs($InstanceID)
	{
		$result = Array();
		$InstanceIDs = IPS_GetInstanceList();
		foreach($InstanceIDs as $IID)
			if(IPS_GetInstance($IID)['ConnectionID'] == $InstanceID)
				$result[] = $IID;
	}		
}

if (!function_exists('LCN_GetStatus'))	
{
	function LCN_GetStatus($InstanceID)
	{
		$i = IPS_GetInstance($InstanceID);
		switch($i['InstanceStatus'])
		{
			case 102: //LCN_Loggedin
				return 2;
			case 201: //LCN_Connected
				return 1;
			case 202: //LCN_Disconnected
				return 0;
			case 203: //LCN_AuthError
				return 3;
			case 204: //LCN_LicenseError
				return 4;
			case 205: //LCN_UnknownError
				return 5;
		}
		return -1;
	}		
}

//Instance configuration
if (!function_exists('CSCK_SetOpen'))	
{
	function CSCK_SetOpen($InstanceID, $Value)
	{
		IPS_SetProperty($InstanceID, 'Open', $Value);
	}
}

if (!function_exists('CSCK_GetOpen'))	
{
	function CSCK_GetOpen($InstanceID)
	{
		return IPS_GetProperty($InstanceID, 'Open');
	}
}

if (!function_exists('CSCK_SetHost'))	
{
	function CSCK_SetHost($InstanceID, $Value)
	{
		IPS_SetProperty($InstanceID, 'Host', $Value);
	}
}

if (!function_exists('CSCK_GetHost'))	
{
	function CSCK_GetHost($InstanceID)
	{
		return IPS_GetProperty($InstanceID, 'Host');
	}
}

if (!function_exists('CSCK_SetPort'))	
{
	function CSCK_SetPort($InstanceID, $Value)
	{
		IPS_SetProperty($InstanceID, 'Port', $Value);
	}
}

if (!function_exists('CSCK_GetPort'))	
{
	function CSCK_GetPort($InstanceID)
	{
		return IPS_GetProperty($InstanceID, 'Port');
	}
}

if (!function_exists('SSCK_SetOpen'))	
{
	function SSCK_SetOpen($InstanceID, $Value)
	{
		IPS_SetProperty($InstanceID, 'Open', $Value);
	}
}

if (!function_exists('SSCK_GetOpen'))	
{
	function SSCK_GetOpen($InstanceID)
	{
		return IPS_GetProperty($InstanceID, 'Open');
	}
}

if (!function_exists('SSCK_SetPort'))	
{
	function SSCK_SetPort($InstanceID, $Value)
	{
		IPS_SetProperty($InstanceID, 'Port', $Value);
	}
}

if (!function_exists('SSCK_GetPort'))	
{
	function SSCK_GetPort($InstanceID)
	{
		return IPS_GetProperty($InstanceID, 'Port');
	}
}

if(file_exists(IPS_GetKernelDir()."\\scripts\\__autoload.php")) 
    require_once(IPS_GetKernelDir()."\\scripts\\__autoload.php"); 

if(file_exists(IPS_GetKernelDir()."\\scripts\\__ipsmodule.inc.php")) 
	require_once(IPS_GetKernelDir()."\\scripts\\__ipsmodule.inc.php");

if(file_exists(IPS_GetKernelDir()."\\scripts\\__automodules.php")) 
	require_once(IPS_GetKernelDir()."\\scripts\\__automodules.inc.php");	
	
?>