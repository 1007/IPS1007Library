<?

	$mac = "001F3B3ADCD9"; //MAC Adresse des einzuschaltenden Ger�tes
 	$ip = "255.255.255.255"; // Broadcast adresse

wake($ip,$mac,15);//Port kann irgendwas sein

function wake($ip, $mac, $port)
	{
  	$nic = fsockopen("udp://" . $ip, $port);
  	if($nic)
  	{
    $packet = "";
    for($i = 0; $i < 6; $i++)
       $packet .= chr(0xFF);
       
    for($j = 0; $j < 16; $j++)
    	{
    	echo "\n[".$j."]";
      for($k = 0; $k < 6; $k++)
      	{
        	$str = substr($mac, $k * 2, 2);
        	echo "-".$str."|";
        	$dec = hexdec($str);
			echo $dec;
        	$packet .= chr($dec);
      	}
    	}

    echo "\n[" . $packet ."]";
    

    //$ret = fwrite($nic, $packet);
    fclose($nic);
	echo "\nErgebniss:".$ret.":";
  }
}

?>