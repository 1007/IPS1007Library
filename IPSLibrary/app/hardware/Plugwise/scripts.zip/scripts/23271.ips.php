<?

	$debug = false;


	if ( $IPS_SENDER == 'RunScript' ) $debug = false;
	
	$now     		=  time();


 	$root_ausgaenge = IPS_GetObjectIDByName("AUSGAENGE",0);
 	$array = IPS_GetChildrenIDs($root_ausgaenge);

	foreach ( $array as $raum_instance )
	   {
	   $raum_name = IPS_GetName($raum_instance);
	   if ($debug)echo "\n$raum_instance-$raum_name";
	   $subarray = IPS_GetChildrenIDs($raum_instance);
	  
		foreach ( $subarray as $object_instance )
	   	{
	   	$object_name = IPS_GetName($object_instance);
			if ($debug)echo "\n--------------$object_instance-$object_name";
			$soll = IPS_GetVariable(IPS_GetVariableIDByName("$object_name.STATUS.SOLL",$object_instance));
			$soll_changed = $soll['VariableChanged'];
			$soll_value   = $soll['VariableValue']['ValueBoolean'];
			$time = GetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER.SOLL",$object_instance));
			$timer = GetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER",$object_instance));

			$ist = IPS_GetVariable(IPS_GetVariableIDByName("$object_name.STATUS",$object_instance));
			$ist_changed = $ist['VariableChanged'];
			$ist_updated = $ist['VariableUpdated'];
			$ist_value   = $ist['VariableValue']['ValueBoolean'];

			$diff = $now-$ist_updated;
			if ($debug)echo "[$diff]$soll_value";
			if ($debug)echo "-->Soll[" . $soll_value ."]->Ist:[" .$ist_value . "]-->Timer[".$time."]".$timer."]";

			//echo "\nTIMER:$timer-$time";
			
			IPS_GetObject($object_instance);

			$objectinfo = IPS_GetObject($object_instance);
         $objectinfo = $objectinfo['ObjectInfo'];
			//echo $objectinfo;


			//*********************************************************************
			// ALLNET Teile
			//*********************************************************************
			if ( $objectinfo == "ALL3100" )
			   {
			   
				//*********************************************************************
				// Timerwert soll gestartet werden
				//*********************************************************************
				if ( $time > 0 )
			   	{ if  ( $debug ) echo "-Timer starten-";
					//SetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER.SOLL",$object_instance),0);
					//SetValueBoolean(IPS_GetVariableIDByName("$object_name.STATUS.SOLL",$object_instance),false);
					//FS20_SwitchDuration($object_instance, TRUE,$time);
					if ( $soll_value != $ist_value )
				   	{
						ALL_SwitchMode($object_instance,$soll_value);
						SetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER",$object_instance),0);

						}

					$soll_diff = $now - $ist_changed ;

					if ( $ist_value == true ) // Zeit laeuft
						{
						SetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER",$object_instance),$soll_diff);
						if ( $soll_diff >= $time ) // ausschalten
						   {
							SetValueBoolean(IPS_GetVariableIDByName("$object_name.STATUS.SOLL",$object_instance),false);
						   ALL_SwitchMode($object_instance,false);
						   }
						   
						}
						
					
			   	}

				//*********************************************************************
				// kein Timerwert
				//*********************************************************************
				if ( $time == 0 and $timer == 0 )
					{
					if ( $debug ) echo "-Kein Timer starten-";
					if ( $soll_value != $ist_value )
				   	{
						//FS20_SwitchMode($object_instance,$soll_value);
						ALL_SwitchMode($object_instance,$soll_value);
						}
					else
			  			{
			   		if ( (($now-$soll_changed) < 180) or (($now-$ist_updated) >= 3600) )
				   		//FS20_SwitchMode($object_instance,$soll_value);
							ALL_SwitchMode($object_instance,$soll_value);

			   		}
			   	}

			   
			   }

			else
			   {
			//*********************************************************************
			// FS 20 Teile
			//*********************************************************************
			
			
			
			//*********************************************************************
			// Timerwert soll gestartet werden
			//*********************************************************************
			if ( $time > 0 )
			   { if  ( $debug ) echo "-Timer starten-";
				SetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER.SOLL",$object_instance),0);
				//SetValueBoolean(IPS_GetVariableIDByName("$object_name.STATUS.SOLL",$object_instance),false);
				FS20_SwitchDuration($object_instance, TRUE,$time);
			   }

			//*********************************************************************
			// kein Timerwert
			//*********************************************************************
			if ( $time == 0 and $timer == 0 )
				{ if  ( $debug ) echo "-Kein Timer starten-";
				if ( $soll_value != $ist_value )
				   {
					FS20_SwitchMode($object_instance,$soll_value);
					}
				else
			  		{
			   	if ( (($now-$soll_changed) < 180) or (($now-$ist_updated) >= 3600) )
				   	FS20_SwitchMode($object_instance,$soll_value);
			   	}
			   }
			//*********************************************************************
			// Ende FS 20
			//*********************************************************************
			}


			}
	   
	   }

?>