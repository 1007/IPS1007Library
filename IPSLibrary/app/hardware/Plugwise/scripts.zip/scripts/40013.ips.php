<?

 print_r($_SERVER);
 print_r($_IPS);

?>