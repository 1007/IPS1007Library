<?

 	$id = 31723;
   $ip = "192.168.10.3";
   
   $kanal = WWWReader_RetrievePage($id,"http://$ip/control/zapto");
   $liste = WWWReader_RetrievePage($id,"http://$ip/control/channellist");
   $epg   = WWWReader_RetrievePage($id,"http://$ip/control/epg");

	$array = explode(chr(10),$liste);
	
   foreach($array as $sender)
		{
		if ( substr_compare($sender,$kanal,0,11) == 0 ) break ;
		$sender = "";
		}

	$array = explode(chr(10),$epg);

   foreach($array as $sendung)
		{
		if ( substr_compare($sendung,$kanal,0,11) == 0 ) break ;
		$sendung = "";
		}

   echo substr($sender,12) . "\n";
	echo substr($sendung,31) . "\n";
  

?>