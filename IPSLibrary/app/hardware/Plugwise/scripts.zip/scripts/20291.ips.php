<?
// Master Eingangs Routine
// alle Eingange sollten diese Routine aufrufen


	$debug = false;
	
	require_once(IPS_GetScriptID("Funcpool").".ips.php");

	if (!isset($IPS_VARIABLE)) $IPS_VARIABLE="" ;

	$root_daten_id = IPS_GetObjectIDByName("DATEN",0);
	
 	$root_ausgaenge = IPS_GetObjectIDByName("AUSGAENGE",0);
 	$root_status 	 = IPS_GetObjectIDByName("STATUS",IPS_GetObjectIDByName("DATEN",0));
	$root_system 	 = IPS_GetObjectIDByName("SYSTEM",IPS_GetObjectIDByName("DATEN",0));
	$root_temp 		 = IPS_GetObjectIDByName("TEMPERATUR",0);
	$root_settings  = IPS_GetObjectIDByName("EINSTELLUNGEN",IPS_GetObjectIDByName("DATEN",0));
	$root_licht     = IPS_GetObjectIDByName("LICHT",0);


	$name = IPS_GetName($IPS_VARIABLE);
	$id = $IPS_VARIABLE;
	$data = GetValue($IPS_VARIABLE);
	
	if ($debug ) echo "\nEingang:$name-$data";
	

	// WOHNEN
	if ( $name == "EINGANG.WOHNEN.PIRI13.EINGANG1" ) { eingang_piri_wohnen($id,$name,$root_licht,$root_status);return;}
	if ( $name == "EINGANG.WOHNEN.PIRI13.EINGANG2" ) { eingang_piri_wohnen($id,$name,$root_licht,$root_status);return;}

	// TREPPE
	if ( $name == "EINGANG.TREPPE.PIRI" ) { eingang_piri_treppe($root_ausgaenge,$root_status);return;}

	// FLUR
	if ( $name == "EINGANG.FLUR.KLINGEL.STATUS" ){ eingang_klingel();return;}
	if ( $name == "EINGANG.FLUR.PIRI" )				{ eingang_piri_flur($root_ausgaenge,$root_status,$root_licht);return;}


	// KELLER
	if ( $name == "EINGANG.KELLER.WASCHMASCHINE" ){ eingang_keller($root_daten_id,"WASCHMASCHINE",$IPS_VALUE);return;}
	if ( $name == "EINGANG.KELLER.TROCKNER" )     { eingang_keller($root_daten_id,"TROCKNER",$IPS_VALUE);return;}

	// BAD
	if ( $name == "EINGANG.BAD.DUSCHMODUS.DATA" ){ eingang_duschmodus($root_temp,$data);return;}
	if ( $name == "EINGANG.BAD.WACHMODUS.DATA" )	{ eingang_wachmodus($root_ausgaenge,$root_status,$data);return;}
	if ( $name == "EINGANG.BAD.PIRI" )          	{ eingang_piri_bad($root_ausgaenge,$root_status,$root_licht);return;}


	// AUSSEN
	if ( $name == "EINGANG.AUSSEN.WETTERSTATION.TEMPERATUR" ){ eingang_wetterstation($id,$root_daten_id,$name,$data);return;}
	if ( $name == "EINGANG.AKM.ANWESEND" ) 						{ eingang_anwesend($root_daten_id,$root_ausgaenge,$root_status,$IPS_VALUE);return;}

	// KUECHE
	if ( $name == "EINGANG.KUECHE.PIRI" ) { eingang_piri_kueche($root_ausgaenge,$root_status);return;}

	// ARBEIT
	if ( $name == "EINGANG.ARBEIT.PIRI" ) { eingang_piri_arbeit($root_ausgaenge,$root_system);return;}

	// SCHLAFEN
	if ( $name == "EINGANG.SCHLAFEN.BETT.DATA" )     { eingang_bett($root_daten_id,$IPS_VALUE,$IPS_OLDVALUE,$root_status,$root_settings);return;}




	echo "\nName: $name nicht gefunden";
	

//******************************************************************************
//
//******************************************************************************
function eingang_wetterstation($id,$root_status,$name,$data)
	{
	$debug = false ;
	
	if ($debug) echo $id."-".$root_status."-".$name."-".$data;

   $parent = IPS_GetParent($id);
   if ($debug) echo $parent;
   
   $temperatur = GetValueFloat(IPS_GetObjectIDByName("EINGANG.AUSSEN.WETTERSTATION.TEMPERATUR",$parent));
   $feuchtigkeit = GetValueInteger(IPS_GetObjectIDByName("EINGANG.AUSSEN.WETTERSTATION.LUFTFEUCHTIGKEIT",$parent));
   $regen = GetValueBoolean(IPS_GetObjectIDByName("EINGANG.AUSSEN.WETTERSTATION.REGEN",$parent));
   $regenmenge = GetValueInteger(IPS_GetObjectIDByName("EINGANG.AUSSEN.WETTERSTATION.REGENMENGE",$parent));
	$windgeschwindigkeit = GetValueFloat(IPS_GetObjectIDByName("EINGANG.AUSSEN.WETTERSTATION.WINDGESCHWINDIGKEIT",$parent));
	
   $root_id = IPS_GetObjectIDByName("WETTERSTATION",$root_status);
   
   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.REGEN",$root_id);
	SetValueBoolean($id,$regen);


	$a=floor(($regenmenge%256)/16);
	$a = $a + ($regenmenge%16)*16;
	$a = $a + floor(($regenmenge)/256)*256;

   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.REGENMENGE",$root_id);
	SetValueInteger($id,$a);

   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.TEMPERATUR",$root_id);
	SetValueFloat($id,$temperatur);

   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.LUFTFEUCHTIGKEIT",$root_id);
	SetValueInteger($id,$feuchtigkeit);

   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.WINDGESCHWINDIGKEIT.KMH",$root_id);
	SetValueFloat($id,$windgeschwindigkeit);

	$wind1 = $windgeschwindigkeit / 3.6;
   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.WINDGESCHWINDIGKEIT.MS",$root_id);
	SetValueFloat($id,$wind1);

	$wind2 = $windgeschwindigkeit / 1.85;
   $id = IPS_GetObjectIDByName("DATEN.WETTERSTATION.WINDGESCHWINDIGKEIT.KN",$root_id);
	SetValueFloat($id,$wind2);


	}

//******************************************************************************
//
//******************************************************************************
function eingang_wachmodus($root_ausgaenge,$root_status,$data)
	{

   $id = IPS_GetObjectIDByName("STATUS.WACH",$root_status);


	if ( $data == 17 or $data == 19 )
	   {
	   echo "Wach EIN ";
	   SetValueBoolean($id,true);
	   }
	if ( $data == 0  or $data == 20 )
	   {
	   echo "Wach AUS ";
	   SetValueBoolean($id,false);
	   }

	
	}
	
//******************************************************************************
//
//******************************************************************************
function eingang_bett($root_daten_id,$status,$status_old,$root_status,$root_settings)
	{
	$debug = false;
	
	$wach = false;
	$change = false ;
	
	$diff = $status - $status_old ;
	if ($debug) echo "\nBettdata : ".$status."[".$status_old."]".$diff;
	
	if ( $status < -30 )
	   if ( $status_old < -30 )
	      { $wach = true ; $change = true; }
	if ( $status > -30 )
	   if ( $status_old > -30 )
	      { $wach = false ; $change = true; }

	
   $id = IPS_GetObjectIDByName("STATUS.WACH",$root_status);
   
   $auto = GetValueBoolean(IPS_GetObjectIDByName("EINSTELLUNGEN.AUTOMATIK.SCHLAFEND",$root_settings));
   
	if ($debug) echo "id:".$id."-".$auto;

	if ( $auto )
		if ( $change )
			 SetValueBoolean($id,$wach);

	}
//******************************************************************************
//
//******************************************************************************
function eingang_anwesend($root_daten_id,$root_ausgaenge,$root_status,$status)
	{
	if ( $status )
		eingang_piri_treppe($root_ausgaenge,$root_status);
	
	$status_id 	= IPS_GetObjectIDByName("STATUS.ANWESEND",IPS_GetObjectIDByName("STATUS",$root_daten_id));

	SetValueBoolean($status_id,$status);

	}

//******************************************************************************
//
//******************************************************************************
function eingang_keller($root_daten_id,$geraet,$eingang)
	{
	$debug = true;
	
	$raum_id     = IPS_GetObjectIDByName("KELLER",$root_daten_id);
	$geraet_id   = IPS_GetObjectIDByName($geraet,$raum_id);
	$laeuft_id   = IPS_GetObjectIDByName($geraet.".LAEUFT",$geraet_id);
	$start_id    = IPS_GetObjectIDByName($geraet.".START",$geraet_id);
	$ende_id     = IPS_GetObjectIDByName($geraet.".ENDE",$geraet_id);
	$laufzeit_id = IPS_GetObjectIDByName($geraet.".LAUFZEIT",$geraet_id);
	$eingang_id  = IPS_GetObjectIDByName($geraet.".EINGANG",$geraet_id);
	

	$status = GetValueBoolean($laeuft_id);
	
	$now = date("d.m.Y H:i:s");

	if ( !$status and $eingang )
		{
		SetValueBoolean($laeuft_id,true);
		SetValueString($start_id,$now);
		SetValueString($ende_id,"");
		SetValueInteger($laufzeit_id,0);;
		}
		
	if ( $status and !$eingang )
		{
		SetValueString($ende_id,$now);
		}



	SetValueBoolean($eingang_id,$eingang);

	
	}
	
	
//******************************************************************************
//
//******************************************************************************
function eingang_tvmodus($root_ausgaenge,$root_status,$data)
	{
	echo "\nTVMODUS: $data";

	$raum_instance 	= IPS_GetObjectIDByName("ARBEIT",$root_ausgaenge);
	$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.ARBEIT.TV",$raum_instance);
	$soll_instance 	= IPS_GetObjectIDByName("AUSGANG.ARBEIT.TV.STATUS.SOLL",$ausgang_instance);
	$timer_instance 	= IPS_GetObjectIDByName("AUSGANG.ARBEIT.TV.TIMER.SOLL",$ausgang_instance);

   SetValueInteger($timer_instance,0);

	if ( $data == 17 or $data == 19 )
	   {
		SetValueBoolean($soll_instance,true);

		$status = GetValueBoolean("DBOX2.STATUS.ONLINE");
		if ( !$status )
		   { echo "\nDBOX kurz aus ";
		   FS20_SwitchDuration(58210, false, 10);
		   }
	   }
	   
	if ( $data == 0  or $data == 20 )
	   {
		SetValueBoolean($soll_instance,false);

	   }

	
	}

	
//******************************************************************************
//
//******************************************************************************
function eingang_duschmodus($root_temp,$data)
	{

	$raum_instance 	= IPS_GetObjectIDByName("BAD",$root_temp);
	$status_instance 	= IPS_GetObjectIDByName("STATUS",$raum_instance);
	$auto_instance 	= IPS_GetObjectIDByName("BAD.HEIZUNG.AUTOMATIK",$status_instance);
	
	//echo "\nDUSCHMODUS: $data-$auto_instance";

	if ( $data == 17 or $data == 19 )
	   {
	   //echo "Duschen EIN ( Automatik aus )";
	   SetValueBoolean($auto_instance,false);
	   }
	if ( $data == 0  or $data == 20 )
	   {
	   //echo "Duschen AUS ( Automatik ein )";
	   SetValueBoolean($auto_instance,true);
	   }

	}

//******************************************************************************
//
//******************************************************************************
function eingang_klingel()
	{
	$id = 27149;
	$id_grabber = 22716;

	newfeed("Klingel","Es hat an der Tuer geklingelt");
	   
	// fahre Position 1 an
	WWWReader_RetrievePage($id,"http://192.168.10.18/decoder_control.cgi?user=admin&pwd=k7pmde&command=31");

	IPS_Sleep(3000);

	IG_UpdateImage($id_grabber);

	IPS_Sleep(1000);

   email("Es hat geklingelt.","C:\\Programme\\IP-SYMCON2\\cams\\22716.jpg");

	}


//******************************************************************************
//
//******************************************************************************
function eingang_piri_wohnen($id,$name,$root_licht,$root_status)
	{

		$time = 12;
		
		$raum_instance 	= IPS_GetObjectIDByName("WOHNEN",$root_licht);
		$licht_instance   = IPS_GetObjectIDByName("LICHT.WOHNEN.LAMPE",$raum_instance);
		$soll_instance 	= IPS_GetObjectIDByName("LICHT.WOHNEN.LAMPE.STATUS.SOLL",$licht_instance);
		$timer_instance 	= IPS_GetObjectIDByName("LICHT.WOHNEN.LAMPE.TIMER.SOLL",$licht_instance);

      $parent  = IPS_GetParent($id);
      $name = $name . ".VISU";
		$visu_id = IPS_GetObjectIDByName($name,$parent);

   	//SetValueInteger($timer_instance,$time);
		//SetValueBoolean($soll_instance,true);


      SetValueInteger($visu_id,10);

      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$root_status)) == true )
   		{
   		SetValueInteger($timer_instance,$time);
			SetValueBoolean($soll_instance,true);
			$id = IPS_GetScriptID("dim_rgb");
			IPS_RunScript($id);

     		}



	}


//******************************************************************************
//
//******************************************************************************
function eingang_piri_treppe($root_ausgaenge,$root_status)
	{

		$time = 60;

		$raum_instance 	= IPS_GetObjectIDByName("TREPPE",$root_ausgaenge);
		$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.TREPPE.DICKDOOF",$raum_instance);
		$soll_instance 	= IPS_GetObjectIDByName("AUSGANG.TREPPE.DICKDOOF.STATUS.SOLL",$ausgang_instance);
		$timer_instance 	= IPS_GetObjectIDByName("AUSGANG.TREPPE.DICKDOOF.TIMER.SOLL",$ausgang_instance);

      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$root_status)) == true )
   		{
   		SetValueInteger($timer_instance,$time);
			SetValueBoolean($soll_instance,true);
     		}

  
	}

//******************************************************************************
//
//******************************************************************************
function eingang_piri_flur($root_licht,$root_status)
	{



	}

//******************************************************************************
//
//******************************************************************************
function eingang_piri_bad($root_ausgaenge,$root_status,$root_licht)
	{

		$time = 60;

		$raum_instance 	= IPS_GetObjectIDByName("BAD",$root_licht);
		$licht_instance   = IPS_GetObjectIDByName("LICHT.BAD.SPIEGEL",$raum_instance);
		$soll_instance 	= IPS_GetObjectIDByName("LICHT.BAD.SPIEGEL.STATUS.SOLL",$licht_instance);
		$timer_instance 	= IPS_GetObjectIDByName("LICHT.BAD.SPIEGEL.TIMER.SOLL",$licht_instance);

      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$root_status)) == true )
   		{
   		SetValueInteger($timer_instance,$time);
			SetValueBoolean($soll_instance,true);
     		}


	}

//******************************************************************************
//
//******************************************************************************
function eingang_piri_kueche($root_ausgaenge,$root_status)
	{

		$time = 90;


		$raum_instance 	= IPS_GetObjectIDByName("KUECHE",$root_ausgaenge);
		$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.KUECHE.LICHTSCHLANGE",$raum_instance);
		$soll_instance 	= IPS_GetObjectIDByName("AUSGANG.KUECHE.LICHTSCHLANGE.STATUS.SOLL",$ausgang_instance);
		$timer_instance 	= IPS_GetObjectIDByName("AUSGANG.KUECHE.LICHTSCHLANGE.TIMER.SOLL",$ausgang_instance);

     	if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$root_status)) == true )
   		{
   		SetValueInteger($timer_instance,$time);
			SetValueBoolean($soll_instance,true);
     		}



	}

//******************************************************************************
//
//******************************************************************************
function eingang_piri_arbeit($root_ausgaenge,$root_system)
	{

	require_once(IPS_GetScriptID("Verwaltung.Elo").".ips.php");
	elo(true);

	}

?>