<?

// Verwaltung Fernbedienung
// ueber LIRC

$taste         = GetValueString("PressedButton");
$fernbedienung = GetValueString("RemoteControl");

$text = "$fernbedienung - $taste";

if($fernbedienung == "harmony")
   {
   $text = "$text [OK]";

   switch($taste)
         {
         case "wach" :
            $text = "$text :Wach wird ausgefuehrt";
            SetValueBoolean("STATUS.WACH.Status",true);
            SetValueBoolean("STATUS.ANWESEND.Status",true);
            IPS_RunScript("Status.Verwaltung.Anwesenheit");
            break;
         case "schlaf" :
            $text = "$text :Schlaf wird ausgefuehrt";
            SetValueBoolean("STATUS.WACH.Status",false);
            SetValueBoolean("STATUS.ANWESEND.Status",true);
            IPS_RunScript("Status.Verwaltung.Anwesenheit");
            break;
         case "anwesend" :
            $text = "$text :Anwesend wird ausgefuehrt";
            SetValueBoolean("STATUS.WACH.Status",true);
            SetValueBoolean("STATUS.ANWESEND.Status",true);
            IPS_RunScript("Status.Verwaltung.Anwesenheit");
            break;
         case "abwesend" :
            $text = "$text :Abwesend wird ausgefuehrt";
            SetValueBoolean("STATUS.WACH.Status",true);
            SetValueBoolean("STATUS.ANWESEND.Status",false);
            IPS_RunScript("Status.Verwaltung.Anwesenheit");
            break;

         default:
            break;

         }
   }
   
if($fernbedienung == "dbox2")
   {
   $text = "$text [OK]";

   switch($taste)
         {
         case "l" :
            $text = "$text :links";
				$lcd = GetValueInteger("DBOX.LCD");
				$lcd = $lcd + 1;
				SetValueInteger("DBOX.LCD",$lcd);
            break;
         case "r" :
            $text = "$text :rechts";
				$lcd = GetValueInteger("DBOX.LCD");
				$lcd = $lcd + 1;
				SetValueInteger("DBOX.LCD",$lcd);
            break;

         default:
            break;

         }
   }
   
IPS_LogMessage("Verwaltung.Fernbedienung","$text");

?>