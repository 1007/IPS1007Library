<?

 $dienst= IPS_EXECUTE("sc.exe","query login",false,true);
 
 echo $dienst;

?>