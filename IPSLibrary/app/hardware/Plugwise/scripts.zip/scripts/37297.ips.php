<?


   $input = urldecode ( $IPS_VALUE );
 	echo $input;



?>