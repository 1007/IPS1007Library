<?

  	require_once IPS_GetScriptID("Funcpool.IPSLogger").".ips.php";
	
	ipslog("FATAL","Ursache","Es ist ein Fehler aufgetreten");
	
	
?>