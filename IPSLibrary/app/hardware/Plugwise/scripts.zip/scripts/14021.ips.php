<?

		require_once(IPS_GetScriptID("Funcpool").".ips.php");

		$data = "?";
		if (isset($IPS_VARIABLE)) $data = GetValue($IPS_VARIABLE);


		$s = $heute = date("D M j G:i:s ");

		$s =  $s . "\nAPC - ".$data;

      email($s);


?>