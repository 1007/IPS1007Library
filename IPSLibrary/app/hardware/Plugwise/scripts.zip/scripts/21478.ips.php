<?

//******************************************************************************
// Scripts die um Mitternacht ausgefuehrt werden
//******************************************************************************

	$roottemp = IPS_GetObjectIDByName("TEMPERATUR",0);
	
	// Fehler der Temperaturfuehler reseten
	reset_error_all($roottemp);

	// Counter der Ofen Einschaltcounter
	reset_counter_all($roottemp);

	//	Temperaturverwaltung auf Automatik
	reset_automatik_all($roottemp);


	strom_copy_tag();


//******************************************************************************
//
//******************************************************************************
function reset_automatik_all($roottemp)
	{
	
	//reset_automatik($roottemp,"BAD");
	//reset_automatik($roottemp,"WOHNEN");
	//reset_automatik($roottemp,"ARBEIT");

	
	}


//******************************************************************************
//
//******************************************************************************
function reset_automatik($roottemp,$raum)
	{
	//$raum_instance   	= IPS_GetObjectIDByName($raum,$roottemp);
	//$status_instance	= IPS_GetObjectIDByName("STATUS",$raum_instance);
	//$instance_auto   	= IPS_GetVariableIDByName ("$raum.HEIZUNG.AUTOMATIK",$status_instance);

	//SetValueBoolean($instance_auto,true);
	}
	
	
//******************************************************************************
//
//******************************************************************************
function reset_counter_all($roottemp)
	{

	//reset_counter($roottemp,"BAD");
	//reset_counter($roottemp,"WOHNEN");
	//reset_counter($roottemp,"ARBEIT");
	}

//******************************************************************************
//
//******************************************************************************
function reset_error_all($roottemp)
	{
	reset_error($roottemp,"BAD",""		);
	reset_error($roottemp,"TREPPE",""	);
	reset_error($roottemp,"AUSSEN",""	);
	reset_error($roottemp,"WOHNEN",""	);
	reset_error($roottemp,"SCHLAF",""	);
	reset_error($roottemp,"ARBEIT",""	);
	reset_error($roottemp,"WOHNEN","AUFLADUNG");
	reset_error($roottemp,"ARBEIT","AUFLADUNG");
	}
	
//******************************************************************************
//
//******************************************************************************
function reset_error($roottemp,$raum,$aufladung)
	{

	$string = $raum;
	if ( $aufladung == "AUFLADUNG" )
		$string = $raum.".".$aufladung;
	
	$raum_instance   		= IPS_GetObjectIDByName($raum,$roottemp);
	$status_instance		= IPS_GetObjectIDByName("STATUS",$raum_instance);
	$instance_error   	= IPS_GetVariableIDByName ("$string.TF.ERROR",$status_instance);
	$instance_error_bat 	= IPS_GetVariableIDByName ("$string.TF.ERROR.BATTERIE",$status_instance);


	SetValueBoolean($instance_error,false);
	SetValueBoolean($instance_error_bat,false);
	}


//******************************************************************************
//
//******************************************************************************
function reset_counter($roottemp,$raum)
	{
	
	$raum_instance   	= IPS_GetObjectIDByName($raum,$roottemp);
	$status_instance	= IPS_GetObjectIDByName("STATUS",$raum_instance);
	$instance_var   	= IPS_GetVariableIDByName ("$raum.HEIZUNG.COUNTER",$status_instance);

	SetValueInteger($instance_var,0);
	}




function strom_copy_tag()
	{

   $root_daten  	= IPS_GetObjectIDByName("STROM",IPS_GetObjectIDByName("DATEN",0));
   $root_tag    = IPS_GetObjectIDByName("TAG",$root_daten);
   $root_tag_m1 = IPS_GetObjectIDByName("TAG-1",$root_daten);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_tag),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_tag),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_tag),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_tag),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_tag),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_tag));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_tag_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_tag),0);

	$data = GetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_tag));
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_tag_m1),$data);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_tag),0);

	$data = GetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_tag));
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_tag_m1),$data);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_tag),0);


	}







?>