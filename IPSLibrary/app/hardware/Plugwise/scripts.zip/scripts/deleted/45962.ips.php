<?

 	$nacht	= 	GetValueBoolean("STATUS.SONNE.Nacht");


	// Geschirrspueler *********************************
	if ( $nacht == true OR $nacht == false )
	   {
	   SetValueInteger("AUSGANG.FLUR.LICHT.TIMER",0);
	 	SetValueBoolean("AUSGANG.FLUR.LICHT.STATUS.SOLL",$nacht);
		}
	//*************************************************


?>