<?

IPS_LogMessage("Test", "...................");


?>