<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : test.ips.php
Trigger  : 
Interval : 
*/

//WAC_Play(53905);

WAC_PlayFile(53905,"c:\l.mp3");



?>
