<?

 //Start writing your scripts between the brackets

   //IPS_LogMessage("Sender","Message");

?>