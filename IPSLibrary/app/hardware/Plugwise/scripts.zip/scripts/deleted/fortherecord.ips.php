<?

   xmlrpc_decode("....");
   
   return;

	$debug = true;
	
	$link = mysql_connect('localhost', 'root', 'k7pmde');
	if (!$link)
		{
   	$text = 'keine Verbindung m�glich: ' . mysql_error();
		if ( $debug ) echo "\n" . $text;
   	die;
		}
   if ( !mysql_select_db("fortherecord", $link))
		{
   	$text = 'Datenbank fortherecord nicht gefunden: ' . mysql_error();
		if ( $debug ) echo "\n" . $text;
		die;
		}




	$id = get_channelgroupid("1007");
	if ( !$id ) return;
	
	$channels = get_channelgroupchannels($id);

	print_r($channels);
	
	mysql_close($link);
 

function get_channelgroupid($name)
	{
	GLOBAL $debug;
	GLOBAL $link;

	echo "\nChannelgroupname: " . $name ;
	
   $result = mysql_query("SELECT * FROM channelgroup where GROUPNAME=$name", $link);
	if ( $result )
	   {
		$num_rows = mysql_num_rows($result);
//		if ( $debug ) echo "\n$num_rows Rows\n";

      $array = mysql_fetch_assoc($result);
		return $array['ChannelGroupId'];
		}
	else
	   return false;
	
	}

function get_channelgroupchannels($id)
	{
	GLOBAL $debug;
	GLOBAL $link;

	$sqlstring = "SELECT * FROM channelgroupchannel where CHANNELGROUPID='$id'";
//	echo $sqlstring;
   $result = mysql_query($sqlstring , $link);
	if ( $result )
	   {
		$num_rows = mysql_num_rows($result);
//		if ( $debug ) echo "\n$num_rows Rows\n";

      
		for ( $x=0;$x<$num_rows;$x++)
			{
			$array = mysql_fetch_assoc($result);
			$channelsid[$x] = $array;
			$return[$x] = get_channel($array);
			}

		return $return;
		}
	else
	   return false;

	}

function get_channel($array)
	{
	GLOBAL $debug;
	GLOBAL $link;

	$return = false;
	
	$channelid = $array['ChannelId'];
//	echo "\n-" . $channelid;
	$sqlstring = "SELECT * FROM channel where CHANNELID='$channelid'";
   $result = mysql_query($sqlstring , $link);
   if ( $result )
      {
		$channelarray = mysql_fetch_assoc($result);
		$return = $channelarray;
		}
	return $return;
	
	}

?>