<?

 	$dir = 'C:/Programme/IP-SYMCON2/rrd/';

	$DS1 = 'DS:TEMP:GAUGE:68400:U:U';
	$DS2 = 'DS:SOLL:GAUGE:689400:U:U';
	$DS3=  'DS:VENTIL:GAUGE:68400:U:U';
	$RRA1= 'RRA:AVERAGE:0.5:1:2016';   		#alle Werte f�r 1 Woche beahlten (5min Raster)
	$RRA2= 'RRA:AVERAGE:0.5.20:13140';   	#Stundenmittelwerte f�r 11/5 Jahre


	$file= 'temp_arbeit.rrd';
	$para = "create $dir$file --step 300 $DS1 $DS2 $DS3 $RRA1 $RRA2";   # alle 5min 1 Wert
	echo RRD_Execute($para);

?>