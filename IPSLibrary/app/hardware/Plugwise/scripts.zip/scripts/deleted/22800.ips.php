<?
   define ("INSTANCE",39171);
   
   $text = "quintessence\n\r";
   $text = "Ansage\n";
 	CSCK_SendText(INSTANCE,"quintessence\n\r");
   //CSCK_SendText(INSTANCE,$text);
   
   
   
   
?>