<?

	$stromnacht	= 	GetValueBoolean("STATUS.STROM.Nacht");


	// Geschirrspueler *********************************
	if ( $stromnacht == true OR $stromnacht == false )
	   {
	   //SetValueInteger("AUSGANG.KUECHE.GESCHIRR.TIMER",0);
	 	SetValueBoolean("AUSGANG.KUECHE.GESCHIRR.STATUS.SOLL",$stromnacht);
		}
	//*************************************************




?>