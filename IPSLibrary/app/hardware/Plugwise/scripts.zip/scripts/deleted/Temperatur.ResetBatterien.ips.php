<?


	reset_error("BAD"		,true);
	reset_error("TREPPE"	,true);
	reset_error("AUSSEN"	,true);
	reset_error("WOHNEN"	,true);
	reset_error("SCHLAF"	,true);
	reset_error("ARBEIT"	,true);
	reset_error("WOHNEN.OFEN"	,true);
	reset_error("ARBEIT.OFEN"	,true);

	reset_counter("TREPPE");
	reset_counter("AUSSEN");
	reset_counter("BAD");
	reset_counter("SCHLAF");
	reset_counter("KUECHE");
	reset_counter("FLUR");
	//reset_counter("WOHNEN.OFEN");
	reset_counter("WOHNEN1");
	reset_counter("WOHNEN2");
	reset_counter("ARBEIT");


function reset_error($raum,$debug)
	{

   $instance_error  		= "$raum.TF.ERROR";
   $instance_error_bat  = "$raum.TF.ERROR.BATTERIE";
   $instance_bat  		= "$raum.TF.BATTERIE";

	$status = false;
	SetValueBoolean($instance_error, 		$status);
	SetValueBoolean($instance_error_bat, 	$status);
	//SetValueBoolean($instance_bat, 			$status);

	
	}


function reset_counter($raum)
	{

	$var = "$raum.HEIZUNG.COUNTER";

	SetValueInteger($var,0);

	}

	
?>
