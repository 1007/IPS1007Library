<?

include  "DEF_INSTANCEN.ips.php";

	if ( !isset($IPS_VARIABLE)) 	$IPS_VARIABLE="";
	if ( !isset($IPS_SENDER)) 		$IPS_SENDER="";
	if ( !isset($IPS_VALUE)) 		$IPS_VALUE="";

   $v = $IPS_VARIABLE ;
	$v1 = $IPS_SENDER ;
	$v2 = $IPS_VALUE;
	



	
	if ( $IPS_VARIABLE == I_AUSGANG_WOHNEN_LAMPE_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_WOHNEN_LAMPE,"AUSGANG.WOHNEN.LAMPE",E_AUSGANG_WOHNEN_LAMPE_STATUS_SOLL);
	if ( $IPS_VARIABLE == I_AUSGANG_WOHNEN_TV_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_WOHNEN_TV,"AUSGANG.WOHNEN.TV",E_AUSGANG_WOHNEN_TV_STATUS_SOLL);


	if ( $IPS_VARIABLE == I_AUSGANG_ARBEIT_TV_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_ARBEIT_TV,"AUSGANG.ARBEIT.TV",E_AUSGANG_ARBEIT_TV_STATUS_SOLL);
	if ( $IPS_VARIABLE == I_AUSGANG_ARBEIT_DRUCKER_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_ARBEIT_DRUCKER,"AUSGANG.ARBEIT.DRUCKER",E_AUSGANG_ARBEIT_DRUCKER_STATUS_SOLL);
	if ( $IPS_VARIABLE == I_AUSGANG_ARBEIT_TELEFON_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_ARBEIT_TELEFON,"AUSGANG.ARBEIT.TELEFON",E_AUSGANG_ARBEIT_TELEFON_STATUS_SOLL);
	if ( $IPS_VARIABLE == I_AUSGANG_ARBEIT_DBOX_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_ARBEIT_DBOX,"AUSGANG.ARBEIT.DBOX",E_AUSGANG_ARBEIT_DBOX_STATUS_SOLL);


	if ( $IPS_VARIABLE == I_AUSGANG_TREPPE_DICKDOOF_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_TREPPE_DICKDOOF,"AUSGANG.TREPPE.DICKDOOF",E_AUSGANG_TREPPE_DICKDOOF_STATUS_SOLL);
																							
	if ( $IPS_VARIABLE == I_AUSGANG_KUECHE_GESCHIRR_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_KUECHE_GESCHIRR,"AUSGANG.KUECHE.GESCHIRR",E_AUSGANG_KUECHE_GESCHIRR_STATUS_SOLL);

	if ( $IPS_VARIABLE == I_AUSGANG_FLUR_LICHT_STATUS_SOLL
					OR $IPS_SENDER=="Execute" or $IPS_SENDER=="TimerEvent")
		do_ausgang(I_AUSGANG_FLUR_LICHT,"AUSGANG.FLUR.LICHT",E_AUSGANG_FLUR_LICHT_STATUS_SOLL);

	return;
	
function do_ausgang($instance,$ausgang,$eventid)
	{

	// Sollvariable nicht antasten !!
	// wird nur von anderen Scripts geaendert.
	// ausser bei Duration
	$soll 	= IPS_GetVariable(IPS_GetVariableID($ausgang . ".STATUS.SOLL"));
	$ist  	= IPS_GetVariable(IPS_GetVariableID($ausgang . ".STATUS"));
	$timer 	= IPS_GetVariable(IPS_GetVariableID($ausgang . ".TIMER"));

	$now     		=  time();
	$updated_ist 	=	$ist['VariableUpdated'];
	$diff_ist 		=	( $now - $updated_ist ) ;
	$updated_soll 	=  $soll['VariableUpdated'];
	$diff_soll 		= 	( $now - $updated_soll ) ;

	$ist_status  	=  $ist['VariableValue']['ValueBoolean'];
	$soll_status  	=  $soll['VariableValue']['ValueBoolean'];
	$timer_wert  	=  $timer['VariableValue']['ValueInteger'];


	//echo "\n[$diff_soll,$diff_ist,$updated_soll] rr";

	// Timer abgelaufen ?
	if ( $timer_wert > 0 AND $ist_status == true AND $diff_ist > $timer_wert )
		SetValueBoolean(IPS_GetVariableID($ausgang . ".STATUS"),false);

	$force = 0;
	// wenn 1 Stunde vorbei nochmal schalten
	if ( $diff_ist > 3600 )
	   $force = 3600;
	if ( $diff_soll < 180 )
	   $force = 180;

	//echo "\n$instance-Switch:$soll_status";
	if ( $ist_status <> $soll_status or $force > 0 )
	   {
	   //echo "\nIst[$ist_status] <> Soll[$soll_status] or Force[$force] $ausgang";
	   
		if ( $timer_wert == 0 )
		   {
		   //echo "\n$instance-Switch:$soll_status";
			FS20_SwitchMode($instance,$soll_status);
			}
		else
		   {
			if ( $soll_status == true )
				{
				//echo "\nDuration:$timer_wert";
	   		FS20_SwitchDuration($instance,true,$timer_wert);
				SetValueBoolean(IPS_GetVariableID($ausgang . ".STATUS.SOLL"),false);
				}
			if ( $ist_status == false )
				{
				//SetValueBoolean(IPS_GetVariableID($ausgang . ".STATUS"),false);
				}


			}
	   
	   }



 
	}
	

?>

