<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : Bewegung.Verwaltung.ips.php
Trigger  : 
Interval : 
*/

require_once("DEF_INSTANCEN.IPS.PHP");
require_once("DEF_HOME.IPS.PHP");
require_once("FUNCPOOL.IPS.PHP");
require_once("DEF_VOICE.IPS.PHP");

$c = $IPS_VARIABLE;

echo "bewegung";

switch($c)
   {
   case I_EINGANG_PIRI_TREPPE:

         if ( GetValueBoolean("STATUS.SONNE.Nacht") == true )
            {
            FS20_SwitchDuration(I_DICKDOOF, TRUE,60);
            }
        
         break;
   case I_EINGANG_PIRI_WOHNEN:

         if ( GetValueBoolean("STATUS.SONNE.Nacht") == true )
            {
            FS20_SwitchDuration(I_STEINLAMPE, TRUE,60);
            }

         break;


   }


?>
