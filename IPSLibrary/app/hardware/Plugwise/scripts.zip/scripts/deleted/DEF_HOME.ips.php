<?

// Instanzen definieren


 // Profile definieren
define("PROFIL_NULL"				,	0);
define("PROFIL_FRUEHSCHICHT"	,	1);
define("PROFIL_SPAETSCHICHT"	,	2);
define("PROFIL_NACHTSCHICHT"	,	3);
define("PROFIL_NORMALSCHICHT"	,	4);
define("PROFIL_WOCHENENDE"		,	11);
define("PROFIL_URLAUB"			,	15);
define("PROFIL_ANWESEND"		,	21);
define("PROFIL_ABWESEND"		,	22);
define("PROFIL_AUFLADUNG"		,	100);
define("PROFIL_ALLE"				,	999);

// Raeume definieren
define ("RAUM_BAD"   	, 1);
define ("RAUM_WOHNEN"	, 2);
define ("RAUM_ARBEIT"	, 3);
define ("RAUM_SCHLAF"	, 4);
define ("RAUM_TREPPE"	, 5);
define ("RAUM_FLUR"		, 6);
define ("RAUM_KUECHE"	, 7);
define ("RAUM_AUSSEN"	, 8);


function get_profil_string($profil)
   {
   $string = "?";

   if ( $profil == 0   ) $string = "NULL";
   if ( $profil == 1   ) $string = "FRUEHSCHICHT";
   if ( $profil == 2   ) $string = "SPAETSCHICHT";
   if ( $profil == 3   ) $string = "NACHTSCHICHT";
   if ( $profil == 4   ) $string = "NORMALSCHICHT";
   if ( $profil == 11  ) $string = "WOCHENENDE";
   if ( $profil == 15  ) $string = "URLAUB";
   if ( $profil == 21  ) $string = "ANWESEND";
   if ( $profil == 22  ) $string = "ABWESEND";
   if ( $profil == 100 ) $string = "AUFLADUNG";
   if ( $profil == 999 ) $string = "ALLE";

   
   return $string;
   }

function get_raum_string($raum)
   {
   $string = "?";

   if ( $raum == 1 ) $string = "BAD";
   if ( $raum == 2 ) $string = "WOHNEN";
   if ( $raum == 3 ) $string = "ARBEIT";
   if ( $raum == 4 ) $string = "SCHLAF";
   if ( $raum == 5 ) $string = "TREPPE";
   if ( $raum == 6 ) $string = "FLUR";
   if ( $raum == 7 ) $string = "KUECHE";
   if ( $raum == 8 ) $string = "WOHNEN1";
   if ( $raum == 9 ) $string = "WOHNEN2";
   if ( $raum == 10) $string = "AUSSEN";

   return $string;
   }
   


?>
