<?

 ################################################################################

/* Zum aktivieren Bundesland und Region ausw�hlen und // davor entfernen.
Es kann jeweils nur eine Kennung und Region ausgew�hlt werden! */

################################################################################
/*----------------------------------------------------------------------------*/
################################################################################
$kennung = ""; //nicht �ndern
################################################################################
/*------------------Wetterbericht Bundesl�nder Tag 1-4------------------------*/
################################################################################
$kennung = "DWEG_"; // Hessen
//$kennung = "DWEI_"; // Rheinland Pfalz und Saarland
//$kennung = "DWEH_"; // Nordrhein-Westfalen
//$kennung = "DWSG_"; // Baden-W�rtemberg
//$kennung = "DWMG_"; // Bayern
//$kennung = "DWLG_"; // Sachsen
//$kennung = "DWLI_"; // Th�ringen
//$kennung = "DWLH_"; // Sachsen-Anhalt
//$kennung = "DWPG_"; // Brandenburg und Berlin
//$kennung = "DWPH_"; // Mecklenburg-Vorpommern
//$kennung = "DWHG_"; // Niedersachsen und Bremen
//$kennung = "DWHH_"; // Schleswig Holstein und Hamburg
################################################################################
/*----------------------------------------------------------------------------*/
################################################################################
$region = ""; // nicht �ndern
################################################################################
/*-----------------------------Regionen---------------------------------------*/
################################################################################
$region = "Mitte"; // Hessen, Rheinlandpfalz und Saarland
//$region = "Nordost"; // Mecklenburg-Vorpommern, Berlin und Brandenburg
//$region = "West"; // Nordrhein-Westfalen
//$region = "Nordwest"; //Schleswig Holstein, Hamburg, Bremen und Niedersachsen
//$region = "Suedwest"; // Baden-W�rtemberg
//$region = "Suedost"; // Bayern
//$region = "Ost"; // Sachsen, Sachsen-Anhalt und Th�ringen
################################################################################
/*-----------------------------Wetterwarnungen--------------------------------*/
################################################################################
$warnung = "OF_x_x_0.gif"; // Hessen
//$warnung = "MS_x_x_0.gif"; // Bayern
//$warnung = "SU_x_x_0.gif"; // Baden-W�rttemberg
//$warnung = "TR_x_x_0.gif"; // Rheinland Pfalz und Saarland
//$warnung = "EM_x_x_0.gif"; // Nordrhein-Westfalen
//$warnung = "HN_x_x_0.gif"; // Niedersachsen und Bremen
//$warnung = "SG_x_x_0.gif"; // Schleswig-Holstein und Hamburg
//$warnung = "RW_x_x_0.gif"; // Mecklenburg-Vorpommern
//$warnung = "PD_x_x_0.gif"; // Berlin und Brandenburg
//$warnung = "LZ_x_x_0.gif"; // Sachsen
//$warnung = "MB_x_x_0.gif"; // Sachsen-Anhalt
//$warnung = "EF_x_x_0.gif"; // Th�ringen
/*----------------------------------------------------------------------------*/
$schilder = "SchilderOF.jpg"; // Hessen, Rheinlandpfalz und Saarland
//$schilder = "SchilderEM.jpg"; // Nordrhein-Westfalen
//$schilder = "SchilderHA.jpg"; // Schleswig Holstein, Hamburg, Bremen und Niedersachsen
//$schilder = "SchilderLZ.jpg"; // Sachsen, Sachsen-Anhalt und Th�ringen
//$schilder = "SchilderMS.jpg"; // Bayern
//$schilder = "SchilderPD.jpg"; // Mecklenburg-Vorpommern, Berlin und Brandenburg
//$schilder = "SchilderSU.jpg"; // Baden-W�rtemberg
/*----------------------------------------------------------------------------*/
$factorwarnung = 0.9; // Bildscalierung Schilder(Warnungen)
$factorWetterwarnung = 0.8; // Bildscalierung Wetterwarnungen(�bersichtsseite)
################################################################################
/*--------------------Name oder Plz eintragen---------------------------------*/
################################################################################
$ortGoogle = "65428";
/*---------------------------Anzeige �bersicht--------------------------------*/
$ort = "Wetter Ruesselsheim";
$ueberschriftKarte = "Wetterwarnungen Hessen";
################################################################################
/*----------------------------------------------------------------------------*/
################################################################################
/*------------------Username und Passwort eintragen---------------------------*/
################################################################################
$ftp_server = 'ftp-outgoing.dwd.de'; // Adresse FTP-Server
$ftp_user_name = "gds41971"; // Username
$ftp_user_pass = "LfQyrlGW"; // Passwort
################################################################################
/*----------------------------------------------------------------------------*/
$umlaute = array("�","�","�","�","�","�","�");
$replace = array("&auml;","&ouml;","&uuml;","&Auml;","&Ouml;","&Uuml;","&szlig;");
$ueberschriftKarte = str_replace($umlaute, $replace, $ueberschriftKarte);
$ort = str_replace($umlaute, $replace, $ort);

?>