<?

    include "52920.ips.php";// Include Roomba Funcpool

	echo "\nStart2";
	$status = command(QUERY_LIST,array(1,100));

	if ( $status ) echo "\nCommand erfolgreich"; else echo "\nCommand nicht erfolgreich";

?>