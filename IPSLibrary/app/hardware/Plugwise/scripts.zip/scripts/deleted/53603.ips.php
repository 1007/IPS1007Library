<?

 $id1= 12537 ;
$id2= 51095 ;
$id3= 44036 ;
$licht_fluter=15250;
$licht_schraege=13948;
$tv=22721;
$actual_time = date("H:i");
$day = date("w");

echo $actual_time;
echo "\n";
echo $day;
{
//Wenn PIRI Bad oder Dusche "True" sendet,
//+ TV, Licht Wohnung aus und
//+ Zwischen 24h und 7h  dann Licht dimmen Stufe 5.
    If ($actual_time >= "00:00" and $actual_time <= "06:59" )
        {
            echo "\n10";
            
        }
//+ Zwischen 7h und 12h  Licht Stufe 15
   If ($actual_time >= "07:00" and $actual_time <= "12:00" )
        {
            echo "\n11";

		  }
//Ansonsten  Licht dimmen auf Stufe 11
   If ($actual_time > "12:00" )
        {
   echo "\n12";
                 }
}

?>