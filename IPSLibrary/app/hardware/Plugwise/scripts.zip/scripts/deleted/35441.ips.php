<?

 echo "\nLighthouse";
 
 
?>