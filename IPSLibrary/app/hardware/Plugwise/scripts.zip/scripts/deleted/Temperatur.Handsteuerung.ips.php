<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : Temperatur.Handsteuerung.ips.php
Trigger  : 
Interval : 
*/

  switch ($IPS_COMPONENT) // enth�lt die in IPSYMID hinterlegte Kennung
      {

      case "TEMPERATUR_BAD_HAND_PLUS":       // Behandlung der
            $t = GetValueFloat("BAD.SOLL.TEMPERATUR.Hand");
            $t = $t + 0.5;
            SetValueFloat("BAD.SOLL.TEMPERATUR.Hand",$t);
      break;

      case "TEMPERATUR_BAD_HAND_MINUS":       // Behandlung der
            $t = GetValueFloat("BAD.SOLL.TEMPERATUR.Hand");
            $t = $t - 0.5;
            if ( $t < 0 ) $t = 0;
            SetValueFloat("BAD.SOLL.TEMPERATUR.Hand",$t);
      break;

      case "TEMPERATUR_WOHNEN_HAND_PLUS":       // Behandlung der
            $t = GetValueFloat("WOHNEN.SOLL.TEMPERATUR.Hand");
            $t = $t + 0.5;
            SetValueFloat("WOHNEN.SOLL.TEMPERATUR.Hand",$t);
      break;

      case "TEMPERATUR_WOHNEN_HAND_MINUS":       // Behandlung der
            $t = GetValueFloat("WOHNEN.SOLL.TEMPERATUR.Hand");
            $t = $t - 0.5;
            if ( $t < 0 ) $t = 0;
            SetValueFloat("WOHNEN.SOLL.TEMPERATUR.Hand",$t);
      break;

      case "TEMPERATUR_ARBEIT_HAND_PLUS":       // Behandlung der
            $t = GetValueFloat("ARBEIT.SOLL.TEMPERATUR.Hand");
            $t = $t + 0.5;
            SetValueFloat("ARBEIT.SOLL.TEMPERATUR.Hand",$t);
      break;

      case "TEMPERATUR_ARBEIT_HAND_MINUS":       // Behandlung der
            $t = GetValueFloat("ARBEIT.SOLL.TEMPERATUR.Hand");
            $t = $t - 0.5;
            if ( $t < 0 ) $t = 0;
            SetValueFloat("ARBEIT.SOLL.TEMPERATUR.Hand",$t);
      break;





      default:

      break;


      }
      
?>
