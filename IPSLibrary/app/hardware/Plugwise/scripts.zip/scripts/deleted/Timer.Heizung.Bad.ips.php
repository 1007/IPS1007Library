<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : Timer.Heizung.Bad.ips.php
Trigger  : 
Interval : 
*/


      FS20_SwitchDuration(40527, TRUE,3600);


?>
