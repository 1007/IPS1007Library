<?
//******************************************************************************
// Drucker fuer x Minuten einschalten
// bis SPOOL Verzeichnis leer
//******************************************************************************

   $time = 180;

 	$root_ausgaenge   = IPS_GetObjectIDByName("AUSGAENGE",0);
	$raum_instance 	= IPS_GetObjectIDByName("ARBEIT",$root_ausgaenge);
	$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.ARBEIT.DRUCKER",$raum_instance);
	$soll_instance 	= IPS_GetObjectIDByName("AUSGANG.ARBEIT.DRUCKER.STATUS.SOLL",$ausgang_instance);
	$timer_instance 	= IPS_GetObjectIDByName("AUSGANG.ARBEIT.DRUCKER.TIMER.SOLL",$ausgang_instance);

	
	$spool = "C:\WINDOWS\system32\spool\PRINTERS";
	$print = false;

	$handle = opendir($spool);
	while ( $file = readdir($handle) )
   	{
      if ( $file != "." && $file != ".." )
        	$print = true;
        
      }
	closedir($handle);


	if ( $print )
   	{
   	SetValueInteger($timer_instance,$time);
		SetValueBoolean($soll_instance,true);
   	}

?>
