<?

 //F�gen Sie hier ihren Skriptquellcode ein



	$ok = Sys_Ping("192.168.11.3",500);
	echo "\n[$ok]";
	sleep(3);
	$ok = Sys_Ping("192.168.11.3",1500);
	echo "\n[$ok]";
   sleep(3);
	$ok = Sys_Ping("192.168.11.3",2000);
	echo "\n[$ok]";
   sleep(3);
	$ok = Sys_Ping("192.168.11.3",2500);
	echo "\n[$ok]";
	sleep(3);
	$ok = Sys_Ping("192.168.11.3",3000);
	echo "\n[$ok]";
   sleep(3);
	$ok = Sys_Ping("192.168.11.3",3500);
	echo "\n[$ok]";
	sleep(3);
	$ok = Sys_Ping("192.168.11.3",4000);
	echo "\n[$ok]";
	sleep(3);
	$ok = Sys_Ping("192.168.11.3",4500);
	echo "\n[$ok]";
   sleep(3);
	$ok = Sys_Ping("192.168.11.3",5000);
	echo "\n[$ok]";
	sleep(3);
	$ok = Sys_Ping("192.168.11.3",5500);
	echo "\n[$ok]";




?>