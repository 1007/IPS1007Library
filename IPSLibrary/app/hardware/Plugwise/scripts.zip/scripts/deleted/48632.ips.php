<?

 SMTP_SendMail(18910,"jjj","lllllllllllllllllll");
 

?>