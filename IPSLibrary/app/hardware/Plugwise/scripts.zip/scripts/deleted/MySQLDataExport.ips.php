<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : MySQLDataExport.ips.php
Trigger  :
Interval :
*/
define("VarMySQLDataCounter", 12794, true);
$MySQLHost = "192.168.10.8";
$username  = "root";
$password  = "k7pmde";

$link = mysql_connect($MySQLHost, $username, $password) or die("Keine Verbindung m�glich!");
mysql_select_db("ipsdata") or die("Auswahl der Datenbank fehlgeschlagen");

$counter = GetValue(VarMySQLDataCounter);
If ($counter >= 4 ) {
	$select = "SELECT * FROM dataconf";
	SetValue(VarMySQLDataCounter, 0);
	$polltime = 5;
} else {
	$select = "SELECT * FROM dataconf where polltime='1'";
	SetValue(VarMySQLDataCounter, $counter + 1);
	$polltime = 1;
}

$vardat = mysql_query($select);
$insert = "INSERT INTO data SET date='".date("Ymd")."', time='".date("His")."', polltime='".$polltime."'";

while ($row = mysql_fetch_array($vardat)) {
	$insert = $insert.", `".$row['ipsvar']."`='".GetVarValue($row['ipsvar'], $row['vartype'])."'";
}

//echo $insert;
$query = mysql_query($insert);
mysql_close($link);

function GetVarValue($var, $vartype){

	if (IPS_VariableExists((int)$var)) {
		$value = GetValue((int)$var);
		if ($vartype == "Boolean") {
			return ($value ? 1 : 0);
		} else {
			return $value;
		}
	}
	IPS_LogMessage("MySQLDataExport","Die IPS Variable #'".$var."' existiert nicht mehr. Bitte aus der Poller Konfiguration entfernen ! Es wurde eine 0 in die Datenbank geschrieben");
	return 0;
}
?>