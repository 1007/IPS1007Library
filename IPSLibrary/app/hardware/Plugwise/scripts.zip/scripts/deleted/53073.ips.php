<?



function refreshfeed()
	{
	
	newfeed("","");
	
	}

function newfeed($newtitel,$newdescription)
	{

	$anzahl  = 20 ;
	$pfad 	= IPS_GetKernelDir() . "webfront\\rss\\";
	$datafile= $pfad . "rssdata.txt";
	$rssfile = $pfad . "rss.xml";

	$now 		= date("H:i");

	$aussen = number_format(GetValueFloat("AUSSEN.TF.TEMPERATUR"),1);
	$arbeit = number_format(GetValueFloat("ARBEIT.TF.TEMPERATUR"),1);
	$wohnen = number_format(GetValueFloat("WOHNEN.TF.TEMPERATUR"),1);
	$schlaf = number_format(GetValueFloat("SCHLAF.TF.TEMPERATUR"),1);
	$treppe = number_format(GetValueFloat("TREPPE.TF.TEMPERATUR"),1);
	$bad    = number_format(GetValueFloat("BAD.TF.TEMPERATUR"),1);

	$aussen = rawurlencode($aussen);
	$arbeit = rawurlencode($arbeit);
	$wohnen = rawurlencode($wohnen);
	$schlaf = rawurlencode($schlaf);
	$treppe = rawurlencode($treppe);
	$bad    = rawurlencode($bad);

	$titel0 = "$now Temperaturen";
	$description0 = 	"Aussen: ". $aussen . "�" . "<br>" .
							"Wohnen: ". $wohnen . "�" . "<br>" .
							"Arbeit: ". $arbeit . "�" . "<br>" .
							"Schlaf: ". $schlaf . "�" . "<br>" .
							"Bad:    ". $bad . "�" . "<br>" .
							"Treppe: ". $treppe . "�" . "<br>" 
							;



	$result = make_rss_feed($datafile,$rssfile,$anzahl,
										$titel0,$description0,
										$newtitel,$newdescription);
										
	$result = make_rss_feed($datafile,$rssfile,$anzahl,
										$titel0,$description0,
										"","");

	}

function make_rss_feed($datafile,$rssfile,$anzahl,
								$titel0,$description0,
								$newtitel,$newdescription)
	{

	$error = 0;

	$now1 		= date("D, j M Y H:i:s")." GMT";
	$now1 		= date("D, j M Y H:i:s");
	$now2 		= date("H:i");

	
	
	if ( !file_exists($datafile)) touch($datafile);
	$olddata = file($datafile);
	$anzahlold = count($olddata);
	if ( $anzahlold<$anzahl)
		$anzahl = $anzahlold;

	
	if ( $newtitel != "" )
	   { 
		$newtitel = "$now2 $newtitel";
		$guid = code(10);
		$newzeile = "<item>".
					"<title>".$newtitel."</title>".
					"<link>http://home.inisnet.de:82/rss/rss.xml</link>".
					"<description>".$newdescription."</description>".
					"<pubDate>".$now1."</pubDate>".
					"<guid>".$guid."</guid>".
					"</item>";
		$newdata[0] = $newzeile.chr(13).chr(10);
		for ($x=1;$x<=($anzahl);$x++)
			$newdata[$x] = $olddata[$x-1];
		if ( !$handle = fopen($datafile,"w"))	{ $error = 1; return $error;}
		foreach ( $newdata as $zeile ) {
	   	if ( !fwrite($handle,$zeile )) 		{ $error = 2; return $error;}}
		fclose($handle);
		}
	else
	   {
		$newdata = $olddata;
	   }



	$rssdata[0] = 	"<?xml version='1.0' encoding='ISO-8859-1'?>".chr(13).chr(10);
	$rssdata[1] = 	"<rss version='2.0'>".chr(13).chr(10);
	$rssdata[2] = 	chr(9)."<channel>".chr(13).chr(10);
	$rssdata[3] = 	chr(9).chr(9)."<title>IPSymcon 1007 News</title>".chr(13).chr(10).
					  	chr(9).chr(9)."<description>Homeserver</description>".chr(13).chr(10).
					  	chr(9).chr(9)."<link>http://mist2.k170.de:82/rss/rss.xml</link>".chr(13).chr(10).
					  	chr(9).chr(9)."<lastBuildDate>".$now1."</lastBuildDate>".chr(13).chr(10);

	$guid = "1007";

	$rssdata[4] = 	chr(9).chr(9)."<item>".
						"<title>".$titel0."</title>".
						"<link>http://home.inisnet.de:82/rss/rss.xml</link>".
						"<description>".$description0."</description>".
						"<pubDate>".$now1."</pubDate>".
                  "<guid>".$guid."</guid>".
						"</item>".chr(13).chr(10);

	$rssdata[4] = str_replace("<br>","\n",$rssdata[4]);

	for ($x=0;$x<$anzahl;$x++)
	   {
		$zeile = chr(9).chr(9).$newdata[$x];
		$rssdata[$x+5] = str_replace("<br>","\n",$zeile);
		}

	$rssdata[$anzahl+5] = chr(9)."</channel>".chr(13).chr(10);
	$rssdata[$anzahl+6] = "</rss>".chr(13).chr(10);

	if ( !$handle = fopen($rssfile,"w")) 	{ $error = 3; return $error;}
	foreach ( $rssdata as $zeile ){
		if ( !fwrite($handle,$zeile )) 		{ $error = 4; return $error;}}
	fclose($handle);

	return $error;

	}



function code($length)
{
  return strtoupper(substr(md5(rand(1,99999).date("FjYgias")), 0, $length));
}


?>