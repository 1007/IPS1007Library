<?
// Verwaltung Status ( WACH    ANWESEND )

$text = "?";


return;


//*******************************************************************
//    Anwesend
//*******************************************************************
$anwesend_counter = GetValueInteger("STATUS.ANWESEND.Counter");
$text = "Anwesendcounter:$anwesend_counter";
if ( $anwesend_counter <> 0 )
   {
   if ( $anwesend_counter ==  1 )
      {
      SetValueBoolean("STATUS.ANWESEND.Status",true);
      SetValueBoolean("STATUS.WACH.Status",true);
      $anwesend_counter = 0;
      IPS_RunScript("Status.Verwaltung.Anwesenheit");
      }
   if ( $anwesend_counter == -1  )
      {
      SetValueBoolean("STATUS.ANWESEND.Status",false);
      SetValueBoolean("STATUS.WACH.Status",true);
      $anwesend_counter = 0;
       IPS_RunScript("Status.Verwaltung.Anwesenheit");
      }
   if ( $anwesend_counter < 0 )  $anwesend_counter++;
   if ( $anwesend_counter > 0 )  $anwesend_counter--;

   SetValueInteger("STATUS.ANWESEND.Counter",$anwesend_counter);
   }
//*******************************************************************


//*******************************************************************
//    Wach
//*******************************************************************
$wach_counter     = GetValueInteger("STATUS.WACH.Counter");
$text = "$text Wachcounter:$wach_counter";
if ( $wach_counter <> 0 )
   {
   if ( $wach_counter ==  1  )
      {
      SetValueBoolean("STATUS.WACH.Status",true);
      SetValueBoolean("STATUS.ANWESEND.Status",true);
      $wach_counter = 0;
      IPS_RunScript("Status.Verwaltung.Anwesenheit");
      }
   if ( $wach_counter == -1  )
      {
      SetValueBoolean("STATUS.WACH.Status",false);
      SetValueBoolean("STATUS.ANWESEND.Status",true);
      $wach_counter = 0;
      IPS_RunScript("Status.Verwaltung.Anwesenheit");
      }
   if ( $wach_counter < 0 )   $wach_counter++;
   if ( $wach_counter > 0 )   $wach_counter--;

   SetValueInteger("STATUS.WACH.Counter",$wach_counter);

   }
//*********************************************************************




//IPS_LogMessage("Verwaltung.Status",$text);

?>
