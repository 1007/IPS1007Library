<?

 //

   $s  = IPS_GetScript(IPS_GetScriptID("mysql"));
   require_once($s['ScriptFile']);


   if ( isset($IPS_VARIABLE))  $v = $IPS_VARIABLE ;  else $v = "?";

   IPS_LogMessage("MYSQL.out","$c-$v");
   //$v=31517;
   $link = mysql_ips_open();
   mysql_ips_insert_out($link,$v);
   mysql_ips_close($link);


?>