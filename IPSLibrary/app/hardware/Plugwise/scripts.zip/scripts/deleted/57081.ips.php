<?
$dir = 'C:/Programme/IP-SYMCON2/rrd/';
$file ='temp_arbeit.rrd'; # Filename RRD datenbank
$DB = "C\:/Programme/IP-SYMCON2/rrd/$file";  # Pfad & Filename

$pngname = 'C:\/Programme\/IP-SYMCON2\/rrd\/arbeit_temp.png'; # Name des zu erstellenden Plot

$VERT_LABEL = "--vertical-label=Wohnzimmer";  #Beschriftung
$TITEL =    "--title=Raumtemperatur";

$start = time() - 36000;  # Startzeit = jetzt - 10 Stunde
$end = time(); # Endzeit = jetzt

$style = "--heigh=150 --width=400";  # Gr��e des Plot
$plot_1 = "DEF:ist=$DB:TEMP:AVERAGE LINE2:ist#0000FF:Ist-Temperatur";   # 1. Line ist Ist-temperatur
$plot_2 = "DEF:soll=$DB:SOLL:AVERAGE AREA:soll#2A07E8DD:Soll-Temperatur"; # 2. Fl�che mit Solltemperatur

$para= "graph $pngname --start=$start --end=$end $style $VERT_LABEL $TITEL $plot_1 $plot_2";  # Nun alles zusammenf�hren

echo rrd_execute($para);  # Plot erzeugen


?>