<?

 IPSUtils_Include ("IPSModuleManager.class.php",
                    "IPSLibrary::install::IPSModuleManager");

  InstallModule('IPSLogger');
  InstallModule('IPSComponent');
  InstallModule('IPSMessageHandler');
  InstallModule('NetPlayer',     'NetPlayer_DemoConfiguration.inc.php',
                'IPSLibrary::config::modules::NetPlayer');
  InstallModule('Entertainment', 'Entertainment_DemoConfiguration.inc.php ',
                'IPSLibrary::config::modules::Entertainment');

  function InstallModule($module, $configFile='', $configNamespace='') {
    $moduleManager = new IPSModuleManager($module);
    $moduleManager->LoadModule('C:\IPSYMCON\\');
    if ($configFile <> '') {
      $fileHandler = new IPSFileHandler();
      $fileHandler->CreateFileFromExample($configFile,
                        str_replace('Demo', '',$configFile), $configNamespace);
    }

    $moduleManager->InstallModule(true);
  }
?>