<?

 require "./FeedGenerator.ips.php";
require "../web/base/xmlparser.ips.php";

$rssFilePath = __myWebHome."\\rss\\feed.xml";

$rssFilePath 	= IPS_GetKernelDir() . "webfront\\rss\\feed.xml";

// Using the IPS_RSSFeedGenerator
$ipsFeed = new IPS_RSSFeedGenerator("IPS news", "test news from IPS");
// Links-click auf dem Info button �ffnet diese Seite:
$ipsFeed->setLink("http://www.domain.com:8000/");

// Add any additional Custom Item (for example ISDN Calls)
$itemISDN = new FeedItem();
$itemISDN->title = "ISDN: Calls";
$itemISDN->link = "www.domain.net";
$itemISDN->description = "NewCalls";
$itemISDN->date = date("d M Y H:i");
$ipsFeed->addItem($itemISDN);
// Feed speichern
$ipsFeed->saveFeed("RSS2.0", $rssFilePath);
// Add any additional Custom Item (for example ISDN Calls)
$itemISDN = new FeedItem();
$itemISDN->title = "Calls";
$itemISDN->link = "www.domain.net";
$itemISDN->description = "NewCalls";
$itemISDN->date = date("d M Y H:i");
$ipsFeed->addItem($itemISDN);
// Feed speichern
$ipsFeed->saveFeed("RSS2.0", $rssFilePath);
// Add any additional Custom Item (for example ISDN Calls)
$itemISDN = new FeedItem();
$itemISDN->title = "test";
$itemISDN->link = "www.domain.net";
$itemISDN->description = "NewCalls";
$itemISDN->date = date("d M Y H:i");
$ipsFeed->addItem($itemISDN);
// Feed speichern
$ipsFeed->saveFeed("RSS2.0", $rssFilePath);
?>