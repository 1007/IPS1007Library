<?

 	$pfad = IPS_GetKernelDir();
 	$pfad = $pfad ."webfront\\rss\\";

	$datafile = $pfad . "rssdata.txt";
	$rssfile  = $pfad . "rss.xml";
	

 	echo $pfad ."-". $datafile."-".$rssfile;

	$newtitel = "Test";
	$newdescription = "Beschreibung";

	$newdata = make($datafile,$newtitel,$newdescription);
	save($rssfile,$newdata);
	
	

function make($file,$newtitel,$newdescription)
	{
	if (!file_exists($file)) touch($file);
	$data = file($file);

	$zeile = "\\<item><title>";

	echo "\n$zeile";
	
	$newdata[0] = "<?xml version='1.0' encoding='ISO-8859-1'?>";
	$newdata[1] = "<rss version='0.91' >";
	$newdata[2] = "<channel>";
	$newdata[3] = "<title>IPSymcon Status</title><description>Homeserver</description>";
	$newdata[4] = "<link>http://mist2.k170.de</link>";


	$newdata[5] = "<item><title>".$newtitel."</title><description>".$newdescription."</description></item>";

	$newdata[6] = "</channel>";
	$newdata[7] = "</rss>";
	
	return $newdata;
	}

function save($rssfile,$data)
	{
	
	if (is_writable($rssfile))
		{
    	if (!$handle = fopen($rssfile, "w"))
		 	{
         print "\nKann die Datei $rssfile nicht �ffnen";
         exit;
    		}
	  foreach ($data as $zeile )
	      {
	      $zeile = $zeile .chr(13);
	      
    		if (!fwrite($handle, $zeile))
		 		{
        		print "\nKann in die Datei $rssfile nicht schreiben";
    			}
			}
			
    	print "\nFertig, in Datei $rssfile wurde geschrieben";

    	fclose($handle);

		}
	else
		{
    	print "\nDie Datei $rssfile ist nicht schreibbar";
		}
	}
	

?>