<?
/*
 *  (c) 2006 by Zapp (IPS_RSSFeedGenerator)
 *
 *  Note: Parts of the FeedGenerator code are taken from the FeedCreator
 *  by Kai Blankenhorn <kaib@bitfolge.de>
 *
 * This  library  is  free  software;  you can redistribute it and/or modify it
 * under  the  terms  of the GNU Library General Public License as published by
 * the  Free  Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This  library is distributed in the hope that it will be useful, but WITHOUT
 * ANY  WARRANTY;  without  even  the  implied  warranty  of MERCHANTABILITY or
 * FITNESS  FOR  A  PARTICULAR  PURPOSE.  See  the  GNU  Library General Public
 * License for more details.
 *
 * You  should  have  received a copy of the GNU Library General Public License
 * along  with  this  library;  if  not, write to the Free Software Foundation,
 */
//----------------------------------------------------------------------------
// USAGE:
// You can use the Class FeedGenerator to Create a standard 2.0 Feed with
// the content you like or you can use the Class IPS_RSSFeedGenerator
// to generate automatically a Feed containing all the Modules of the Types
// you indicate. The Class IPS_RSSFeedGenerator requires the IPS_XMLPARSER
// ---------------------------------------------------------------------------
// CLASS IPS_RSSFeedGenerator
//
// require "./FeedGenerator.ips.php";
// require "../web/base/xmlparser.ips.php";
//
// $ipsFeed = new IPS_RSSFeedGenerator("IPS news", "Test news from IPS");
// $ipsFeed->setLink("www.domain.com");
// $ipsFeed->addModules("FHT", "www.domain.com/fhts/");
// $ipsFeed->saveFeed("RSS2.0", "testfeed.xml");
//
// CLASS FEEDGENERATOR
//
// require "./FeedGenerator.ips.php";
// require "../web/base/xmlparser.ips.php";
//
// $rss = new FeedGenerator();
// $rss->title = "IPS news";
// $rss->description = "test news from IPS";
//
// optional
// $rss->link = "http://www.domain.net/rssfeed/";
// $rss->syndicationURL = "www.domain.net/rssfeed/";
//
// $item = new FeedItem();
// $item->title = "Test";
// $item->link = "www.naphane.net";
// $item->description = "This is a Test";
// $item->date = date("d M Y H:i");
// $item->source = "http://www.domain.net";
// $item->author = "Zapp";
//
// $rss->addItem($item);
//
// $rss->saveFeed("RSS2.0", "testfeed.xml");


// Version string.
define("IPS_FEEDGENERATOR_VERSION", "IPS_RSSFeedGenerator 0.5");

class FeedGenerator extends FeedCreator
{

   private $_feed;

	public function __construct()
	{
      // Empty for now
	}
	
	public function createFeed($format = "RSS2.0")
   {
		$this->setFormat($format);
		return $this->_feed->createFeed();
	}

	public function saveFeed($format = "RSS2.0", $pathToXMLFile)
   {
      $this->setFormat($format);
		$this->_feed->saveFeed($pathToXMLFile);
	}
	
	private function setFormat($format)
	{
      switch (strtoupper($format)) {

			case "2.0":
			case "RSS2.0":
				$this->_feed = new RSSFeed20();
				break;
         default:
            echo "FeedGenerator only implemented for RSS 2.0\r\n";
				$this->_feed = new RSSFeed20();
				break;
      }
      $vars = get_object_vars($this);
	   foreach ($vars as $key => $value) {
		    // prevent overwriting of properties "contentType", "encoding"; do not copy "feed" itself
		    if (!in_array($key, array("_feed", "contentType", "encoding"))) {
			      $this->_feed->{$key} = $this->{$key};
		    }
	   }
	}

} // End of the FeedGenerator Class


/**
 * A FeedItem is a part of a FeedCreator feed.
 * modified from Kai Blankenhorn <kaib@bitfolge.de>
 */
class FeedItem {
	// Mandatory attributes of an item.
	public $title, $description, $link;

	// Optional attributes of an item.
	public $author, $authorEmail, $image, $category, $comments, $guid, $source, $creator;

	public $date;
}

/**
 * FeedCreator is the interface for concrete
 * implementations that implement a specific format of syndication.
 * modified from Kai Blankenhorn <kaib@bitfolge.de>
 */
class FeedCreator {

	// Mandatory attributes of a feed.
	public $title, $description, $link;

	// Optional attributes of a feed.
	public $syndicationURL, $image, $language, $copyright, $pubDate, $lastBuildDate, $editor, $editorEmail, $webmaster, $category, $docs, $ttl, $rating, $skipHours, $skipDays;

	// Items
	public $items = Array();

	// This feed's MIME content type.
	public $contentType = "application/xml";

	// This feed's character encoding.
	public $encoding = "ISO-8859-1";

	// Adds an FeedItem to the feed
	public function addItem($item) {
		$this->items[] = $item;
	}
	
	// Create the feed.
	// This method has to be implemented
	public function createFeed() {
	}
	
   // Save the feed in a file.
	public function saveFeed($filename="") {
		$feedFile = fopen($filename, "w+");
		if ($feedFile) {
			fputs($feedFile,$this->createFeed());
			fclose($feedFile);
		} else {
			echo "Error creating feed file, please check write permissions.";
		}
	}

}

// RSSFeed20 is a FeedCreator that implements RSS 2.0.
// modified from Kai Blankenhorn <kaib@bitfolge.de>

class RSSFeed20 extends FeedCreator {

	// RSS feed's version number.
	private $RSSVersion;

	public function __construct() {
		$this->setRSSVersion("2.0");
		$this->contentType = "application/rss+xml";
	}

	// RSS feed's version number.
	private function setRSSVersion($version) {
		$this->RSSVersion = $version;
	}

	 // Builds the RSS feed's content.
	public function createFeed() {
		$feed = "<?xml version=\"1.0\" encoding=\"".$this->encoding."\"?>\n";
		$feed.= "<rss version=\"".$this->RSSVersion."\">\n";
		$feed.= "    <channel>\n";
		$feed.= "        <title>".htmlspecialchars($this->title)."</title>\n";

		$feed.= "        <description>".$this->description."</description>\n";
		$feed.= "        <link>".$this->link."</link>\n";

		$feed.= "        <lastBuildDate>".$this->pubDate."</lastBuildDate>\n";
		$feed.= "        <generator>".IPS_FEEDGENERATOR_VERSION."</generator>\n";

		if ($this->language!="") {
			$feed.= "        <language>".$this->language."</language>\n";
		}
		if ($this->copyright!="") {
			$feed.= "        <copyright>".htmlspecialchars($this->copyright)."</copyright>\n";
		}
		if ($this->editor!="") {
			$feed.= "        <managingEditor>".htmlspecialchars($this->editor)."</managingEditor>\n";
		}
		if ($this->webmaster!="") {
			$feed.= "        <webMaster>".htmlspecialchars($this->webmaster)."</webMaster>\n";
		}
		if ($this->pubDate!="") {
			$feed.= "        <pubDate>".htmlspecialchars($this->date)."</pubDate>\n";
		}
		if ($this->category!="") {
			$feed.= "        <category>".htmlspecialchars($this->category)."</category>\n";
		}
		if ($this->docs!="") {
			$feed.= "        <docs>".htmlspecialchars($this->docs)."</docs>\n";
		}
		if ($this->ttl!="") {
			$feed.= "        <ttl>".htmlspecialchars($this->ttl)."</ttl>\n";
		}
		if ($this->rating!="") {
			$feed.= "        <rating>".htmlspecialchars($this->rating)."</rating>\n";
		}
		if ($this->skipHours!="") {
			$feed.= "        <skipHours>".htmlspecialchars($this->skipHours)."</skipHours>\n";
		}
		if ($this->skipDays!="") {
			$feed.= "        <skipDays>".htmlspecialchars($this->skipDays)."</skipDays>\n";
		}

		for ($i=0;$i<count($this->items);$i++) {
			$feed.= "        <item>\n";
			$feed.= "            <title>".htmlspecialchars(strip_tags($this->items[$i]->title))."</title>\n";
			$feed.= "            <link>".htmlspecialchars($this->items[$i]->link)."</link>\n";
			$feed.= "            <description>".$this->items[$i]->description."</description>\n";

			if ($this->items[$i]->author!="") {
				$feed.= "            <author>".htmlspecialchars($this->items[$i]->author)."</author>\n";
			}
			/*
			// on hold
			if ($this->items[$i]->source!="") {
					$feed.= "            <source>".htmlspecialchars($this->items[$i]->source)."</source>\n";
			}
			*/
			if ($this->items[$i]->category!="") {
				$feed.= "            <category>".htmlspecialchars($this->items[$i]->category)."</category>\n";
			}
			if ($this->items[$i]->comments!="") {
				$feed.= "            <comments>".htmlspecialchars($this->items[$i]->comments)."</comments>\n";
			}
			if ($this->items[$i]->date!="") {
				$feed.= "            <pubDate>".htmlspecialchars($this->items[$i]->date)."</pubDate>\n";
			}
			if ($this->items[$i]->guid!="") {
				$feed.= "            <guid>".htmlspecialchars($this->items[$i]->guid)."</guid>\n";
			}
			$feed.= "        </item>\n";
		}
		$feed.= "    </channel>\n";
		$feed.= "</rss>\n";
		return $feed;
	}
}


////////////////////////////////////////////////////////////////
// Classes for the semi-automatical Creation of the IPS RSS Feed
// author: Zapp (11/2006)

class IPS_RSSFeedGenerator
{
   private $_rss;
   
   public function __construct( $szTitle, $szDescription )
	{
      $this->_rss = new FeedGenerator();
      $this->setTitle($szTitle);
      $this->setDescription($szDescription);
	}
	// Mandatory
	public function setTitle( $szTitle )
	{
      $this->_rss->title = $szTitle;
	}
	// Mandatory
	public function setDescription( $szDescription )
	{
      $this->_rss->description = $szDescription;
	}
	// optional
	public function setLink( $szLink )
	{
      $this->_rss->link = $szLink;
	}
	// optional
	public function setSyndicationURL( $szSyndicationURL )
	{
      $this->_rss->syndicationURL = $szSyndicationURL;
	}
	
	public function saveFeed( $format, $pathToXMLFile )
	{
      $this->_rss->saveFeed($format, $pathToXMLFile);
	}
	
	public function addItem( $item )
	{
      $this->_rss->addItem($item);
	}
	
	public function addModulesItems( $szModuleName , $link, $useNames=false, $source="", $author="" )
	{
      switch($szModuleName)
      {
         case "FHT":
            $module = new FHTModule();
            break;
         case "HMS":
            $module = new HMSModule();
            break;
         case "FS20TX":
            $module = new FS20TXModule();
            break;
         case "FS20RX":
            $module = new FS20RXModule();
            break;
         default:
            echo "Error: Unknown Module or not implemented";
            break;
      }
      $module->useNames($useNames);
      $allModulesVariables = $module->getVariables();
      foreach($allModulesVariables as $moduleVariables)
      {
         $item = new FeedItem();
         $item->title = $szModuleName.": ".$moduleVariables["Location"];
         $item->link = $link;
         $description = "";
         // Create description String from Variables Array Content Concatenation
         foreach($moduleVariables as $key => $value)
         {
            if ($key != "Location")
               $description .= $key.": ".$value."|";
         }
         //echo "Description: ".$description."\r\n";
         $item->description = $description;
         $item->date = date("d M Y H:i");
         $item->source = $source;
         $item->author = $author;
         
         $this->_rss->addItem($item);
      }

	}

   

}

class FHTModule extends Module
{
   public function __construct()
   {
      Module::__construct("FHT");  // parent constructor
   }

   public function getVariables()
   {
      $instancesFHT = $this->_instances;

      foreach ($instancesFHT as $instanceId)
      {
         $settings = IPS_GetInstanceSettings($instanceId);
         $array = $this->_xml->GetArray($settings);
         
         if ($this->_useNames == true) {
            $thisVariable['Location'] = $array['ID']['LOCATION']['NAME'];
         } else {
            $locationPathArray = explode("\\",LOC_GetLocation_InstanceID($instanceId));
            $thisVariable['Location'] = $locationPathArray[1]; // Keep the line number for modifications
         }
         
         $varTemperature = $array['ID']['Settings']['TemeratureVar'];
         $varTarget = $array['ID']['Settings']['TargetTempVar'];
         $varPosition = $array['ID']['Settings']['PositionVar'];
         $varMode = $array['ID']['Settings']['TargetModeVar'];
         $varWindowOpen = $array['ID']['Settings']['WindowOpen'];
         $varLowBattery = $array['ID']['Settings']['LowBatteryVar'];
         
         if (IPS_VariableExists($varTemperature)) {
            $temperature   = GetValueFloat($varTemperature);
            $thisVariable['Temperature'] = floor(($temperature) * 100 + .5) * .01;
         } else {
            echo("\nError: Variable ".$varTemperature." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Temperature'] = "?";
         }
         if (IPS_VariableExists($varTarget)) {
            $target = GetValueFloat($varTarget);
            $thisVariable['Target'] = floor(($target) * 100 + .5) * .01;
         } else {
            echo("\nError: Variable ".$varTarget." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Target'] = "?";
         }
         if (IPS_VariableExists($varPosition)) {
            $thisVariable['Position'] = round(GetValueFloat($varPosition));
         } else {
            echo("\nError: Variable ".$varPosition." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Position'] = "?";
         }
         if (IPS_VariableExists($varMode)) {
            $thisVariable['Mode'] = GetValueInteger($varMode);
         } else {
            echo("\nError: Variable ".$varMode." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Mode'] = "?";
         }
         if (IPS_VariableExists($varLowBattery)) {
            $lowBattery    = GetValueBoolean($varLowBattery);
            $thisVariable['LowBattery'] = $lowBattery ? 1 : 0;
         } else {
            echo("\nError: Variable ".$varLowBattery." does not exist for Instance ".$instanceId."\n");
            $thisVariable['LowBattery'] = "?";
         }
         if (IPS_VariableExists($varWindowOpen)) {
            $thisVariable['WindowOpen'] = GetValueBoolean($varWindowOpen) ? 1 : 0;
         } else {
            echo("\nWarning: Variable ".$varWindowOpen." does not exist for Instance ".$instanceId."\n");
            $thisVariable['WindowOpen'] = "?";
         }
         
         array_push($this->_variables, $thisVariable);
      }
      
      return $this->_variables;
   }
}

class HMSModule extends Module
{
   public function __construct()
   {
      parent::__construct("HMS");
   }
   
   public function getVariables()
   {
      $instancesFHT = $this->_instances;

		print_r($instancesFHT);
		
      foreach ($instancesFHT as $instanceId)
      {
         $settings = IPS_GetInstanceSettings($instanceId);
         $array = $this->_xml->GetArray($settings);
         
         if ($this->_useNames == true) {
            $thisVariable['Location'] = $array['ID']['LOCATION']['NAME'];
         } else {
            $locationPathArray = explode("\\",LOC_GetLocation_InstanceID($instanceId));
            $thisVariable['Location'] = $locationPathArray[1]; // Keep the line number for modifications
         }
         
         $varTemperature = $array['ID']['Settings']['Variable1'];
         $varMoisture = $array['ID']['Settings']['Variable2'];
         $varLowBattery = $array['ID']['Settings']['LowBatteryVar'];
         
         if (IPS_VariableExists($varTemperature)) {
            $temperature   = GetValueFloat($varTemperature);
            $thisVariable['Temperature'] = floor(($temperature) * 100 + .5) * .01;
         } else {
            echo("\nError: Variable ".$varTemperature." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Temperature'] = "?";
         }
         if (IPS_VariableExists($varMoisture)) {
            $thisVariable['Moisture'] = round(GetValueFloat($varMoisture));
         } else {
            echo("\nError: Variable ".$varMoisture." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Moisture'] = "";
         }
         if (IPS_VariableExists($varLowBattery)) {
            $thisVariable['LowBattery'] = GetValueBoolean($varLowBattery) ? 1 : 0;
         } else {
            echo("\nError: Variable ".$varLowBattery." does not exist for Instance ".$instanceId."\n");
            $thisVariable['LowBattery'] = "?";
         }

         array_push($this->_variables, $thisVariable);
      }
      
      return $this->_variables;
   }
}

class FS20TXModule extends Module
{
   public function __construct()
   {
      parent::__construct("FS20TX");
   }

   public function getVariables()
   {
      $instancesFS20TX = $this->_instances;

      foreach ($instancesFS20TX as $instanceId)
      {
         $settings = IPS_GetInstanceSettings($instanceId);
         $array = $this->_xml->GetArray($settings);
         
         if ($this->_useNames == true) {
            $thisVariable['Location'] = $array['ID']['LOCATION']['NAME'];
         } else {
            $locationPathArray = explode("\\",LOC_GetLocation_InstanceID($instanceId));
            $thisVariable['Location'] = $locationPathArray[1]; // Keep the line number for modifications
         }

         $varStatus = $array['ID']['Settings']['StatusVariable'];
         if (IPS_VariableExists($varStatus)) {
            $status = GetValueBoolean($varStatus);
            $thisVariable['Status'] = $status ? 1 : 0;
         } else {
            echo("\nError: Variable ".$varStatus." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Status'] = "?";
         }

         array_push($this->_variables, $thisVariable);
      }

      return $this->_variables;
   }
}

class FS20RXModule extends Module
{
   public function __construct()
   {
      parent::__construct("FS20RX");
   }

   public function getVariables()
   {
      $instancesFS20RX = $this->_instances;

      foreach ($instancesFS20RX as $instanceId)
      {
         $settings = IPS_GetInstanceSettings($instanceId);
         $array = $this->_xml->GetArray($settings);

         if ($this->_useNames == true) {
            $thisVariable['Location'] = $array['ID']['LOCATION']['NAME'];
         } else {
            $locationPathArray = explode("\\",LOC_GetLocation_InstanceID($instanceId));
            $thisVariable['Location'] = $locationPathArray[1]; // Keep the line number for modifications
         }

         $varStatus = $array['ID']['Settings']['StatusVariable'];
         if (IPS_VariableExists($varStatus)) {
            $status = GetValueBoolean($varStatus);
            $thisVariable['Status'] = $status ? 1 : 0;
         } else {
            echo("\nError: Variable ".$varStatus." does not exist for Instance ".$instanceId."\n");
            $thisVariable['Status'] = "?";
         }

         array_push($this->_variables, $thisVariable);
      }

      return $this->_variables;
   }
}

class Module
{
	//private $lf="\r\n";

   private $_moduleName;
   private $_guid;
   public $_instances;
   public $_variables = array();
   public $_xml;
   public $_useNames;

	//public function __construct( $moduleName )
   public function __construct( $moduleName )
   {
      $this->_moduleName = $moduleName;
      $this->_guid = $this->getModuleGUID();
      $this->_instances = $this->getInstances();
      $this->_xml = new IPS_XMLParser();
   }

   private function getModuleGUID()
   {
      $modules = IPS_GetModuleList();
      foreach($modules as $module) {
         $info=IPS_GetModule($module);
         print_r($info);
         if($info["name"]==$this->_moduleName) $guid = $info["guid"];
      }
      return $guid;
   }
   
   private function getInstances()
   {
      return IPS_GetInstancesByModuleID($this->_guid);
   }
   
   public function useNames($useNames)
   {
      $this->_useNames = $useNames;
   }
   
   public function getVariables()
   {
      // To be implemented by child classes
   }

} // End of the Module Class

?>
