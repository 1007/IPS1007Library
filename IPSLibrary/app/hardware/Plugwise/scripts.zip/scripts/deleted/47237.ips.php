<?

	$x = rand(1,10);
	
	say("Die Temperatur ist zu hoch");

function say($text)
	{
	$debug = true;

   $dir = IPS_GetKernelDir();
	$dir = $dir."voicereader\\";

	$exe = $dir."voicereader.exe";
	
	
   $file = $text . ".mp3";
	$file = str_replace(" ","_",$file);
	$file = $dir  . $file;
	
	if ( $debug ) echo "[".$file."]";

   if ( !file_exists($file))
		{
		if ( $debug ) echo "\nFile existiert nicht. Wird erstellt.";

		IPS_ExecuteEx($exe,"Save"." "."\"" .$text. "\""." ".$file,FALSE,TRUE,0);
		}
	   

	}
	
?>