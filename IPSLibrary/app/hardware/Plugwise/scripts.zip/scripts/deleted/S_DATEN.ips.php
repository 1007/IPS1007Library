<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : S_DATEN.ips.php
Trigger  : 
Interval : 
*/

require_once "def_home.ips.php";

//		Schalterdaten etc
//							Profile			Raum	Uhrzeit		Instanz EIN/AUS Dauer
$s_daten  = array(
				//	PROFILE 	FRUEHSCHICHT
				 0  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"00:00",		00000,	0,	0),
 				 1  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"16:05",		10.5,	0,	0),
  				 2  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"19:00",		10.5,	0,	0),
  				 5  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"00:00",		12.5,	0,	0),
 				 6  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"16:05",		15.5,	0,	0),
  				 7  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"19:00",		12.5,	0,	0),
  				10  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"00:00",		12.5,	0,	0),
 				11  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"16:05",		17.5,	0,	0),
  				12  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"19:00",		12.5,	0,	0),

  				//	PROFILE		SPAETSCHICHT
				20   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"00:00",		10.5,	0,	0),
 				21   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"16:05",		10.5,	0,	0),
  				22   => array(PROFIL_SPAETSCHICHT,RAUM_BAD,		"19:00",		10.5,	0,	0),
  				25   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"00:00",		12.5,	0,	0),
 				26   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"16:05",		15.5,	0,	0),
  				27   => array(PROFIL_SPAETSCHICHT,RAUM_WOHNEN,	"19:00",		12.5,	0,	0),
  				30   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"00:00",		12.5,	0,	0),
 				31   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"16:05",		17.5,	0,	0),
  				32   => array(PROFIL_SPAETSCHICHT,RAUM_ARBEIT,	"19:00",		12.5,	0,	0),

  				//	PROFILE 	NACHTSCHICHT
				40  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"00:00",		10.5,	0,	0),
 				41  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"16:05",		10.5,	0,	0),
  				42  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"19:00",		10.5,	0,	0),
  				45  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"00:00",		12.5,	0,	0),
 				46  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"16:05",		15.5,	0,	0),
  				47  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"19:00",		12.5,	0,	0),
  				50  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"00:00",		12.5,	0,	0),
 				51  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"16:05",		17.5,	0,	0),
  				52  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"19:00",		12.5,	0,	0),

				//	PROFILE 	NORMALSCHICHT
				60  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"00:00",		10.5,	0,	0),
 				61  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"16:05",		10.5,	0,	0),
  				62  => array(PROFIL_FRUEHSCHICHT,RAUM_BAD,		"19:00",		10.5,	0,	0),
  				65  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"00:00",		12.5,	0,	0),
 				66  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"16:05",		15.5,	0,	0),
  				67  => array(PROFIL_FRUEHSCHICHT,RAUM_WOHNEN,	"19:00",		12.5,	0,	0),
  				70  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"00:00",		12.5,	0,	0),
 				71  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"16:05",		17.5,	0,	0),
  				72  => array(PROFIL_FRUEHSCHICHT,RAUM_ARBEIT,	"19:00",		12.5,	0,	0),

 				//	PROFILE		WOCHENENDE
				100 => array(PROFIL_WOCHENENDE,RAUM_BAD,		"00:00",		10.5,	0,	0),
 				101 => array(PROFIL_WOCHENENDE,RAUM_BAD,		"16:05",		10.5,	0,	0),
  				102 => array(PROFIL_WOCHENENDE,RAUM_BAD,		"19:00",		10.5,	0,	0),
  				105 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"00:00",		12.5,	0,	0),
 				106 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"09:00",		15.5,	0,	0),
  				107 => array(PROFIL_WOCHENENDE,RAUM_WOHNEN,		"19:00",		12.5,	0,	0),
  				110 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"00:00",		12.5,	0,	0),
 				111 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"16:05",		17.5,	0,	0),
  				112 => array(PROFIL_WOCHENENDE,RAUM_ARBEIT,		"19:00",		12.5,	0,	0),


 				//
  				999 => array(0,			0,			"00:00",		0,		0,	0)
  				);



?>
