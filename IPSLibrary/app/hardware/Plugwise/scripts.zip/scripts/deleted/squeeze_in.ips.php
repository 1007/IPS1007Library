<?

	require_once("squeeze_func.ips.php");
   


?>