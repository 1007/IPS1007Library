<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : DEF_VOICE.ips.php
Trigger  : 
Interval : 
*/


define("VOICE_TEST","Dies ist ein Test");
define("VOICE_BAD_BATLEER","Die Batterie im Bad ist leer");
define("VOICE_WOHNEN_BATLEER","Die Batterie im Wohnzimmer ist leer");
define("VOICE_SCHLAFEN_BATLEER","Die Batterie im Schlafzimmer ist leer");
define("VOICE_TREPPE_BATLEER","Die Batterie im Treppenhaus ist leer");
define("VOICE_ARBEIT_BATLEER","Die Batterie im Arbeitszimmer ist leer");
define("VOICE_AUSSEN_BATLEER","Die Batterie auf dem Balkon ist leer");

define("VOICE_ENTER_KUECHE","Sie betreten den K�chenbereich");



?>
