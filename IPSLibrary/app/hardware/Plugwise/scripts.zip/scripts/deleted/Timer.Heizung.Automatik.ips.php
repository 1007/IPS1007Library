<?
//******************************************************************************
// 	wird alle Minute ausgefuehrt durch OB1
//******************************************************************************


	require_once(IPS_GetScriptID("Funcpool").".ips.php");
   
	$root = IPS_GetObjectIDByName("TEMPERATUR",0);
	
	
	
	heizung_ein($root,"ARBEIT",false);
	heizung_ein($root,"WOHNEN",false);
	heizung_ein($root,"BAD"   ,false);

	heizung_fuehlerueberwachung($root,"ARBEIT","AUFLADUNG",false);
	heizung_fuehlerueberwachung($root,"WOHNEN","AUFLADUNG",false);

	heizung_fuehlerueberwachung($root,"AUSSEN","",false);
	heizung_fuehlerueberwachung($root,"BAD"	,"",false);
	heizung_fuehlerueberwachung($root,"TREPPE","",false);
	heizung_fuehlerueberwachung($root,"SCHLAF","",false);
	heizung_fuehlerueberwachung($root,"WOHNEN","",false);
	heizung_fuehlerueberwachung($root,"ARBEIT","",false);
	
	heizung_aufladung($root,"ARBEIT",false,0);
	heizung_aufladung($root,"WOHNEN",false,0);




function heizung_aufladung($root,$raum,$debug,$offset)
	{

	$debug = false;
	
	$now = getdate();

	$akt_stunde    = $now["hours"];
	$akt_minute    = $now["minutes"];
	$akt_wochentag = $now["wday"];

	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN",$root);
	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN.TF",$aussen_instance);
	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN.TF.TEMPERATUR",$aussen_instance);

	$raum_instance     = IPS_GetObjectIDByName($raum,$root);
	$status_instance   = IPS_GetObjectIDByName("STATUS",$raum_instance);
	$stufe_instance    = IPS_GetVariableIDByName($raum.".AUFLADUNG.STUFE",$status_instance);
   $fuehler_instance  = IPS_GetInstanceIDByName($raum.".AUFLADUNG.TF",$raum_instance);
	$temp_instance     = IPS_GetVariableIDByName($raum.".AUFLADUNG.TF.TEMPERATUR",$fuehler_instance);
	$leer_instance     = IPS_GetVariableIDByName($raum.".AUFLADUNG.LEER",$status_instance);

   $ein_instance  	 = IPS_GetInstanceIDByName($raum.".AUFLADUNG.EIN",$raum_instance);

	$aussen_temperatur = GetValueFloat($aussen_instance);
	$ofen_temperatur   = GetValueFloat($temp_instance);

	//echo "\nAktuelle Stunde:$akt_stunde-$akt_minute";
	
	$on = false;
	$refresh = false;
	
	// Nach 0 Uhr Nachts immer einschalten ( jede Stunde )
	if ( $akt_stunde <= 8 and $akt_minute == 0 ){ $on = true; $refresh = true; }

	// Nach 12 Uhr Mittags immer ausschalten ( jede Stunde )
	if ( $akt_stunde >= 12 and $akt_minute == 0 ){ $on = false; $refresh = true; }


	if ( $refresh )
		{
		FS20_SwitchMode($ein_instance, $on );
	   //echo "ON [$on]";
	   }
	   
	   
	// Ofentemp 35 bedeutet leer
	$leer = false;
	if ( $ofen_temperatur < 35 ) $leer = true;
	SetValueBoolean($leer_instance,$leer);

	//SetValueInteger($stufe_instance,$akt_minute);

	return;
	
	$debug = false;

	$instance_ist		= "$raum.OFEN.TF.TEMPERATUR";
	$instance_soll 	= "$raum.HEIZUNG.AUFLADUNG.SOLL.TEMPERATUR";
	$instance_status 	= "$raum.HEIZUNG.AUFLADUNG.EIN.Status";

	$instance_ausgang = IPS_GetObjectIDByName($raum,33252);
	$instance_ausgang = IPS_GetInstanceIDByName("$raum.HEIZUNG.AUFLADUNG.EIN",$instance_ausgang);

   $Soll_Temperatur 	= GetValueFloat($instance_soll);
   $Ist_Temperatur  	= GetValueFloat($instance_ist);
	$Diff_Temperatur 	= ($Ist_Temperatur - $Soll_Temperatur);
	$status 				= GetValueBoolean($instance_status);

   $Soll_Temperatur = $Soll_Temperatur + $offset;

   if ( $debug )  echo "\nStatus:$status-Soll:$Soll_Temperatur Ist:$Ist_Temperatur Diff:$Diff_Temperatur";

   $ausgang = true;
   
    if ( $debug ) echo "\nRum:$raum-Status:$status-Soll:$Soll_Temperatur Ist:$Ist_Temperatur Diff:$Diff_Temperatur";
	 if ( $debug ) echo "\nRaum:$raum Ausgang:$ausgang IstStatus:$status - instance:$instance_ausgang";

 	if (  $Ist_Temperatur > ( $Soll_Temperatur + 1 )  )
		{$ausgang = false; if ( $debug )echo "Uebertemperatur"; }
 	if (  $Ist_Temperatur < ( $Soll_Temperatur - 3 )  )
		{ $ausgang = true;if ( $debug )echo "Untertemperatur"; }

	if ( !GetValueBoolean("STATUS.STROM.Nacht")) $ausgang = false;



   if ( $raum == "WOHNEN")
		{  if ( $debug ) echo "\nWOHNEN1:$status";
		if ( $ausgang){ FS20_SwitchDuration($instance_ausgang, false,0); if ( $debug )echo "AUS";}
		if ( !$ausgang ){ FS20_SwitchDuration($instance_ausgang, true ,0); if ( $debug )echo "AN";}
		}

   if ( $raum == "ARBEIT")
		{ if ( $debug ) echo "\nARBEIT1:$status";
		if ( $ausgang ){ FS20_SwitchDuration($instance_ausgang, true ,0); if ( $debug )echo "AN";}
		if ( !$ausgang){ FS20_SwitchDuration($instance_ausgang, false,0); if ( $debug )echo "AUS";}
		}


	}
	
	
	
function heizung_fuehlerueberwachung($root,$raum,$aufladung,$debug)
	{

	if ( $aufladung == "" ) $fuehlerstring = $raum .".TF";
	if ( $aufladung == "AUFLADUNG" ) $fuehlerstring = $raum .".AUFLADUNG.TF";

	$raum_instance     = IPS_GetObjectIDByName($raum,$root);
	$status_instance   = IPS_GetObjectIDByName("STATUS",$raum_instance);
	$fuehler_instance  = IPS_GetInstanceIDByName($fuehlerstring,$raum_instance);
	$error_instance 	 = IPS_GetVariableIDByName($fuehlerstring.".ERROR",$status_instance);
	$bat_instance      = IPS_GetVariableIDByName($fuehlerstring.".TEMPERATUR",$fuehler_instance);
	
	if($debug) echo "\nFuehlerueberwachung: $root - $raum_instance - $fuehler_instance";
	
   $t1 = time() / 60;    // aktuelle Zeit in Minuten

   $array = IPS_GetVariable($bat_instance);
   
   $t2 = $array["VariableUpdated"]/60;
	$diff = $t1 - $t2;

	if ( $debug ) echo "\n$fuehler_instance: $t1 - $t2 =$diff";

   if (($t1 - $t2) > 30)
      {
      $string = "TF $raum ausgefallen";
		if ( 	GetValueBoolean($error_instance)  == false )
      	{
         email($string);
			}
      SetValueBoolean($error_instance , true);
      if ( $debug ) echo "\n$string";
      IPS_LogMessage("Heizungssteuerung: ",$string);
      
      }
	else
	   {
	   SetValueBoolean($error_instance , false);
		}
	
	}



function heizung_ein($root,$raum,$debug)
	{
	
	$now     		=  time();
	
	$debug = false;
	

	$raum_instance   = IPS_GetObjectIDByName($raum,$root);
	$status_instance = IPS_GetObjectIDByName("STATUS",$raum_instance);

	
	
	
	
	$instance_ausgang    =  IPS_GetInstanceIDByName ("$raum.HEIZUNG.EIN",$raum_instance);
	$instance_control    =  IPS_GetInstanceIDByName ("$raum.HEIZUNG.CONTROL",$raum_instance);
	$instance_ein 	      = 	IPS_GetVariableIDByName ("$raum.HEIZUNG.CONTROL.EIN",$instance_control);

	$instance_solltemp   = IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR",$status_instance);
	$instance_soll			= IPS_GetVariableIDByName ("$raum.HEIZUNG.CONTROL.SOLL",$instance_control);
	$instance_autotemp 	= IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR.AUTOMATIK",$status_instance);
	$instance_handtemp 	= IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR.HAND",$status_instance);
	$instance_auto    	= IPS_GetVariableIDByName ("$raum.HEIZUNG.AUTOMATIK",$status_instance);


		
	// Automatik oder Handtemperaturen
	$handtemp = GetValueFloat($instance_handtemp);
	$autotemp = GetValueFloat($instance_autotemp);
	$auto     = GetValueBoolean($instance_auto);

	
	// Handeinstellung nur fuer x Minuten
	$array = IPS_GetVariable($instance_auto);
	$diff = $now  - $array['VariableUpdated'];
	//echo "\nDiff=$diff";
	if ( !$auto and $diff > 3600)
	   {
	   $auto = true;
		//echo "\n$raum-$diff";

	   echo "\nHandeinstellungszeit ist abgelaufen";
	   SetValueBoolean($instance_auto,$auto);
	   }


	
	
	$soll = GetValueFloat($instance_handtemp);
	if ( $auto)  $soll = GetValueFloat($instance_autotemp);

	SetValueFloat($instance_solltemp,$soll);

	if ($debug) echo "\n$raum-$instance_control: [$auto] Hand:$handtemp - Auto:$autotemp - SollControl:$soll";

	$i = 99;
	$i = HC_TargetValue($instance_control,$soll);


	// Heizung einschalten
	if ( GetValueBoolean($instance_ein) == TRUE )
   	{
      FS20_SwitchDuration($instance_ausgang, TRUE,100);
		//if ($debug) echo "\nEin";
		}



	
	}
	


?>
