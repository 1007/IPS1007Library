<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : Profile.Verwaltung.ips.php
Trigger  : 
Interval : 
*/

require_once "def_home.ips.php";

return;

$debug = 0;

$heute = getdate();

$akt_profile[0]            = 0;
$akt_profile[RAUM_BAD]     = 0;
$akt_profile[RAUM_WOHNEN]  = 0;
$akt_profile[RAUM_ARBEIT]  = 0;
$akt_profile[RAUM_SCHLAF]  = 0;
$akt_profile[RAUM_TREPPE]  = 0;
$akt_profile[RAUM_FLUR]    = 0;
$akt_profile[RAUM_KUECHE]  = 0;

$akt_profile[RAUM_AUSSEN]  = 0;

$akt_stunde   = $heute["hours"];
$akt_minute   = $heute["minutes"];
$akt_wochentag= $heute["wday"];
$akt_tickcount= $heute[0];
$akt_uhrzeit  = "$akt_stunde:$akt_minute";
$akt_timecode = ($akt_stunde * 60 ) + $akt_minute;
//Erster Wochenanfang seit UNIX-Epoche berechnen
$x = (floor(($akt_tickcount + (86400*3) )/(60*60*24*7)))/2;
if  ( floor($x) == $x) 	{ $akt_woche = 1; }
else 					{ $akt_woche = 2; }

$auto_profile = 1;
//	automatische Profilberechnung
if ( $auto_profile == 1 )
	{
	$akt_profile = array_fill(0,count($akt_profile),PROFIL_NULL);
	// Schicht
	if ( $akt_woche == 1 )
		$akt_profile = array_fill(0,count($akt_profile),PROFIL_FRUEHSCHICHT);
	if ( $akt_woche == 2 )
		$akt_profile = array_fill(0,count($akt_profile),PROFIL_SPAETSCHICHT);
	// Wochenende
	if ( $akt_wochentag == 6 or $akt_wochentag == 0 )
		$akt_profile = array_fill(0,count($akt_profile),PROFIL_WOCHENENDE);

	}

//echo $akt_wochentag;
//echo $akt_stunde;

SetValueInteger("PROFIL.BAD",   $akt_profile[RAUM_BAD]);
SetValueInteger("PROFIL.WOHNEN",$akt_profile[RAUM_WOHNEN]);
SetValueInteger("PROFIL.ARBEIT",$akt_profile[RAUM_ARBEIT]);


$string = "";



   $anzahl = count($akt_profile);
   for ( $x=1;$x<$anzahl;$x++)
      {
      $raum = get_raum_string($x);
      $profil = get_profil_string($akt_profile[$x]);
      $s = "PROFIL.$raum.String";
      //echo $s;
      SetValueString($s,$profil);
      //echo "\n $raum [$profil] ";
      $string = "$string $raum($profil) ";
      }

   //IPS_LogMessage("Verwaltung.Profil", $string);



    
?>
