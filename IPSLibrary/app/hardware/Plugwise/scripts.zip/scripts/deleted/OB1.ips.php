<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : OB1.ips.php
Trigger  : 
Interval : 
*/

//IPS_LogMessage("OB1","Minute");

IPS_RunScript("Verwaltung.Profile");

IPS_RunScript("Verwaltung.Status");

IPS_RunScript("Verwaltung.Drucker");

IPS_RunScript("Temperatur.Sollwertberechnung");

IPS_RunScript("Temperatur.Heizung.Automatik");

IPS_RunScript("Verwaltung.Ausgaenge");

?>
