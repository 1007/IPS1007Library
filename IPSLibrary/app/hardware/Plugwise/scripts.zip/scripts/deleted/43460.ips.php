<?

 $dir = 'C:/Programme/IP-SYMCON2/rrd/';
$file= 'temp_arbeit.rrd';
$temp = getvalue(34783);
$soll = getvalue(47917);
$ventil = getvalue(39172);
$para = "update $dir$file N:$temp:$soll:$ventil";
echo RRD_Execute($para);

?>