<?
	// Squeezeserverfunktionen
   require_once("squeeze_func.ips.php");
   
   //if ( !squeezeserver_connect() ) { echo "\nVerbindung zu CLI fehlgeschlagen"; exit; }
   $geraetename = "ARBEIT";
   //echo "\n".$mode = squeeze_command("GENERAL_CAN","time");
   echo "\n".$mode = squeeze_command("GENERAL_VERSION");
   if ( !$mode ) { echo "\nVerbindung zu CLI fehlgeschlagen"; exit; }
	echo "\n".$mode = squeeze_command("GENERAL_LISTEN",1);
	//echo "\n".$mode = squeeze_command("GENERAL_LOGIN","USER","PASSWORD");
	//echo "\n".$mode = squeeze_command("GENERAL_SUBSCRIBE","MIXER");
	//echo "\n".$mode = squeeze_command("GENERAL_PREF","audiodir");
	//echo "\n".$mode = squeeze_command("GENERAL_LOGGING","group:scanner",0);
	//echo "\n".$mode = squeeze_command("GENERAL_PREFVALIDATE","bufferSecs 10");
	//echo "\n".$mode = squeeze_command("GENERAL_GETSTRING","HOME");
	//echo "\n".$mode = squeeze_command("GENERAL_SETSNCREDENTIALS","USER","PASSWORD",0);
	//echo "\n".$mode = squeeze_command("GENERAL_DEBUG","d_files",0);
	//echo "\n".$mode = squeeze_command("GENERAL_EXIT");
	//echo "\n".$mode = squeeze_command("GENERAL_SHUTDOWN");


	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERCOUNT");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERID",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERUUID",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERIP",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMODEL",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERISPLAYER",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERDISPLAYTYPE",0);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERCANPOWEROFF",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSIGNALSTRENGTH",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERGETNAME",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSETNAME",$geraetename,"NEWNAME");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERCONNECTED",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERGETSLEEP",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSETSLEEP",$geraetename,10);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERGETSYNC",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSETSYNC",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSYNCGROUPS",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERPOWER",$geraetename,1);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMIXERVOLUME",$geraetename,20);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMIXERMUTING",$geraetename,"toggle");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMIXERBASS",$geraetename,"?");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMIXERTREBLE",$geraetename,"?");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERMIXERPITCH",$geraetename,"?");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERSHOW",$geraetename,"line1:Hello%20World line2:Second%20line duration:1 centered:1");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERDISPLAY",$geraetename,"Hello World 5");
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERLINESPERSCREEN",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERDISPLAYNOW",$geraetename);
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERPLAYERPREF",$geraetename,"doublesize ?"); 						// ?
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERPLAYERPREFVALIDATE",$geraetename,"scrollPause 3"); 			// ok
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERBUTTON",$geraetename,"pause"); 											// ok
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERIR",$geraetename,"768910ef 11073.575");                       // ok
	//echo "\n".$mode = squeeze_command("PLAYERS_PLAYERIRENABLE",$geraetename,"?");                       // ok



	//echo "\n".$mode = squeeze_command("DATABASE_INFOTOTALGENRES");                       //   ok
	//echo "\n".$mode = squeeze_command("DATABASE_INFOTOTALARTISTS");                       //   ok
	//echo "\n".$mode = squeeze_command("DATABASE_INFOTOTALALBUMS");                       //   ok
	//echo "\n".$mode = squeeze_command("DATABASE_INFOTOTALSONGS");                       //   ok
   //echo "\n".$mode = squeeze_command("DATABASE_GENRES","0 5");                            // ok
   //echo "\n".$mode = squeeze_command("DATABASE_ARTISTS","0 5");                            // ok
	//echo "\n".$mode = squeeze_command("DATABASE_ALBUMS","0 4");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_YEARS","0 4");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_MUSICFOLDER","0 4");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTS","8 8");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTSTRACKS","6533 0");                      // ??
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTSRENAME","playlist_id:6533 newname:BAD");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTSNEW","name:NEW");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTSDELETE","playlist_id:7089");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_PLAYLISTSEDIT","cmd:up playlist_id:6645 index:2");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_SONGINFO","0 100 track_id:2");                      // ok
	//echo "\n".$mode = squeeze_command("DATABASE_TITLES","0 1");                      // ?? Timeout
	//echo "\n".$mode = squeeze_command("DATABASE_SEARCH","0 4 term:al");                      // ?? Timeout
	//echo "\n".$mode = squeeze_command("DATABASE_PRAGMA","locking_mode=NORMAL");                      // nicht getestet



?>