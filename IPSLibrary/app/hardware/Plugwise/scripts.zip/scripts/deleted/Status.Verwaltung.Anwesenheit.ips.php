<?

// Routine wird aufgerufen wenn sich der
// Status aendert ( ANWESEND - WACH )
// oder alle 60 Minuten - muss noch gemacht werden

include  "DEF_INSTANCEN.ips.php";

$text ="";

$anwesend 	= GetValueBoolean("STATUS.ANWESEND.Status");
$wach     	= GetValueBoolean("STATUS.WACH.Status");
$stromnacht	= GetValueBoolean("STATUS.STROM.Nacht");

$wach=true;
$text="Anwesend:$anwesend Wach:$wach";
// Telefon  Arbeit ********************************
if ( $anwesend==true AND $wach==true )
      FS20_SwitchMode(I_TELEFON,true);
else
      FS20_SwitchMode(I_TELEFON,false);
//*************************************************
IPS_Sleep(2000);





?>
