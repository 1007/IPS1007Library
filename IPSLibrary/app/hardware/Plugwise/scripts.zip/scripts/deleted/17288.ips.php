<?

/////////////////////////(C) by MD 2009 //////////////////////////
//                                                              //
//     Skript scannt einen bestimmten Netzwerk-Bereich          //
//      und legt bei Antwort die IP Addresse und den            //
//          Hostnamen in einer String Variable ab               //
//                                                              //
//            Trigger z.B. alle 10 min erzeugen                 //
//                 (tested with IPS v2.1)                       //
//                                                              //
//////////////////////////////////////////////////////////////////


// Ausf�hrungszeit maximal 180 sec

set_time_limit(180);

// statischer Teil

// $ID = Netzwerk-Teiladresse z.B. 192.168.1.
// $start = erste zu scannende IP Adresse
// $end = letzte zu scannende IP Adresse
// $ParentID = Kategorie ID f�r String Variablen
// $Anz = Anzahl der zu erstellenden Stringvariablen
//        (sind mehr IP Adressen vorhanden als String Variablen, so werden
//        die IP Adressen f�r die keine String Variablen vorhanden sind, nicht
//        gespeichert)
// $debug = Debugausgabe

$ID = "192.168.10.";
$start = 1;
$end = 254;
$ParentID = 23179;
$Anz = 20;
$debug = true;

// dynamischer Teil

// String-Variablen erstellen

$IP1 = @IPS_GetVariableIDByName("IP1", $ParentID);

if (IPS_VariableExists($IP1) == false)
    {
    for($i=1; $i <= $Anz; $i++)
       {
       $var = IPS_CreateVariable(3);
        IPS_SetParent($var, $ParentID);
          IPS_SetName($var,"IP$i");
          }
   $var = IPS_CreateVariable(1);
    IPS_SetParent($var, $ParentID);
     IPS_SetName($var,"Anzahl_aktiv");

     IPS_Sleep(2500);
   }

// Netzwerkscan

$Anzahl = 0;

for($i=$start; $i <= $end; $i++) // von - bis zu scannende Adressen
    {
    $adr = $ID.$i;
    $ping = Sys_Ping("$adr",100);
    if ($ping == true)
        {
        $host = gethostbyaddr($adr);
        if ($debug) {echo "IP: $adr -- Hostname: $host \n";}
        $Anzahl = $Anzahl + 1;
        if ($Anzahl <= $Anz)
            {
            $VarID = IPS_GetVariableIDByName("IP$Anzahl",$ParentID);
            setValueString($VarID,"IP Adresse: $adr -- Hostname: $host");
            }
        }
      else
        {
        if ($debug) {echo "IP: $adr --> nicht erreichbar \n";}

        }
    }


if ($debug) {echo "Anzahl aktiver Netzwerkger�te: $Anzahl \n";}
$VarID = IPS_GetVariableIDByName("Anzahl_aktiv",$ParentID);
setValueInteger($VarID,$Anzahl);

// restliche Strings wieder l�schen

if ($Anzahl < $Anz)
    {
    for($i=$Anzahl+1; $i<=$Anz; $i++)
        {
        $VarID = IPS_GetVariableIDByName("IP$i",$ParentID);
        setValueString($VarID,"");
        }
    }



?>