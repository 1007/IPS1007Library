<?

//




	require_once(IPS_GetScriptID("Funcpool.DBox").".ips.php");
	
   
   $string = "Aussen";
	$string = "lock=1&clear=1&xpos=8&ypos=30&size=18&font=2&text=$string&update=1";
	dbox_control(DBOX2_IP,DBOXCONTROL_LCD,$string,1);

   
	//$ok = dbox_gettime(DBOX2_IP);
	//sleep(2);
   //$ok = dbox_gettime(DBOX3_IP);

	//$ok = dbox_message(DBOX2_IP,"Message");
	//sleep(2);
   //$ok = dbox_message(DBOX3_IP,"Message");

	//$ok = dbox_popup(DBOX2_IP,"Message");
	//sleep(2);
   //$ok = dbox_popup(DBOX3_IP,"Message");

	//$ok = dbox_shutdown(DBOX2_IP,"Message");
	//sleep(2);
   //$ok = dbox_shutdown(DBOX3_IP,"Message");

	//$ok = dbox_epg(DBOX2_IP,"");
	//$string = GetValueString("DBOX2.DATA");
	//echo $string;
	//sleep(2);
   //$ok = dbox_epg(DBOX3_IP,"");
	//$string = GetValueString("DBOX3.DATA");
   //echo $string;
	//echo "ende\n";

	//$ok = dbox_getbouquets(DBOX2_IP);
	//$string = GetValueString("DBOX2.DATA");
	//echo $string;
	//sleep(2);
   //$ok = dbox_getbouquets(DBOX3_IP);
	//$string = GetValueString("DBOX3.DATA");
   //echo $string;

	//$ok = dbox_getbouquet(DBOX2_IP,1);
	//$string = GetValueString("DBOX2.DATA");
	//echo $string;
	//sleep(2);
   //$ok = dbox_getbouquet(DBOX3_IP,1);
	//$string = GetValueString("DBOX3.DATA");
   //echo $string;

	//$ok = dbox_zapto(DBOX2_IP,"43700016d66");
	//$string = GetValueString("DBOX2.DATA");
	//echo $string;
	//sleep(2);
   //$ok = dbox_zapto(DBOX3_IP,"43700016d66");
	//$string = GetValueString("DBOX3.DATA");
   //echo $string;


	//zap_all();

	//get_akt_epg();
	

	echo "\nende\n";


function get_akt_epg()
	{
	
	dbox_zapto(DBOX2_IP,"");

	$akt_kanal = GetValueString("DBOX2.DATA");
	echo "Kanal: $akt_kanal";
   $akt_kanal = preg_replace('/(\r|\n)/','',$akt_kanal);

	$ok = dbox_epg(DBOX2_IP,"id=$akt_kanal&");

	$akt_epg = GetValueString("DBOX2.DATA");
	echo "EPG:\n $akt_epg";

	}
	
// Zapt alle Kanaele durch
function zap_all()
	{

	$ok = dbox_getbouquet(DBOX2_IP,1);
	$allesender = GetValueString("DBOX2.DATA");
	
   $sender = explode("\n",$allesender);
	$anzahl = count($sender);
	//$anzahl = 5;
	
   for ( $x=0;$x<$anzahl;$x++)
      {
         $id = explode(" ",$sender[$x]);
         $kanal = $id[1];
         
         dbox_zapto(DBOX2_IP,$kanal);
         
         echo "$x: $kanal \n";
         sleep(5);
         
		}


  }
  
?>