<?

	reset_counter("TREPPE");
	reset_counter("AUSSEN");
	reset_counter("BAD");
	reset_counter("SCHLAF");
	reset_counter("KUECHE");
	reset_counter("FLUR");
	reset_counter("WOHNEN1");
	reset_counter("WOHNEN2");
	reset_counter("ARBEIT");


function reset_counter($raum)
	{

	$var = "$raum.HEIZUNG.COUNTER";

	SetValueInteger($var,0);

	}


?>