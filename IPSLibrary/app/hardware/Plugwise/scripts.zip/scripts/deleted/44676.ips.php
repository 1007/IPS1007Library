<?

/*
  $IPS_SENDER -> Variable, TimerEvent, Execute, Designer, WebInterface, SMSwitch�.
  $IPS_SELF -> Scriptname (N/A bei SENDER = WebInterface!)

  Bei $IPS_SENDER = Designer
  $IPS_COMPONENT -> gesteuert per IPSYMID

  Bei $IPS_SENDER = Variabe
  $IPS_VARIABLE = Variable mit der Variable die getriggert hat
  $IPS_VALUE = Veriablenwert zum Zeitpunkt des Triggers
  $IPS_TRIGER = Art des Triggers z.B. OnUpdate, OnValue, OnChange�

  Bei $IPS_SENDER = TimerEvent
  Spezialfall durch Benutzung von IPS_RunScriptEx("Script", Array("TWZ_LASTTIMER"=>$lasttimer));
  $TWZ_LATTIMER ist dann der Zeitpunkt als UnixTimestamp des getriggerten TimerEvents

  Bei $IPS_SENDER = EventHandler
  $IPS_MESSAGETYPE - Typ der Nachricht
  $IPS_MESSAGESENDER - Sender der Nachricht
  $IPS_MESSAGE - Nachricht selbst

  Bei $IPS_SENDER = WebInterface
    'PHP_SELF'
    'PHP_AUTH_USER',
    'PHP_AUTH_PW',
    'REMOTE_ADDR',
    'REMOTE_HOST',
    'REMOTE_USER',
    'REQUEST_METHOD',
    'HTTP_COOKIE',
    'HTTP_USER_AGENT',
    'HTTP_CACHE_CONTROL',
    'HTTP_DATE',
    'HTTP_ACCEPT',
    'HTTP_FROM',
    'HTTP_HOST',
    'HTTP_CONTENT_ENCODING',
    'HTTP_CONTENT_VERSION',
    'HTTP_EXPIRES',
    'HTTP_CONNECTION',
    'HTTP_ACCEPT_LANGUAGE',
    'HTTP_ACCEPT_ENCODING',
    'DOCUMENT_ROOT',
    'REQUEST_URI',
    'SCRIPT_NAME',
    'QUERY_STRING'

*/

	echo "\nIPS_SENDER  : " . $IPS_SENDER;
	echo "\nIPS_SELF    : " . $IPS_SELF;
	echo "\nIPS_VARIABLE: " . $IPS_VARIABLE;
	echo "\nIPS_VALUE   : " . $IPS_VALUE;
	echo "\nIPS_TRIGER  : " . $IPS_TRIGER;

	



?>