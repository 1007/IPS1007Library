<?
	/***************************************************************************
	Uebersicht ueber alle Squeezeserverkommandos
	   General
	      login                      GENERAL_LOGIN,user,password
	      can                        GENERAL_CAN,request
	      version                    GENERAL_VERSION
	      listen                     GENERAL_LISTEN,status
	      subscribe                  GENERAL_SUBSCRIBE,list
	      pref                       GENERAL_PREF,variable
	      logging                    GENERAL_LOGGING,group
	      getstring                  GENERAL_GETSTRING,string
	      setsncredentials           GENERAL_SETSNCREDENTIALS,credentials
	      debug                      GENERAL_DEBUG,categories,status
	      exit                       GENERAL_EXIT
	      shutdown                   GENERAL_SHUTDOWN
	   Players
	
	   Database
	
	   Playlist
	
	   Queries
	   
	   Notifications
	   
	   Alarm
	   
		Plugin
		
	****************************************************************************/
	
	
	//***************************************************************************
	// Hier anpassen
	//***************************************************************************
	// Opel
   $cli_id = 35533;                          // Socket-ID
	$tag_kategorie = 41778;                   // Datenkategorie
	$squeeze_kategorie = 40041;               // Hauptkategorie
	$send_timeout = 3;                        // Timeout beim Senden in Sekunden
	
	// Home
	$cli_id = 40623;
	$tag_kategorie = 32728;
	$squeeze_kategorie = 16510;
	$send_timeout = 3;

	
	
	$debug = true;
	$logging = true;
	
	$squeezebox_mac_adressen = array(
						"00:04:20:1e:92:31",
						"00:04:20:27:b7:04",
						"00:04:20:27:ae:ac",
						"00:0b:97:dd:3a:05",
						"00:00:00:00:00:00",
						"00:00:00:00:00:00",
						"00:00:00:00:00:00",
						"00:00:00:00:00:00",
						"00:00:00:00:00:00",
						"00:00:00:00:00:00" );
	$squeezebox_aliasnamen = array(
	               "ARBEIT",
	               "BAD",
	               "WOHNEN",
	               "TEST",
	               "RESERVE5",
	               "RESERVE6",
						"RESERVE7",
						"RESERVE8",
						"RESERVE9",
						"RESERVE10" );
	//***************************************************************************



	//***************************************************************************
	if ( !isset($IPS_VALUE)) $IPS_VALUE = "version 1007";
	
	if ( $IPS_SENDER == "Execute" ) ;
	
	if ( $IPS_SENDER == "RegisterVariable" )
	   {

 		$input = urldecode(rtrim( $IPS_VALUE ));
 	
 		$teile = explode("\n", $input);
 		foreach($teile as $zeile)
 	      	do_zeile($zeile);
 	
		}

//******************************************************************************
// Kommando an Server senden und warte auf Antwort bis Timeout
//******************************************************************************
function send($clear,$command)
	{
	
	global $cli_id;
	global $debug;
	global $logging;
	global $send_timeout;
	global $squeeze_kategorie;
	
	clear($clear);

	if ( $logging ) logging("->",$command);
	
	if ( !$command_id = IPS_GetObjectIDByName("command",$squeeze_kategorie))
		{
		if ( $debug ) echo "Create: command";
		$command_id = IPS_CreateVariable(3);
		IPS_SetParent($command_id,$squeeze_kategorie);
      IPS_SetName($command_id,"command");
		}
   SetValueString($command_id,$command);

	$command = $command . chr(10);
	CSCK_SendText($cli_id,$command);

	$return = wait($clear);

	return $return;
	}


//******************************************************************************
// Hier werden alle Zeilen die von der Squeezebox kommen ausgewertet
// Bei Antwort die keine Daten enthalten ( zB stop ) dummy anhaengen
// wegen Timeouterkennung
//******************************************************************************
function do_zeile($input)
	{

	global $debug;
	global $logging;
	global $squeeze_kategorie;
	global $tag_kategorie;
	global $p1_mac;
	global $p2_mac;
	global $p3_mac;
	global $p4_mac;
	global $p5_mac;
	global $logging;
	global $debug;
	global $squeezebox_mac_adressen;
	

	if ( $logging ) logging("<-",$input);

	if ( !$answer_id = IPS_GetObjectIDByName("answer",$squeeze_kategorie))
		{
		if ( $debug ) echo "Create: answer";
		$answer_id = IPS_CreateVariable(3);
		IPS_SetParent($answer_id,$squeeze_kategorie);
      IPS_SetName($answer_id,"answer");
		}
		
   SetValueString($answer_id,$input);

	$answer = "answer_unknown";
	$dummy = false;
	
	for ( $x=0;$x<count($squeezebox_mac_adressen);$x++)
	   {

   	$name = "$squeezebox_mac_adressen[$x] signalstrength"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   	$name = "player canpoweroff $squeezebox_mac_adressen[$x]"; 		if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] name"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] sleep"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] connected"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] power";	 					if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] mixer volume";	 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] mixer muting";	 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] mixer bass";		 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] mixer treble";	 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] mixer pitch";	 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] show";				 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] display";			 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] linesperscreen";			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] displaynow";			 		if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] playerpref";			 		if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] playerpref validate";		if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] button";			 			if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] ir";			 				if ( check_answer($name,$input) ) { $answer = $name;  }
  		$name = "$squeezebox_mac_adressen[$x] irenable";			 		if ( check_answer($name,$input) ) { $answer = $name;  }

	   }
	

   $name = "listen"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "version";      				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "can";      						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "login";      					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "subscribe";      				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "pref";      					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "pref validate";				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "logging";      				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "getstring";      				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "setsncredentials";			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "debug";      					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "exit";      					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "shutdown";      				if ( check_answer($name,$input) ) { $answer = $name;  }

   $name = "player count"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player id"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player uuid"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player ip"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player model"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player isplayer"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "player displaytype"; 		if ( check_answer($name,$input) ) { $answer = $name;  }

   $name = "info total genres"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "info total artists"; 		if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "info total albums"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "info total songs"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "genres"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "artists"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "albums"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "years"; 							if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "musicfolder"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists"; 					if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists tracks"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists rename"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists new"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists delete"; 			if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "playlists edit"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "songinfo"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "titles"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "search"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "pragma"; 						if ( check_answer($name,$input) ) { $answer = $name;  }


   $name = "serverstatus"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "status"; 						if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "displaystatus"; 				if ( check_answer($name,$input) ) { $answer = $name;  }
   $name = "readdirectory"; 				if ( check_answer($name,$input) ) { $answer = $name;  }


	if ( $answer == "answer_unknown" )
		$id = IPS_GetObjectIDByName($answer,$squeeze_kategorie);
	else
		$id = IPS_GetObjectIDByName($answer,$tag_kategorie);

	if ( !$id )
	   {
		if ( $debug ) echo "Create: $answer";
		$id = IPS_CreateVariable(3);
		if ( $answer == "answer_unknown" )
			IPS_SetParent($id,$squeeze_kategorie);
		else
			IPS_SetParent($id,$tag_kategorie);
      IPS_SetName($id,$answer);
		}

	if ( $answer != "answer_unknown" )
		$input = trim(substr($input,strlen($answer)));
	
	if ( $dummy )
	   $input = $input . "OK";
	SetValueString($id,$input);


	}
	
function check_answer($name,$input)
	{
	global $debug;
	
	$return = false;
	
	if ( substr($input,0,strlen($name)) == $name )
		{
		if ( $debug )
			echo "[$name][$input]";
		$return = true; 
		}
		
	return $return;
	
	}

function get_tag($tag)
	{
	global $debug;
	global $tag_kategorie;
	$data = false;
	
	$id = IPS_GetObjectIDByName($tag,$tag_kategorie);
	
	if ( $debug ) echo $id;
	if ( $id ) $data = GetValueString($id);
	if ( $data ) { $data = trim(substr($data,strlen($tag))); }
	
	return $data;
	}

function squeeze_command()
	{
	global $p1_mac;
	global $p2_mac;
	global $p3_mac;
	global $p4_mac;
	global $p5_mac;
	global $mac_adressen;
	
	global $debug;
	
	$anzahl_arg = func_num_args();
	if ( $anzahl_arg == 0 ) return;
	if ( $anzahl_arg > 0 ) $cmd = func_get_arg(0);
	if ( $anzahl_arg > 1 ) $p1  = func_get_arg(1);
	if ( $anzahl_arg > 2 ) $p2  = func_get_arg(2);
	if ( $anzahl_arg > 3 ) $p3  = func_get_arg(3);
	if ( $anzahl_arg > 4 ) $p4  = func_get_arg(4);

   $return = false;
   
	switch ( $cmd)
	   {
	   // GENERAL
		case "GENERAL_LOGIN" 							:  $return = send("login","login $p1 $p2"); 	break;
		case "GENERAL_CAN" 								:  $return = send("can","can $p1 ?"); 			break;
	   case "GENERAL_VERSION" 							:  $return = send("version","version ?"); 	break;
	   case "GENERAL_LISTEN"  							:  $return = send("listen","listen $p1"); 	break;
	   case "GENERAL_SUBSCRIBE"  						:  $return = send("subscribe","subscribe $p1"); 	break;
	   case "GENERAL_PREF"  							:  $return = send("pref","pref $p1 ?"); 	break;
	   case "GENERAL_LOGGING"  						:  $return = send("logging","logging $p1 $p2"); 	break;
	   case "GENERAL_PREFVALIDATE"  					:  $return = send("pref validate","pref validate $p1"); 	break;
	   case "GENERAL_GETSTRING"   					:  $return = send("getstring","getstring $p1"); 	break;
	   case "GENERAL_SETSNCREDENTIALS"				:  $return = send("setsncredentials","setsncredentials $p1 $p2 $p3"); 	break;
	   case "GENERAL_DEBUG"  							:  $return = send("debug","debug $p1 $p2"); 	break;
	   case "GENERAL_EXIT"  							:  $return = send("exit","exit"); 	break;
	   case "GENERAL_SHUTDOWN"  						:  $return = send("shutdown","shutdown"); 	break;

	   // PLAYERS
	   case "PLAYERS_PLAYERCOUNT"  					:  $return = send("player count","player count ?"); 	break;
	   case "PLAYERS_PLAYERID"  						:  $return = send("player id","player id $p1 ?"); 	break;
	   case "PLAYERS_PLAYERUUID"  					:  $return = send("player uuid","player uuid $p1 ?"); 	break;
	   case "PLAYERS_PLAYERIP"  						:  $return = send("player ip","player ip $p1 ?"); 	break;
	   case "PLAYERS_PLAYERMODEL"  					:  $return = send("player model","player model $p1 ?"); 	break;
	   case "PLAYERS_PLAYERISPLAYER"  				:  $return = send("player isplayer","player isplayer $p1 ?"); 	break;
	   case "PLAYERS_PLAYERDISPLAYTYPE"  			:  $return = send("player displaytype","player displaytype $p1 ?"); 	break;
	   case "PLAYERS_PLAYERCANPOWEROFF"  			:  $return = send("player canpoweroff ".suche_mac($p1),"player canpoweroff ".suche_mac($p1)." ?"); 	break;
	   case "PLAYERS_PLAYERSIGNALSTRENGTH"			:  $return = send(suche_mac($p1)." signalstrength",suche_mac($p1)." signalstrength ?"); 	break;
	   case "PLAYERS_PLAYERGETNAME"					:  $return = send(suche_mac($p1)." name",suche_mac($p1)." name ?"); 	break;
	   case "PLAYERS_PLAYERSETNAME"					:  $return = send(suche_mac($p1)." name",suche_mac($p1)." name $p2"); 	break;
	   case "PLAYERS_PLAYERCONNECTED"				:  $return = send(suche_mac($p1)." connected",suche_mac($p1)." connected ?"); 	break;
	   case "PLAYERS_PLAYERGETSLEEP"					:  $return = send(suche_mac($p1)." sleep",suche_mac($p1)." sleep ?"); 	break;
	   case "PLAYERS_PLAYERSETSLEEP"					:  $return = send(suche_mac($p1)." sleep",suche_mac($p1)." sleep $p2"); 	break;


	   case "PLAYERS_PLAYERPOWER"						:  $return = send(suche_mac($p1)." power",suche_mac($p1)." power $p2"); 	break;
	   case "PLAYERS_PLAYERMIXERVOLUME"				:  $return = send(suche_mac($p1)." mixer volume",suche_mac($p1)." mixer volume $p2"); 	break;
	   case "PLAYERS_PLAYERMIXERMUTING"				:  $return = send(suche_mac($p1)." mixer muting",suche_mac($p1)." mixer muting $p2"); 	break;
	   case "PLAYERS_PLAYERMIXERBASS"				:  $return = send(suche_mac($p1)." mixer bass",suche_mac($p1)." mixer bass $p2"); 	break;
	   case "PLAYERS_PLAYERMIXERTREBLE"				:  $return = send(suche_mac($p1)." mixer treble",suche_mac($p1)." mixer treble $p2"); 	break;
	   case "PLAYERS_PLAYERMIXERPITCH"				:  $return = send(suche_mac($p1)." mixer pitch",suche_mac($p1)." mixer pitch $p2"); 	break;
	   case "PLAYERS_PLAYERSHOW"	 					:  $return = send(suche_mac($p1)." show",suche_mac($p1)." show $p2"); 	break;
	   case "PLAYERS_PLAYERDISPLAY"	 				:  $return = send(suche_mac($p1)." display",suche_mac($p1)." display $p2"); 	break;
	   case "PLAYERS_PLAYERLINESPERSCREEN"			:  $return = send(suche_mac($p1)." linesperscreen",suche_mac($p1)." linesperscreen ?"); 	break;
	   case "PLAYERS_PLAYERDISPLAYNOW"	 			:  $return = send(suche_mac($p1)." displaynow",suche_mac($p1)." displaynow ? ?"); 	break;
	 	case "PLAYERS_PLAYERPLAYERPREF"	 			:  $return = send(suche_mac($p1)." playerpref",suche_mac($p1)." playerpref $p2"); 	break;
	 	case "PLAYERS_PLAYERPLAYERPREFVALIDATE"	:  $return = send(suche_mac($p1)." playerpref validate",suche_mac($p1)." playerpref validate $p2"); 	break;
	 	case "PLAYERS_PLAYERBUTTON"					:  $return = send(suche_mac($p1)." button",suche_mac($p1)." button $p2"); 	break;
	 	case "PLAYERS_PLAYERIR"							:  $return = send(suche_mac($p1)." ir",suche_mac($p1)." ir $p2"); 	break;
	 	case "PLAYERS_PLAYERIRENABLE"					:  $return = send(suche_mac($p1)." irenable",suche_mac($p1)." irenable $p2"); 	break;
		// DATABASE
	 	case "DATABASE_INFOTOTALGENRES"				:  $return = send("info total genres","info total genres ?"); 	break;
	 	case "DATABASE_INFOTOTALARTISTS"				:  $return = send("info total artists","info total artists ?"); 	break;
	 	case "DATABASE_INFOTOTALALBUMS"				:  $return = send("info total albums","info total albums ?"); 	break;
	 	case "DATABASE_INFOTOTALSONGS"				:  $return = send("info total songs","info total songs ?"); 	break;
	 	case "DATABASE_GENRES"							:  $return = send("genres","genres $p1"); 	break;
	 	case "DATABASE_ARTISTS"							:  $return = send("artists","artists $p1"); 	break;
	 	case "DATABASE_ALBUMS"							:  $return = send("albums","albums $p1"); 	break;
	 	case "DATABASE_YEARS"							:  $return = send("years","years $p1"); 	break;
	 	case "DATABASE_MUSICFOLDER"					:  $return = send("musicfolder","musicfolder $p1"); 	break;
	 	case "DATABASE_PLAYLISTS"						:  $return = send("playlists","playlists $p1"); 	break;
	 	case "DATABASE_PLAYLISTSTRACKS"				:  $return = send("playlists tracks","playlists tracks $p1"); 	break;
	 	case "DATABASE_PLAYLISTSRENAME"				:  $return = send("playlists rename","playlists rename $p1"); 	break;
	 	case "DATABASE_PLAYLISTSNEW"					:  $return = send("playlists new","playlists new $p1"); 	break;
	 	case "DATABASE_PLAYLISTSDELETE"				:  $return = send("playlists delete","playlists delete $p1"); 	break;
	 	case "DATABASE_PLAYLISTSEDIT"					:  $return = send("playlists edit","playlists edit $p1"); 	break;
	 	case "DATABASE_SONGINFO"						:  $return = send("songinfo","songinfo $p1"); 	break;
	 	case "DATABASE_TITLES"							:  $return = send("titles","titles $p1"); 	break;
	 	case "DATABASE_SEARCH"							:  $return = send("search","search $p1"); 	break;
	 	case "DATABASE_PRAGMA"							:  $return = send("pragma","pragma $p1"); 	break;
		// COMMANDS
		
		// COMPOUND
	 	case "COMPOUND_SERVERSTATUS"					:  $return = send("serverstatus","serverstatus $p1"); 	break;
	 	case "COMPOUND_STATUS"							:  $return = send("status","status $p1"); 	break;
	 	case "COMPOUND_DISPLAYSTATUS"					:  $return = send("displaystatus","displaystatus $p1"); 	break;
	 	case "COMPOUND_READDIRECTORY"					:  $return = send("readdirectory","readdirectory $p1"); 	break;




	   default : echo "Unknown CMD : .$cmd" ;break;
	   }
	
   return $return;

	}


//******************************************************************************
//	loescht ein Tag bevor gesendet wird
//******************************************************************************
function clear($tag)
	{
	global $tag_kategorie;
	$id = false;
	$id = IPS_GetObjectIDByName($tag,$tag_kategorie);
	if ( $id ) SetValueString($id,"");
	}



//******************************************************************************
// warte auf Antwort von Squeezebox bis Timeout
//******************************************************************************
function wait($tag)
	{
	global $tag_kategorie;
	global $send_timeout;
	
	$id = false;
	$return = false;
	
	$id = IPS_GetObjectIDByName($tag,$tag_kategorie);

	if ( $id )
		{
		$start_sec = time();
		$timeout_sec = $start_sec + $send_timeout;
		$laufzeit = 0;
		while (time() <= $timeout_sec)
		   {
		   
		   usleep(10);
		   $laufzeit = $laufzeit + 10 ;
		   if ( GetValueString($id) != "" )
				{
				$return = GetValueString($id);
				break;
				}
		   }

		logging("--",$laufzeit);
	
		
		}

	return $return;
	
	}
function squeezeserver_connect()
	{
	global $cli_id;
	$connect = false;
	
	$connect = CSCK_SetOpen($cli_id,true);
	//sleep(5);
	$connect = CSCK_GetOpen($cli_id);

	
	echo "\nConnect:[".$connect."]";
	return $connect;
	}
	
function suche_mac($alias_name)
	{
	global $squeezebox_mac_adressen;
	global $squeezebox_aliasnamen;

	$mac_adresse = false;
	
	$key = array_search($alias_name, $squeezebox_aliasnamen);

	$mac_adresse = $squeezebox_mac_adressen[$key];
	
	return $mac_adresse;
	
	}
	
//******************************************************************************
// Logging
//******************************************************************************
function logging($p1,$text)
	{

	$logdatei = IPS_GetKernelDir() . "logs\\squeeze.log";
	$datei = fopen($logdatei,"a+");
	fwrite($datei, date("d.m.Y H:i:s").$p1 . $text . chr(13));
	fclose($datei);

	
	}
	
	
?>