<?

  //

   $s  = IPS_GetScript(IPS_GetScriptID("mysql"));
   require_once($s['ScriptFile']);


   if ( isset($IPS_VARIABLE))  $v = $IPS_VARIABLE ;  else $v = "?";

   //IPS_LogMessage("MYSQL.feucht","$c-$v");

   $link = mysql_ips_open();
   mysql_ips_insert_feucht($link,$v);
   mysql_ips_close($link);


?>