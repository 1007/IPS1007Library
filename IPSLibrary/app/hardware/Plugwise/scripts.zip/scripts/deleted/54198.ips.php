<?

 	define ("INSTANCE",39171);
 	$data = trim($IPS_VALUE);
 
	IPS_LogMessage("IN:",$data);
 
	if ( $data != 'accept' )
		{
		$data .= ":";
		$hash  = md5($data);
		$hash .= "\n";
		CSCK_SendText(INSTANCE,$hash);
		}

?>