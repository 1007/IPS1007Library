<?

 
		$debug = false;
		
	 	
	 	$offline = GetValueInteger("DBOX2.STATUS.OFFLINE.TIMESTAMP.DIFF");
   	$status = GetValueBoolean("DBOX2.STATUS.ONLINE");
	 	if ($debug)echo "\nDBOX2 $offline [$status]";
	
	   if ( $status == false and $offline > 600 )
	      {
	   	//SetValueInteger("AUSGANG.ARBEIT.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.ARBEIT.TV.STATUS.SOLL",false);
	      }
	   if ( $status == true and $offline < 360 )
	      {
	   	//SetValueInteger("AUSGANG.ARBEIT.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.ARBEIT.TV.STATUS.SOLL",true);
	      }


	 	$offline = GetValueInteger("DBOX3.STATUS.OFFLINE.TIMESTAMP.DIFF");
	 	$status = GetValueBoolean("DBOX3.STATUS.ONLINE");
		if ($debug) echo "\nDBOX3 $offline [$status]";

	   if ( $status == false and $offline > 600 )
	      {
	   	//SetValueInteger("AUSGANG.WOHNEN.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.WOHNEN.TV.STATUS.SOLL",false);
	      }
	   if ( $status == true and $offline < 360 )
	      {
	   	//SetValueInteger("AUSGANG.WOHNEN.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.WOHNEN.TV.STATUS.SOLL",true);
	      }



?>