<?


   require_once(IPS_GetScriptID("Funcpool").".ips.php");
   
	refreshfeed();
	

?>