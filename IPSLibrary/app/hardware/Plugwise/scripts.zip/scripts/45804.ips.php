<?

 	//IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   //$moduleManager = new IPSModuleManager('IPSEDIP','https://raw.github.com/MCS-51/IPSLibrary/Development/');
   //$moduleManager->LoadModule('', true);


	IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager('IPSEDIP','https://raw.github.com/MCS-51/IPSLibrary/Development/');
   $moduleManager->InstallModule();
?>