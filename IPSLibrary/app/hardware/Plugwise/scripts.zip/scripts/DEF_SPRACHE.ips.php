<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : DEF_SPRACHE.ips.php
Trigger  : 
Interval : 
*/


define("VOICE_TEST","Dies ist ein Test");



?>
