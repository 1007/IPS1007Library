<?php

	include('ProwlPHP.php');



function iphone_alarm($text)
	{
	
	return;
	
	$app   = "IPS";
	$event = "ALARM";
	
	$prowl = new Prowl('a3c47b0688ee7180c1ad97d9b7d9dcf595a02612');
	$prowl->push(array(
                'application'=>$app,
                'event'=>$event,
                'description'=>$text.' \n gesendet am ' . date('H:i:s'),
                'priority'=>0,
                
            ),true);

	var_dump($prowl->getError()); // Optional
	var_dump($prowl->getRemaining()); // Optional
	var_dump(date('d m Y h:i:s', $prowl->getResetdate())); // Optional

	}

?>
