<?


 	$a = snmpwalk("192.168.10.8", "public", "");
 
	print_r($a);


?>