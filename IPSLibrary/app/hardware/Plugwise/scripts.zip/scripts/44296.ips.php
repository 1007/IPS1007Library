<?

//******************************************************************************
//
//    $akt_timecode = Anzahl der Minuten am heutigen Tag
//
//******************************************************************************

	$debug = false;

	$root_daten = IPS_GetObjectIDByName("DATEN",0);
	$status_instance = IPS_GetObjectIDByName("STATUS",$root_daten);
	$ausgaenge_instance = IPS_GetObjectIDByName("AUSGAENGE",0);
	
	$heute = getdate();

	$akt_stunde   = $heute["hours"];
	$akt_minute   = $heute["minutes"];
	$akt_wochentag= $heute["wday"];
	$akt_tickcount= $heute[0];
	$akt_uhrzeit  = "$akt_stunde:$akt_minute";
	$akt_timecode = ($akt_stunde * 60 ) + $akt_minute;

	if ( $debug ) echo "\nTimcode:$akt_timecode";
	
	//***************************************************************************
	// Sonnenaufgang und Sonnenuntergang berechnen
   //***************************************************************************
   $tag = false;
   // difference between GMT and local time in hours:
   if (date('I') == 0 )
      {
       if ( $debug ) echo "\nEs ist Winterzeit";
      $gmt = 1;
      }
   else
      {
       if ( $debug ) echo "\nEs ist Sommerzeit";
      $gmt = 2;
      }

   $sunrise = strtotime(date("Y-m-d ").date_sunrise(time(), SUNFUNCS_RET_STRING, 49.991, 8.418, 90, $gmt));
   $string1 = date("d.m.y H:i", $sunrise);
   SetValueString(IPS_GetVariableIDByName("STATUS.SONNE.AUFGANG",$status_instance), date("H:i", $sunrise));
   $minuten = ( date("H", $sunrise) * 60 ) +  date("i", $sunrise) ;
   if ( $akt_timecode > $minuten )
		{
      $tag = true;
      }

   $sunset = strtotime(date("Y-m-d ").date_sunset(time(), SUNFUNCS_RET_STRING, 49.991, 8.418, 90, $gmt));
   $string2 = date("d.m.y H:i", $sunset);
   SetValueString(IPS_GetVariableIDByName("STATUS.SONNE.UNTERGANG",$status_instance), date("H:i", $sunset));
   $minuten = ( date("H", $sunset) * 60 ) +  date("i", $sunset) ;
   if ( $akt_timecode > $minuten )
		{
      $tag = false;
      }



   if ( $tag == true )
      {
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.TAG",$status_instance)) == false )
         {
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.TAG",$status_instance),true);
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE",$status_instance),true);
			}
		if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$status_instance)) == true )
			{
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$status_instance),false);
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE",$status_instance),false);
			}
	   }
   else
      {
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.TAG",$status_instance)) == true )
			{
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.TAG",$status_instance),false);
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE",$status_instance),false);
			}
		if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$status_instance)) == false )
			{
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$status_instance),true);
			SetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE",$status_instance),true);
			}
	   }


	//***************************************************************************
   // Tag - Nachtstrom
   // 360  =  06:00 Uhr
   // 1350 =  22:30 Uhr
   //***************************************************************************
   $tag = true;
   if ( $akt_timecode < 360  or $akt_timecode > 1350 )      // Nacht
		{
		if ($debug) echo "\nNachtstrom Ein";
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.TAG",$status_instance)) == true )
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.TAG",$status_instance),false);
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.NACHT",$status_instance)) == false )
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.NACHT",$status_instance),true);
		}
	else
		{
		if ($debug) echo "\nNachtstrom Aus";
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.TAG",$status_instance)) == false )
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.TAG",$status_instance),true);
      if ( GetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.NACHT",$status_instance)) == true )
      	SetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.NACHT",$status_instance),false);
		}
		

	//***************************************************************************
	// Hier sind wir in der  Nachtstrom-Zeit
	//***************************************************************************
   $stromnacht = GetValueBoolean(IPS_GetVariableIDByName("STATUS.STROM.NACHT",$status_instance));
   //$stromnacht = true;
	// Geschirrspueler *********************************
	$raum_instance = IPS_GetObjectIDByName("KUECHE",$ausgaenge_instance);
	$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.KUECHE.GESCHIRR",$raum_instance);
	$soll_instance = IPS_GetVariableIDByName("AUSGANG.KUECHE.GESCHIRR.STATUS.SOLL",$ausgang_instance);
   if ( GetValueBoolean($soll_instance) != $stromnacht )
		SetValueBoolean($soll_instance,$stromnacht);

	//***************************************************************************
	
	//***************************************************************************
	// Hier sind wir in der  Nacht-Zeit
	//***************************************************************************
   $nacht = GetValueBoolean(IPS_GetVariableIDByName("STATUS.SONNE.NACHT",$status_instance));
   //$nacht = true;
	// Licht Flur *********************************
	$raum_instance = IPS_GetObjectIDByName("FLUR",$ausgaenge_instance);
	$ausgang_instance = IPS_GetObjectIDByName("AUSGANG.FLUR.LICHT",$raum_instance);
	$soll_instance = IPS_GetVariableIDByName("AUSGANG.FLUR.LICHT.STATUS.SOLL",$ausgang_instance);
   if ( GetValueBoolean($soll_instance) != $nacht )
		SetValueBoolean($soll_instance,$nacht);

	//***************************************************************************



?>