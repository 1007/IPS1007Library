<?



 	$component = "Plugwise";

	IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component);
   $moduleManager->LoadModule('C:\\git\\IPS1007Library\\',true);

   $moduleManager->InstallModule('C:\\git\\IPS1007Library\\');



?>