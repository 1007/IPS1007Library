<?

  	$component = "Roomba";

	IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component);
   $moduleManager->DeployModule('C:\\git\\IPS1007Library\\');


?>