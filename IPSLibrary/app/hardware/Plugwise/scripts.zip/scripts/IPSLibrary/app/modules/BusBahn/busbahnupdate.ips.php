<?

	$remoteRepository = 'https://raw.github.com/1007/IPSLibrary/BusBahn/';

   $component = 'BusBahn';

	update($remoteRepository,$component);

function update($remoteRepository,$component)
	{
	IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component,$remoteRepository);
   $moduleManager->UpdateModule($remoteRepository);
	}

?>