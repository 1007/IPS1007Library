<?
	/**@addtogroup netplayer
	 * @{
	 * @file          NetPlayer_IDs.inc.php
	 * @author        Andreas Brauneis
	 * @version
	 * Version 2.50.1, 31.01.2012<br/>
	 *
	 * NetPlayer ID Konstanten
	 *
	 */

	//MediaPlayer
	define ("NP_ID_MEDIAPLAYER",              36728);

	//MP3 Player
	define ("NP_ID_CDDIRECTORYPATH",		  		29675);
	define ("NP_ID_CDDIRECTORYNAME",	    	   42423);
	define ("NP_ID_CDCATEGORYNAME",          	26386);
	define ("NP_ID_CDDIRECTORYIDX",           46774);
	define ("NP_ID_CDTRACKLISTHTML",          10762);
	define ("NP_ID_CDTRACKIDX",               35496);

	// Radio Player
	define ("NP_ID_RADIOIDX",                	22775);
	define ("NP_ID_RADIONAME",      				51922);
  	define ("NP_ID_RADIOURL",     				58416);

	// NetPlayer Controls
  	define ("NP_ID_POWER",                    44978);
  	define ("NP_ID_CONTROLTYPE",          		23726);
  	define ("NP_ID_REMOTECONTROL",            41599);
  	define ("NP_ID_MOBILECONTROL",            46070);

  	define ("NP_ID_CATEGORYLIST",            	10498);
  	define ("NP_ID_CDALBUMLIST",              57398);
  	define ("NP_ID_CDALBUMNAV",               14459);
  	define ("NP_ID_CDTRACKLIST",              56721);
  	define ("NP_ID_CDTRACKNAV",               37941);
  	define ("NP_ID_RADIOLIST",               	41939);
  	define ("NP_ID_RADIONAV",                	38508);
  	define ("NP_ID_SOURCE",                 	22077);
  	define ("NP_ID_CONTROL",                 	37437);
	define ("NP_ID_CDINTERPRET",             	52238);
	define ("NP_ID_CDALBUM",                 	15838);

  /** @}*/
?>