<?
	$remoteRepository = 'https://raw.github.com/1007/IPSLibrary/BusBahn/';

   $component = 'BusBahn';

	install($remoteRepository,$component);

function install($remoteRepository,$component)
	{
	IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component,$remoteRepository);
   $moduleManager->InstallModule($remoteRepository);
	}


?>