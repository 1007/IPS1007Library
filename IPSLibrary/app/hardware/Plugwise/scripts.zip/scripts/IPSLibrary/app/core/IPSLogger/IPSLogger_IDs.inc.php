<?
	/**@addtogroup ipslogger
	 * @{
	 *
	 * File mit IDs, die f�r den Betrieb des Loggers notwendig sind. 
	 * Die IDs werden vom Installations Script automatisch gesetzt, manuelle Ver�nderung dieses Files ist NICHT notwendig !!!
	 *
	 * @file          IPSLogger_IDs.inc.php
	 * @author        Andreas Brauneis
	 * @version
	 * Version 2.50.1, 31.01.2012<br/>
	 *
	 */

  // ---- Single Out --------------------------------------------------------------------------
  define ("c_ID_SingleOutEnabled",13341 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\SingleOut_Enabled]*/);
  define ("c_ID_SingleOutLevel",  59421 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\SingleOut_Level]*/);
  define ("c_ID_SingleOutMsg",    45109 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\SingleOut_Msg]*/);

  // ---- Html Out ----------------------------------------------------------------------------
  define ("c_ID_HtmlOutEnabled",  41733 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\HtmlOut_Enabled]*/);
  define ("c_ID_HtmlOutLevel",    58551 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\HtmlOut_Level]*/);
  define ("c_ID_HtmlOutMsgCount", 32060 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\HtmlOut_MsgCount]*/);
  define ("c_ID_HtmlOutMsgId",    25551 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\HtmlOut_MsgId]*/);
  define ("c_ID_HtmlOutMsgList",  34108 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\HtmlOut_MsgList]*/);

  // ---- IPS Out -----------------------------------------------------------------------------
  define ("c_ID_IPSOutEnabled",   30321 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\IPSOut_Enabled]*/);
  define ("c_ID_IPSOutLevel",     51316 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\IPSOut_Level]*/);

  // ---- EMail Out ---------------------------------------------------------------------------
  define ("c_ID_EMailOutEnabled", 49087 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EMailOut_Enabled]*/);
  define ("c_ID_EMailOutLevel",   13182 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EMailOut_Level]*/);
  define ("c_ID_EMailOutDelay",   54831 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EMailOut_SendDelay]*/);
  define ("c_ID_EMailOutPriority",37409 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EMailOut_Priority]*/);
  define ("c_ID_EMailOutMsgList", 38567 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EMailOut_MsgList]*/);

  // ---- File Out ----------------------------------------------------------------------------
  define ("c_ID_FileOutEnabled",  25291 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\FileOut_Enabled]*/);
  define ("c_ID_FileOutLevel",    26757 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\FileOut_Level]*/);
  define ("c_ID_FileOutDays",     11779 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\FileOut_Days]*/);

  // ---- Log4IPS Out -------------------------------------------------------------------------
  define ("c_ID_Log4IPSOutEnabled",55780 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\Log4IPSOut_Enabled]*/);
  define ("c_ID_Log4IPSOutLevel",  39421 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\Log4IPSOut_Level]*/);
  define ("c_ID_Log4IPSOutDays",   44727 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\Log4IPSOut_Days]*/);

  // ---- Echo Out ----------------------------------------------------------------------------
  define ("c_ID_EchoOutEnabled",   18768 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EchoSOut_Enabled]*/);
  define ("c_ID_EchoOutLevel",     31791 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\EchoOut_Level]*/);

  // ---- Prowl Out ---------------------------------------------------------------------------
  define ("c_ID_ProwlOutEnabled",  41703 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\ProwlOut_Enabled]*/);
  define ("c_ID_ProwlOutLevel",    49906 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\ProwlOut_Level]*/);
  define ("c_ID_ProwlOutPriority", 21184 /*[Program\IPSLibrary\app\core\IPSLogger\IPSLogger\ProwlOut_Priority]*/);

  // ------------------------------------------------------------------------------------------
  define ("c_ID_ScriptSendMail",       55447 /*[Program\IPSLibrary\app\core\IPSLogger\Scripts\IPSLogger_SendMail]*/);
  define ("c_ID_ScriptPurgeLogFiles",  16802 /*[Program\IPSLibrary\app\core\IPSLogger\Scripts\IPSLogger_PurgeLogFiles]*/);

	/** @}*/
?>