<?
//******************************************************************************
// Roomba starten
//******************************************************************************

	IPSUtils_Include ("Roomba_Configuration.inc.php", "IPSLibrary::config::modules::Roomba");
	IPSUtils_Include ("RoombaFuncpool.ips.php",    "IPSLibrary::app::modules::Roomba");

	roomba_go_clean();

?>