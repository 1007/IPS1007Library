<?
	/**@ingroup entertainment
	 * @{
	 *
	 * @file          Entertainment_AllRoomesOff.ips.php
	 * @author        Andreas Brauneis
	 * @version
	 * Version 2.50.1, 31.01.2012<br/>
	 *
	 * Ausschalten aller R�ume und Ger�te
	 *
	 */
	include_once "Entertainment.inc.php";

	Entertainment_TurnOffAllRoomesAndDevices();

  /** @}*/
?>