<?
//******************************************************************************
// Roomba auf Wartungsposition schicken
//******************************************************************************

	IPSUtils_Include ("Roomba_Configuration.inc.php", 	"IPSLibrary::config::hardware::Roomba");
	IPSUtils_Include ("RoombaFuncpool.inc.php",    		"IPSLibrary::app::hardware::Roomba");

	roomba_go_wartung();


?>