<?

	$component = 'Withings';
	update($component);


function update($component)
    {
	IPSUtils_Include ("IPSModuleManager.class.php","IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component);
   $moduleManager->UpdateModule('C:\IPSLibrary\\');
    }

?>