<?
//******************************************************************************
// Roomba Funktionen
//******************************************************************************

	IPSUtils_Include ("Roomba_Configuration.inc.php",    "IPSLibrary::config::modules::Roomba");

  	$CategoryRoombaData     = ("Program.IPSLibrary.data.modules.Roomba.RoombaData");
  	$CategoryLighthouseData = ("Program.IPSLibrary.data.modules.Roomba.LighthouseData");
  	$CategorySystemData     = ("Program.IPSLibrary.data.modules.Roomba.SystemData");

	//***************************************************************************
	// Roomba
	//***************************************************************************
	define   ("BUMP_AND_WHEEL_DROPS"									, IPS_GetVariableIDByName("BUMP_AND_WHEEL_DROPS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUMP_AND_WHEEL_DROPS_BUMP_RIGHT"					, IPS_GetVariableIDByName("BUMP_AND_WHEEL_DROPS_BUMP_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUMP_AND_WHEEL_DROPS_BUMP_LEFT" 					, IPS_GetVariableIDByName("BUMP_AND_WHEEL_DROPS_BUMP_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUMP_AND_WHEEL_DROPS_WHEEL_DROP_RIGHT"			, IPS_GetVariableIDByName("BUMP_AND_WHEEL_DROPS_WHEEL_DROP_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUMP_AND_WHEEL_DROPS_WHEEL_DROP_LEFT"			, IPS_GetVariableIDByName("BUMP_AND_WHEEL_DROPS_WHEEL_DROP_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WALL"                         						, IPS_GetVariableIDByName("WALL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_LEFT"                            			, IPS_GetVariableIDByName("CLIFF_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_FRONT_LEFT"                      			, IPS_GetVariableIDByName("CLIFF_FRONT_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_FRONT_RIGHT"                     			, IPS_GetVariableIDByName("CLIFF_FRONT_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_RIGHT"                           			, IPS_GetVariableIDByName("CLIFF_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("VIRTUAL_WALL"                          			, IPS_GetVariableIDByName("VIRTUAL_WALL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WHEEL_OVERCURRENTS"         						, IPS_GetVariableIDByName("WHEEL_OVERCURRENTS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WHEEL_OVERCURRENTS_SIDE_BRUSH"         			, IPS_GetVariableIDByName("WHEEL_OVERCURRENTS_SIDE_BRUSH",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WHEEL_OVERCURRENTS_MAIN_BRUSH"         			, IPS_GetVariableIDByName("WHEEL_OVERCURRENTS_MAIN_BRUSH",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WHEEL_OVERCURRENTS_RIGHT_WHEEL"        			, IPS_GetVariableIDByName("WHEEL_OVERCURRENTS_RIGHT_WHEEL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WHEEL_OVERCURRENTS_LEFT_WHEEL"         			, IPS_GetVariableIDByName("WHEEL_OVERCURRENTS_LEFT_WHEEL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("DIRT_DETECT"                           			, IPS_GetVariableIDByName("DIRT_DETECT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("INFRARED_CHARACTER_OMNI"               			, IPS_GetVariableIDByName("INFRARED_CHARACTER_OMNI",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS"                               			, IPS_GetVariableIDByName("BUTTONS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_CLEAN"                         			, IPS_GetVariableIDByName("BUTTONS_CLEAN",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_SPOT"                          			, IPS_GetVariableIDByName("BUTTONS_SPOT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_DOCK"                          			, IPS_GetVariableIDByName("BUTTONS_DOCK",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_MINUTE"                        			, IPS_GetVariableIDByName("BUTTONS_MINUTE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_HOUR"                          			, IPS_GetVariableIDByName("BUTTONS_HOUR",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_DAY"                           			, IPS_GetVariableIDByName("BUTTONS_DAY",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_SCHEDULE"                      			, IPS_GetVariableIDByName("BUTTONS_SCHEDULE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BUTTONS_CLOCK"                         			, IPS_GetVariableIDByName("BUTTONS_CLOCK",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("DISTANCE"                              			, IPS_GetVariableIDByName("DISTANCE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("ANGLE"	                              			, IPS_GetVariableIDByName("ANGLE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE"                        			, IPS_GetVariableIDByName("CHARGING_STATE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_NOT_CHARGING"           			, IPS_GetVariableIDByName("CHARGING_STATE_NOT_CHARGING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_RECONDITIONING_CHARGING"			, IPS_GetVariableIDByName("CHARGING_STATE_RECONDITIONING_CHARGING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_FULL_CHARGING"          			, IPS_GetVariableIDByName("CHARGING_STATE_FULL_CHARGING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_TRICKLE_CHARGING"       			, IPS_GetVariableIDByName("CHARGING_STATE_TRICKLE_CHARGING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_WAITING"                			, IPS_GetVariableIDByName("CHARGING_STATE_WAITING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_STATE_CHARGING_FAULT_CONDITION"		, IPS_GetVariableIDByName("CHARGING_STATE_CHARGING_FAULT_CONDITION",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("TEMPERATURE"                              		, IPS_GetVariableIDByName("TEMPERATURE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BATTERY_CHARGE"                           		, IPS_GetVariableIDByName("BATTERY_CHARGE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("BATTERY_CAPACITY"                         		, IPS_GetVariableIDByName("BATTERY_CAPACITY",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("WALL_SIGNAL"                              		, IPS_GetVariableIDByName("WALL_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_LEFT_SIGNAL"                        		, IPS_GetVariableIDByName("CLIFF_LEFT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_FRONT_LEFT_SIGNAL"                   	, IPS_GetVariableIDByName("CLIFF_FRONT_LEFT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_FRONT_RIGHT_SIGNAL"                  	, IPS_GetVariableIDByName("CLIFF_FRONT_RIGHT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CLIFF_RIGHT_SIGNAL"                        	, IPS_GetVariableIDByName("CLIFF_RIGHT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("OI_MODE"                        					, IPS_GetVariableIDByName("OI_MODE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("OI_MODE_OFF"                        				, IPS_GetVariableIDByName("OI_MODE_OFF",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("OI_MODE_PASSIVE"                        		, IPS_GetVariableIDByName("OI_MODE_PASSIVE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("OI_MODE_SAFE"                        			, IPS_GetVariableIDByName("OI_MODE_SAFE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("OI_MODE_FULL"                        			, IPS_GetVariableIDByName("OI_MODE_FULL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("SONG_PLAYING"                        			, IPS_GetVariableIDByName("SONG_PLAYING",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("NUMBER_OF_STREAM_PACKETS"                    	, IPS_GetVariableIDByName("NUMBER_OF_STREAM_PACKETS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("REQUESTED_VELOCITY"                        	, IPS_GetVariableIDByName("REQUESTED_VELOCITY",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("REQUESTED_RIGHT_VELOCITY"                    	, IPS_GetVariableIDByName("REQUESTED_RIGHT_VELOCITY",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("REQUESTED_LEFT_VELOCITY"                     	, IPS_GetVariableIDByName("REQUESTED_LEFT_VELOCITY",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("REQUESTED_RADIUS"                        		, IPS_GetVariableIDByName("REQUESTED_RADIUS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("RIGHT_ENCODER_COUNTS"                        	, IPS_GetVariableIDByName("RIGHT_ENCODER_COUNTS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LEFT_ENCODER_COUNTS"                        	, IPS_GetVariableIDByName("LEFT_ENCODER_COUNTS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER"                        			, IPS_GetVariableIDByName("LIGHT_BUMPER",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_FRONT_RIGHT"                    	, IPS_GetVariableIDByName("LIGHT_BUMPER_FRONT_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_RIGHT"                        	, IPS_GetVariableIDByName("LIGHT_BUMPER_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_CENTER_RIGHT"                   	, IPS_GetVariableIDByName("LIGHT_BUMPER_CENTER_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_CENTER_LEFT"                    	, IPS_GetVariableIDByName("LIGHT_BUMPER_CENTER_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_FRONT_LEFT"                     	, IPS_GetVariableIDByName("LIGHT_BUMPER_FRONT_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMPER_LEFT"                        		, IPS_GetVariableIDByName("LIGHT_BUMPER_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_LEFT_SIGNAL"              			, IPS_GetVariableIDByName("LIGHT_BUMP_LEFT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_FRONT_LEFT_SIGNAL"        			, IPS_GetVariableIDByName("LIGHT_BUMP_FRONT_LEFT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_CENTER_LEFT_SIGNAL"       			, IPS_GetVariableIDByName("LIGHT_BUMP_CENTER_LEFT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_CENTER_RIGHT_SIGNAL"      			, IPS_GetVariableIDByName("LIGHT_BUMP_CENTER_RIGHT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_FRONT_RIGHT_SIGNAL"       			, IPS_GetVariableIDByName("LIGHT_BUMP_FRONT_RIGHT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LIGHT_BUMP_RIGHT_SIGNAL"             			, IPS_GetVariableIDByName("LIGHT_BUMP_RIGHT_SIGNAL",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_SOURCES_AVAILABLE"                  	, IPS_GetVariableIDByName("CHARGING_SOURCES_AVAILABLE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_SOURCES_AVAILABLE_HOME_BASE"        	, IPS_GetVariableIDByName("CHARGING_SOURCES_AVAILABLE_HOME_BASE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CHARGING_SOURCES_AVAILABLE_INTERNAL_CHARGER" 	, IPS_GetVariableIDByName("CHARGING_SOURCES_AVAILABLE_INTERNAL_CHARGER",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("INFRARED_CHARACTER_LEFT"								, IPS_GetVariableIDByName("INFRARED_CHARACTER_LEFT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("INFRARED_CHARACTER_RIGHT"							, IPS_GetVariableIDByName("INFRARED_CHARACTER_RIGHT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("LEFT_MOTOR_CURRENT"  									, IPS_GetVariableIDByName("LEFT_MOTOR_CURRENT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("RIGHT_MOTOR_CURRENT"  								, IPS_GetVariableIDByName("RIGHT_MOTOR_CURRENT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("MAIN_BRUSH_MOTOR_CURRENT"  							, IPS_GetVariableIDByName("MAIN_BRUSH_MOTOR_CURRENT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("SIDE_BRUSH_MOTOR_CURRENT"  							, IPS_GetVariableIDByName("SIDE_BRUSH_MOTOR_CURRENT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("STASIS"                       						, IPS_GetVariableIDByName("STASIS",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("VOLTAGE"                                   	, IPS_GetVariableIDByName("VOLTAGE",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("CURRENT"                                   	, IPS_GetVariableIDByName("CURRENT",IPSUtil_ObjectIDByPath($CategoryRoombaData)));
	define   ("SONG_NUMBER"                               	, IPS_GetVariableIDByName("SONG_NUMBER",IPSUtil_ObjectIDByPath($CategoryRoombaData)));

	//***************************************************************************
	// Lighthouse
	//***************************************************************************

	define   ("LH_CHARGER_160"                               , IPS_GetVariableIDByName("LH_CHARGER_160",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
	define   ("LH_CHARGER_FORCE_FIELD"                       , IPS_GetVariableIDByName("LH_CHARGER_FORCE_FIELD",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
	define   ("LH_CHARGER_GREEN_BUOY"                        , IPS_GetVariableIDByName("LH_CHARGER_GREEN_BUOY",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
	define   ("LH_CHARGER_RED_BUOY"                          , IPS_GetVariableIDByName("LH_CHARGER_RED_BUOY",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));

  for ( $x=0;$x<LIGHTHOUSES_ANZAHL;$x++)
      {
      define	("LH_0".$x."_ID"                           	, IPS_GetVariableIDByName("LH_0".$x."_ID",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
      define	("LH_0".$x."_FENCE"                          , IPS_GetVariableIDByName("LH_0".$x."_FENCE",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
      define	("LH_0".$x."_FORCE_FIELD"                    , IPS_GetVariableIDByName("LH_0".$x."_FORCE_FIELD",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
      define	("LH_0".$x."_GREEN_BUOY"                     , IPS_GetVariableIDByName("LH_0".$x."_GREEN_BUOY",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
      define	("LH_0".$x."_RED_BUOY"                       , IPS_GetVariableIDByName("LH_0".$x."_RED_BUOY",IPSUtil_ObjectIDByPath($CategoryLighthouseData)));
      }

	//***************************************************************************
	// System
	//***************************************************************************
	define   ("PACKET_REQUESTED"                          	, IPS_GetVariableIDByName("PACKET_REQUESTED",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("PACKET_COUNTER"                          		, IPS_GetVariableIDByName("PACKET_COUNTER",IPSUtil_ObjectIDByPath($CategorySystemData)));

	define   ("KILOMETERZAEHLER"                          	, IPS_GetVariableIDByName("KILOMETERZAEHLER",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("STARTZEIT"                          				, IPS_GetVariableIDByName("STARTZEIT",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ENDZEIT"                          				, IPS_GetVariableIDByName("ENDZEIT",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("LAUFZEIT"                          				, IPS_GetVariableIDByName("LAUFZEIT",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("BATTERIE"                          				, IPS_GetVariableIDByName("BATTERIE",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("STARTTIMESTAMP"                          		, IPS_GetVariableIDByName("STARTTIMESTAMP",IPSUtil_ObjectIDByPath($CategorySystemData)));

	define   ("ROOMBA_STATUS_CHARGING"                       , IPS_GetVariableIDByName("ROOMBA_STATUS_CHARGING",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ROOMBA_STATUS_MOVING"                         , IPS_GetVariableIDByName("ROOMBA_STATUS_MOVING",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ROOMBA_STATUS_ONLINE"                         , IPS_GetVariableIDByName("ROOMBA_STATUS_ONLINE",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ROOMBA_STATUS_UNKNOWN"                        , IPS_GetVariableIDByName("ROOMBA_STATUS_UNKNOWN",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("POLLING_STATUS"                          		, IPS_GetVariableIDByName("POLLING_STATUS",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ROOMBA_DISTANCE"                          		, IPS_GetVariableIDByName("ROOMBA_DISTANCE",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("ROOMBA_CHARGING"                          		, IPS_GetVariableIDByName("ROOMBA_CHARGING",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("TIMER"                          					, IPS_GetVariableIDByName("TIMER",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("XBEE_INSTANCE"                          		, IPS_GetVariableIDByName("XBEE_INSTANCE",IPSUtil_ObjectIDByPath($CategorySystemData)));
	define   ("AKTIV"                          					, IPS_GetVariableIDByName("AKTIV",IPSUtil_ObjectIDByPath($CategorySystemData)));


//******************************************************************************
// Roomba Kommandos
//******************************************************************************
	define ('START'					,128);
	define ('BAUD'						,129);
	define ('SAFE'						,131);
	define ('FULL'						,132);
	define ('POWER'					,133);
	define ('SPOT'						,134);
	define ('CLEAN'					,135);
	define ('MAX'						,136);
	define ('DRIVE'  					,137);
	define ('MOTORS' 					,138);
	define ('LEDS'   					,139);
	define ('SONG'   					,140);
	define ('PLAY'   					,141);
	define ('SENSORS'					,142);
	define ('SEEK_DOCK'				,143);
	define ('PWM_MOTORS'				,144);
	define ('DRIVE_DIRECT' 			,145);
	define ('DRIVE_PWM'				,146);
	define ('STREAM' 					,148);
	define ('QUERY_LIST'				,149);
	define ('PAUSE_RESUME_STREAM'	,150);
	define ('SCHEDULING_LEDS'		,162);
	define ('DIGIT_LEDS_RAW'		,163);
	define ('DIGIT_LEDS_ASCII'		,164);
	define ('CMD_BUTTONS'			,165);
	define ('SCHEDULE'  				,167);
	define ('SET_DAY_TIME' 			,168);

   $debug = DEBUG_MODE;

//******************************************************************************
// Roomba auf Inittialisieren
//******************************************************************************
function roomba_init()
	{
	SetValueBoolean(POLLING_STATUS,false);

	command(START,0); sleep(2);
   command(SAFE,0);  sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba ausschalten
//******************************************************************************
function roomba_power()
	{
	SetValueBoolean(POLLING_STATUS,false);

	command(START,0); sleep(2);
   command(SAFE,0);  sleep(2);
	command(POWER,0);	sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba auf Ladestation schicken
//******************************************************************************
function roomba_go_home()
	{

   SetValueBoolean(POLLING_STATUS,false);

	command(START,0); 	 sleep(2);
	command(SAFE,0);		 sleep(2);
	command(SEEK_DOCK,0); sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba starten
//******************************************************************************
function roomba_go_clean()
	{

	roomba_go_wartung();

	reset_data();
	startzeit();

	SetValueBoolean(POLLING_STATUS,false);

	command(START,0); sleep(2);
   command(SAFE,0);  sleep(2);
   command(CLEAN,0);	sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba starten Maxmodus
//******************************************************************************
function roomba_go_max()
	{

	roomba_go_wartung();

	reset_data();
	startzeit();

	SetValueBoolean(POLLING_STATUS,false);

	command(START,0);	sleep(2);
   command(SAFE,0);  sleep(2);
   command(MAX,0);	sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba starten Spot
//******************************************************************************
function roomba_go_spot()
	{

	go_wartung();

	reset_data();
	startzeit();

	SetValueBoolean(POLLING_STATUS,false);

	command(START,0);	sleep(2);
   command(SAFE,0);  sleep(2);
   command(SPOT,0);	sleep(2);

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Roomba auf Wartungsposition schicken
//******************************************************************************
function roomba_go_wartung()
	{

	reset_data();
	startzeit();

   SetValueBoolean(POLLING_STATUS,false);

   command(START,0);	sleep(2);
   command(SAFE,0);	sleep(2);
   
	command(DRIVE_DIRECT,speed_to_byte(-50,-50));  	// 50 mm/s

	sleep(10);                               			// x * 50mm

	command(DRIVE_DIRECT,speed_to_byte(0,0));   		// Stop

	show_lcd_text(get_batterie());                  // Batterieladung auf LCD

	command(START,0);                               // Passive Mode

   SetValueBoolean(POLLING_STATUS,true);

	}

//******************************************************************************
// Daten senden
//******************************************************************************
function xbee_send($command)
	{
	$debug = false;
 	//$instance = XBEE_INSTANCE ;
 	$instance = ROOMBA_IO_INSTANZID;
	$xbee_id = 2;
	if ($debug) print_r($command);

	$string = "";
	for ( $x = 0 ; $x< sizeof($command) ; $x++)
	   {
	   $c = chr($command[$x]);
	   
	   $string =  $string . $c   ;

	   }

	$len = strlen($string);

	XBee_SendBuffer($instance,$xbee_id,$string);

	}

//******************************************************************************
// Kommando zusammensetzen
//******************************************************************************
function command($opcode,$databytes)
	{
	if ( GetValueBoolean(AKTIV))
		{
		if ( $debug )
			echo "\nScript ist gesperrt! Opcode:[$opcode]";
		return false;
		}
	SetValueBoolean(AKTIV,true);

	$sendbuffer = array();

	$debug = false;
	if ($debug) echo "\nOpcode:$opcode";

	switch($opcode)
	   {
		// Getting Started Commands
			// Start
	      case 128 :
							$sendbuffer[0] = 128;
							xbee_send($sendbuffer);
							break;
			// Baud
	      case 129 :
	      				$sendbuffer[0] = 129;
							xbee_send($sendbuffer);
							break;
		// Mode Commands
			// Safe
	      case 131 :
							$sendbuffer[0] = 131;
							xbee_send($sendbuffer);
							break;
			// Full
	      case 132 :
	      				$sendbuffer[0] = 132;
							xbee_send($sendbuffer);
							break;

		// Cleaning Commands
			// Clean
	   	case 135 :
							$sendbuffer[0] = 135;
							xbee_send($sendbuffer);
							break;
			// Max
	   	case 136 :  xbee_send(136); break;
			// Spot
		   case 134 :
							$sendbuffer[0] = 134;
							xbee_send($sendbuffer);
							break;
			// Seek Dock
	      case 143 :
							$sendbuffer[0] = 143;
							xbee_send($sendbuffer);
							break;
			// Schedule
			case 167 :	xbee_send(167);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							xbee_send($databytes[3]);
							xbee_send($databytes[4]);
							xbee_send($databytes[5]);
							xbee_send($databytes[6]);
							xbee_send($databytes[7]);
							xbee_send($databytes[8]);
							xbee_send($databytes[9]);
							xbee_send($databytes[10]);
							xbee_send($databytes[11]);
							xbee_send($databytes[12]);
							xbee_send($databytes[13]);
							xbee_send($databytes[14]);
							break;
			// SetDay/Time
			case 168 :	xbee_send(168);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							break;
			// Power
			case 133 :	xbee_send(133); break;
		// Actuator Commands
			// Drive
			case 137 :  xbee_send(137);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							xbee_send($databytes[3]);
							break;
			// Drive Direct
			case 145 :

							$sendbuffer[0] = 145;
							$sendbuffer[1] = $databytes[0];
							$sendbuffer[2] = $databytes[1];
							$sendbuffer[3] = $databytes[2];
							$sendbuffer[4] = $databytes[3];

							xbee_send($sendbuffer);

							break;
			// Drive PWM
			case 146 :  xbee_send(146);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							xbee_send($databytes[3]);
							break;
			// Motors
			case 138 :  xbee_send(138);
							xbee_send($databytes[0]);
							break;
			// PWM Motors
			case 144 :  xbee_send(144);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							break;
			// LEDs
			case 139 :  xbee_send(139);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							xbee_send($databytes[2]);
							break;
			// Scheduling LEDs
			case 162 :  xbee_send(162);
							xbee_send($databytes[0]);
							xbee_send($databytes[1]);
							break;
			// Digit LED Raw
			case 163 :
							$sendbuffer[0] = 163;
							$sendbuffer[1] = $databytes[0];
							$sendbuffer[2] = $databytes[1];
							$sendbuffer[3] = $databytes[2];
							$sendbuffer[4] = $databytes[3];

							xbee_send($sendbuffer);

							break;
			// Digit LEDs ASCII
			case 164 :
							$sendbuffer[0] = 164;
							$sendbuffer[1] = $databytes[0];
							$sendbuffer[2] = $databytes[1];
							$sendbuffer[3] = $databytes[2];
							$sendbuffer[4] = $databytes[3];

							xbee_send($sendbuffer);


							break;
			// Buttons
			case 165 :  xbee_send(165);
							xbee_send($databytes[0]);
							break;
			// Song
			case 140 :  xbee_send(140);
			            $song = $databytes[0];
			            $laenge = $databytes[1];
			            $laenge = ($laenge*2)+2;
			            //echo "\nSong:$song-$laenge";
			            for ($x=0;$x<$laenge;$x++)
			               	{//echo "\n$databytes[$x]";
			            		xbee_send($databytes[$x]);}
							break;

			// Play
			case 141 :  xbee_send(141);
							xbee_send($databytes[0]);
							break;
		// Input Commands
			// Sensors
			case 142 :  xbee_send(142);
							xbee_send($databytes[0]);
							break;
			// Query List
			case 149 :
							$anzahl = $databytes[0];
			            if ( $anzahl > 1 ) break; // Im Moment nur eine Gruppe
			            SetValueInteger(PACKET_REQUESTED,$databytes[1]);

							$sendbuffer[0] = 149;
							for ($x=0;$x<=$anzahl;$x++)
			               $sendbuffer[$x+1] = $databytes[$x];

							xbee_send($sendbuffer);

							break;
			// Stream
			case 148 :  xbee_send(148);
			            $anzahl = $databytes[0];
			            for ($x=0;$x<=$anzahl;$x++)
			               xbee_send($databytes[$x]);
							break;
			// Pause/Resume Stream
			case 150 :  xbee_send(150);
							xbee_send($databytes[0]);
							break;
		// default
			default:    echo "\nCommand:$opcode unbekannt";break;

		}

   SetValueBoolean(AKTIV,false);

   return true;

	}

//******************************************************************************
//	Berechnung der Restbatteriekapazit�t in %
//******************************************************************************
function get_batterie()
	{
	$s = 0;
	$x = GetValueInteger(BATTERY_CHARGE);
	$y = GetValueInteger(BATTERY_CAPACITY);

	if ( $y > 0 )
		$s = strval(($x /$y)*100);
	return  $s;
	}

//******************************************************************************
// Ausgabe von Text auf dem LCD
//******************************************************************************
function show_lcd_text($string)
	{
	if ( $string == "" ) return ;
	$byte1 = ord($string[0]);
	$byte2 = ord($string[1]);
	$byte3 = ord($string[2]);
	$byte4 = ord($string[3]);
	command(DIGIT_LEDS_ASCII,array($byte1,$byte2,$byte3,$byte4));
	}


function speed_to_byte($speed_rechts,$speed_links)
	{
   $a = array(0,0,0,0);

	$speed_rechts = intval($speed_rechts);
	$speed_links  = intval($speed_links);

	if ( $speed_rechts >  500 or $speed_links >  500 ) 	return $a;
	if ( $speed_rechts < -500 or $speed_links < -500 ) 	return $a;

	$hbr = ($speed_rechts & bindec('1111111100000000'))/256;
	$lbr = ($speed_rechts & bindec('0000000011111111'));
	$hbl = ($speed_links  & bindec('1111111100000000'))/256;
	$lbl = ($speed_links  & bindec('0000000011111111'));

	$a = array($hbr,$lbr,$hbl,$lbl);

	return $a;

	}

function reset_data()
	{

	SetValueString(STARTZEIT,"");
	SetValueString(ENDZEIT,"");
	SetValueString(LAUFZEIT,"");
	SetValueInteger(KILOMETERZAEHLER,0);

	SetValueBoolean(LH_CHARGER_160,false);
	SetValueBoolean(LH_CHARGER_FORCE_FIELD,false);
	SetValueBoolean(LH_CHARGER_GREEN_BUOY,false);
	SetValueBoolean(LH_CHARGER_RED_BUOY,false);

  for ( $x=0;$x<LIGHTHOUSES_ANZAHL;$x++)
      {
		SetValueInteger(constant("LH_0".$x."_ID"),0);
		SetValueBoolean(constant("LH_0".$x."_FENCE"),false);
		SetValueBoolean(constant("LH_0".$x."_FORCE_FIELD"),false);
		SetValueBoolean(constant("LH_0".$x."_GREEN_BUOY"),false);
		SetValueBoolean(constant("LH_0".$x."_RED_BUOY"),false);
		}
		

	}

function startzeit()
	{

	$timestamp = time();

	$s = strftime("%H:%M",$timestamp);

	SetValueInteger(STARTTIMESTAMP,$timestamp);
	SetValueString(STARTZEIT,$s);

	}

function endzeit()
	{

	$timestamp = time();

	$s = strftime("%H:%M",$timestamp);

	SetValueString(ENDZEIT,$s);

	}

function laufzeit()
	{

	$timestamp1 = time();
	$timestamp2 = GetValueInteger(STARTTIMESTAMP);

	$sec = $timestamp1 - $timestamp2;

	$stunden = intval($sec/3600);
	$minuten = intval(($sec - ($stunden*3600))/60);

	$s = sprintf('%02d:%02d', $stunden, $minuten);

	SetValueString(LAUFZEIT,$s);

	}

function decode($nr,$s)
	{

	$song 	= array($nr,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	$s 		= str_replace(':',',',$s);
	$array 	= explode(',',$s);

	$titel 	= $array[0];
	$duration= intval(strrev($array[1]));
	$scale 	= intval(strrev($array[2]));
	$beats 	= $array[3];

	$beats = preg_replace('![^0-9]!','',$beats);
	$beats   = $beats/60;
	$counter = 2;

	for ( $x=4;$x<20;$x++ )
	   {
		$d = $duration;
		$s = $scale;
		$n = $array[$x];
		$b1 = intval($n);
		$s1 = intval(strrev($n));
		if ( $b1 > 0 ) $d = $b1;
		if ( $s1 > 0 ) $s = intval($s1);
   	$n1 = preg_replace('/[^A-Za-z#]*/','',strtoupper($n));
		$b1 = note($s,$n1);
		$song[$counter] = $b1;
		$counter++;
		$song[$counter] = intval($d*$beats);
		$counter++;
	   }

	return $song;
	}

function note($scale,$note)
	{

	$b = 0;

	if ( $note == "C" ) $b = 0;
	if ( $note == "C#" )$b = 1;
	if ( $note == "D" ) $b = 2;
	if ( $note == "D#" )$b = 3;
	if ( $note == "E" ) $b = 4;
	if ( $note == "F" ) $b = 5;
	if ( $note == "F#" )$b = 6;
	if ( $note == "G" ) $b = 7;
	if ( $note == "G#" )$b = 8;
	if ( $note == "A" ) $b = 9;
	if ( $note == "A#" )$b = 10;
	if ( $note == "B" ) $b = 11;

	$b = ($scale*12) + $b;

	if ( $note == "P" ) $b = 0;

	$b = intval($b);

	return $b;
	}

?>