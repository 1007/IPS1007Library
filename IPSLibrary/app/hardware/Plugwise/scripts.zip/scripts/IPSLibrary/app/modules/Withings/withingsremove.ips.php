<?
  //****************************************************************************
  //  entfernt das Withingsmodul
  //****************************************************************************
  
	$component = 'Withings';

	remove($component);
  	

function remove($component)
    {
    IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
    $moduleManager = new IPSModuleManager($component);
    $moduleManager->DeleteModule();
    
    }

?>