<?

	$component = 'Withings';
	install($component);
  	

function install($component)
    {
    IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
    $moduleManager = new IPSModuleManager($component);
    $moduleManager->LoadModule('C:\IPSLibrary\\');
    $moduleManager->InstallModule();
    }


?>