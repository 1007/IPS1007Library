<?
	/**@defgroup ipsedip_visu EDIP Visualisierung
	 * @ingroup ipsedip
	 * @{
	 *
	 * Zur Zeit wird nur die Ansteuerung von Displays des Types eDIPTFT43A unterst�tzt (horizontale Montage). Die Anzeige
	 * ist aufgeteilt in einen Navigations Teil (links) und in einen Variablen  Teil (rechts). Angezeit werden alle Variablen
	 * au�er jene mit Profil "HTMLBox", editieren kann man zur Zeit folgende (Voraussetzung ActionScript ist definiert):
	 *  - Boolean
	 *  - Integer mit Prefix "%"
	 *  - Integer mit Assoziationen
	 *
	 * Zus�tzlich kann die Anzeige auch noch durch die Angabe von speziellen "Tags" in der Descritpion von Variablen/Links
	 * beeinflusst werden. Dadurch ist es m�glich:
	 *  - Darstellung von Texten mit doppelter Schriftgr�sse
	 *  - Darstelung von Assoziationen �ber die volle Breite
	 *  - Darstellung von Assoziationen mit variabler Breite
	 *
	 *  Montage Beispiel eines Displays in der Praxis
	 *  @image html IPSEDIP_Example.jpg
	 *
	 *  Einbindung des NetPlayers und der Entertainment Steuerung
	 *  @image html IPSEDIP_Player.jpg
	 *
	 *  Edit einer Variable mit Assoziationen
	 *  @image html IPSEDIP_Selection.jpg
	 *
	 *  Beispiel von Assoziationen �ber die volle Breite
	 *  @image html IPSEDIP_FullWidth.jpg
	 *
	 */
	/** @}*/

	/**@defgroup ipsedip IPSEDIP 
	 * @ingroup hardware
	 * @{
	 *
	 * Es handelt sich bei IPSEDIP um Scripts, mit denen es m�glich ist IPS Strukturen auf einem EDIP43 Display
	 * zu visualisieren. Das hat den Vorteil, dass man die Visualisierung komplett aus IPS steuern kann. Eine �nderung
	 * der EDIP Programmierung entf�llt somit komplett und eine Anbindung neuer EDIP Displays kann praktisch per
	 * Plug and Play erledigt werden !
	 *
	 * Update der Displays erfolgt entweder �ber einen internen Timer oder �ber Events (d.h es wird autom. f�r jede visualisierte
	 * Variable ein Event angelegt, das bei �nderung sofort ein Refresh des Displays ausl�st).
	 *
	 * @file          IPSEDIP.class.php
	 * @author        Andreas Brauneis
	 * @author        Andr� Czwalina
	 *
	 * EDIP Klasse
	 *
	 */

	include_once "IPSEDIP_Constants.inc.php";
	IPSUtils_Include ("IPSLogger.inc.php", "IPSLibrary::app::core::IPSLogger");
	IPSUtils_Include ("IPSEDIP_Configuration.inc.php", "IPSLibrary::config::hardware::IPSEDIP");

   /**
    * @class IPSEDIP
    *
    * Definiert ein allgemeines EDIP Display
    *
    * @author Andreas Brauneis
	 * @author Andr� Czwalina
    * @version
    * Version 2.50.2, 16.04.2012<br/>
    */
	abstract class IPSEDIP{
		private $sendDelay=5;

		protected $instanceId=0;
		protected $rootId=0;
		protected $currentId=0;
		private   $registerId=0;

		protected $objectIdsId=0;
		protected $objectValuesId=0;
		protected $objectCmdsId=0;
		protected $objectEditId=0;

		protected $messageArray=array();
		protected $objectList=array();//Types,Names,...

		/**
       * @public
		 *
		 * Initialisierung eines EDIP Display Objects
		 *
	    * @param integer $instanceId - ID des EDIP Displays.
		 */
		public function __construct($instanceId){
			$this->instanceId     = $instanceId;
			$this->rootId         = GetValue(IPS_GetObjectIDbyIdent(EDIP_VAR_ROOT, $instanceId));
			$this->currentId      = GetValue(IPS_GetObjectIDbyIdent(EDIP_VAR_CURRENT, $instanceId));
			$this->registerId     = GetValue(IPS_GetObjectIDbyIdent(EDIP_VAR_REGISTER, $instanceId));
			$this->objectIdsId    = IPS_GetObjectIDbyIdent(EDIP_VAR_OBJECTIDS, $instanceId);
			$this->objectValuesId = IPS_GetObjectIDbyIdent(EDIP_VAR_OBJECTVALUES, $instanceId);
			$this->objectBacklightId	=	IPS_GetObjectIDbyIdent(EDIP_VAR_BACKLIGHT, $instanceId);
			$this->objectCmdsId   = IPS_GetObjectIDbyIdent(EDIP_VAR_OBJECTCMDS, $instanceId);
			$this->objectEditId   = IPS_GetObjectIDbyIdent(EDIP_VAR_OBJECTEDIT, $instanceId);
		}

		abstract protected function AddMessageHeader();
		abstract protected function AddMessageCategories();
		abstract protected function AddMessageVariables();
		abstract protected function AddMessageValueEdit();
		abstract protected function AddMessageNotify();                                                        							

		private function GenerateEvents() {                          
			$objectIds = explode(',',GetValue($this->objectIdsId));
			$edipName  = IPS_GetName($this->instanceId);
			$edipNr	  = (int)substr($edipName,5,1);																			

			// Trigger Notify
			$objectId = IPS_GetObjectIDbyIdent(EDIP_VAR_NOTIFY, $this->instanceId);
			$eventId   = @IPS_GetEventIdByName($edipName."_Trigger_1" ,EDIP_ID_EVENTSCRIPT);	
			if ($eventId===false) {																						
				$eventId = IPS_CreateEvent(0);
				IPS_SetParent($eventId, EDIP_ID_EVENTSCRIPT);
		  		IPS_SetName($eventId, $edipName."_Trigger_1");													
				IPS_SetPosition($eventId, 1);																			
				}																												
			IPS_SetEventTrigger($eventId, 1, $objectId);															
			IPS_SetEventActive($eventId, true);

			// Trigger Backlight
			$objectId = IPS_GetObjectIDbyIdent(EDIP_VAR_BACKLIGHT, $this->instanceId);
			$eventId   = @IPS_GetEventIdByName($edipName."_Trigger_2" ,EDIP_ID_EVENTSCRIPT);		
			if ($eventId===false) {																						
				$eventId = IPS_CreateEvent(0);
				IPS_SetParent($eventId, EDIP_ID_EVENTSCRIPT);
		  		IPS_SetName($eventId, $edipName."_Trigger_2");													
				IPS_SetPosition($eventId, 2);																			
				}																												
			IPS_SetEventTrigger($eventId, 1, $objectId);															
			IPS_SetEventActive($eventId, true);


			$i=2;																															
			foreach ($objectIds as $objectId) {
			   $objectId   = (int)$objectId;
				$objectData = IPS_GetObject($objectId);
				if ($objectData['ObjectType']==2) {
				   $eventName = $edipName.'_'.IPS_GetName($objectId);
					$eventId   = @IPS_GetEventIdByName($eventName ,EDIP_ID_EVENTSCRIPT);
					if ($eventId===false) {
						$Nr = ($edipNr*10)+$i++;																					
						$eventId   = @IPS_GetEventIdByName($edipName."_Trigger_".$i ,EDIP_ID_EVENTSCRIPT);		
						if ($eventId===false) {																						
   						$eventId = IPS_CreateEvent(0);
							IPS_SetParent($eventId, EDIP_ID_EVENTSCRIPT);
							IPSLogger_Trc(__file__, "Create Event=$eventName, ID=$eventId, Parent=".EDIP_ID_EVENTSCRIPT);
   						}																												
				  		IPS_SetName($eventId, $edipName."_Trigger_".$i);													
						IPS_SetEventTrigger($eventId, 1, $objectId);															
						IPS_SetEventActive($eventId, true);

						IPS_SetPosition($eventId, $Nr);																			
						IPSLogger_Trc(__file__, "Aktivate Event=$eventName, ID=$eventId, Parent=".EDIP_ID_EVENTSCRIPT);
					}																														
				}
			}
		}

		private function DropEvents() {                                                    						
			$objectIds = explode(',',GetValue($this->objectIdsId));
			$edipName  = IPS_GetName($this->instanceId);
			$edipNr	  = (int)substr($edipName,5,1);																			
			$i = 0;																														
			$eventObj = IPS_GetObject(EDIP_ID_EVENTSCRIPT);																	
			$eventObjs = $eventObj['ChildrenIDs'];																				
			foreach ($eventObjs as $objectId) {
			   $eventId = (int)$objectId;																							

				if (substr(IPS_GetName($eventId),0,strlen($edipName))==$edipName){									
					$Nr = ($edipNr*10)+$i++;																						
				   $eventName = $edipName.'_Trigger_'.$i;																		
				   IPSLogger_Trc(__file__, "Deaktivate Event=$eventName, ID=$eventId");
			  		IPS_SetName($eventId, $eventName);																			
					IPS_SetEventActive($eventId, false);																		
					IPS_SetPosition($eventId, $Nr);																				
					if ($i > 25){																										
						IPS_DeleteEvent($eventId);																					
					   IPSLogger_Trc(__file__, "Delete Event=$eventName, ID=$eventId");								
					}																														
				} else {																													
						IPS_DeleteEvent($eventId);																					
				}																															
			}
		}


		private function StoreObjectData() {
			$objectIds    = array();
			$objectValues = array();
			$objectCmds   = array();
			foreach ($this->objectList as $object) {
			   if ($object['ObjectType']=='Category') {
					$objectIds[]    = $object['Link'];
				} else {
					$objectIds[]    = $object['Id'];
				}
				if ($object['DisplayType']=='Text') {
					$objectValues[] = "";
				} elseif (array_key_exists('Value', $object)) {
					$objectValues[] = $object['Value'];
				} else {
					$objectValues[] = "";
				}
				$objectCmds[]   = $object['Cmd'];
			}
			SetValue($this->objectIdsId,    implode(',',$objectIds));
			SetValue($this->objectValuesId, implode(',',$objectValues));
			SetValue($this->objectCmdsId,   implode(',',$objectCmds));
		}
		
		private function GetObjectDataByCmd($cmd) {
			$objectIds    = explode(',',GetValue($this->objectIdsId));
			$objectValues = explode(',',GetValue($this->objectValuesId));
			$objectCmds   = explode(',',GetValue($this->objectCmdsId));
			foreach ($objectCmds as $idx=>$objectCmd) {
				if ($objectCmd==$cmd) {
					$object['Cmd']   = $cmd;
					$object['Id']    = $objectIds[$idx];
					$object['Value'] = $objectValues[$idx];
					return $object;
				}
			}
			return false;
		}
		
		private function GetDisplayAttributte($id, $attribute, $default) {
		   $result     = $default;
			$object     = IPS_GetObject($id);
			$objectInfo = $object['ObjectInfo'];
			if (substr($objectInfo,0,2)=='##') {
				$attributeList = explode(',',substr($objectInfo,2));
				foreach ($attributeList as $keyValue) {
				   $keyValue = explode('=', $keyValue);
				   if ($keyValue[0]==$attribute) {
				      $result = $keyValue[1];
				   }
				}
			}
			return $result;
		}
		
		private function AddObjectCategory($link, $id, $name, $position) {
			$object = array();
			$object['Id']             = $id;
			$object['Link']           = $link;
			$object['Name']           = $name;
			$object['Position']       = $position;
			$object['DisplayType']    = 'Category';
			$object['ObjectType']     = 'Category';
			$this->objectList[] = $object;
		}

		private function AddObjectScript($link, $id, $name, $position) {
			$object = array();
			$object['Id']             = $id;
			$object['Link']           = $link;
			$object['Name']           = $name;
			$object['BlockBegin']     = true;
			$object['BlockEnd']       = true;
			$object['Position']       = $position;
			$object['DisplayType']    = 'Button';
			$object['ObjectType']     = 'Script';
			$object['ValueFormatted'] = 'Execute';
			$object['Width']          = 100;
			$object['LineIdx']        = 0;
			$color = 150*256*256+150*256+150;
			$red    = floor($color/256/256);
			$green  = floor(($color-$red*256*256)/256);
			$blue   = floor(($color-$red*256*256-$green*256));
			$object['Color']  =  $color;
			$object['Red']    =  $red;
			$object['Green']  =  $green;
			$object['Blue']   =  $blue;
			$this->objectList[] = $object;
		}
		
		private function AddObjectVariableValues($object, $associations, $valueCurrent, $objectType) {
			$lineIdx    = 0;
			$widthTotal = 0;
		   foreach ($associations as $idx=>$association) {
		      $object['BlockBegin']     = false;
				$object['BlockEnd']       = false;
		      if ($idx==0)                        $object['BlockBegin']     = true;
				if ($idx == count($associations)-1) $object['BlockEnd']       = true;
				$object['Idx']            = $idx;
				$object['Value']          = $association['Value'];
				$object['ValueFormatted'] = $object['Prefix'].$association['Name'].$object['Suffix'];
            $object['ValueFormatted'] = Str_Replace('%d',$valueCurrent, $object['ValueFormatted']);      						
				$object['ObjectType']     = $objectType;

            $color = $this->GetDisplayAttributte($object['Link'], 'Color', '8');
				$object['Farbe']    = $color; 																			

            $width = $this->GetDisplayAttributte($object['Link'], 'Width'.$association['Value'], '100');
				$object['Width']    = $width;
				$object['LineIdx']  = $lineIdx;
				$widthTotal = $widthTotal + $width;
				if ($widthTotal >= 100) {
				   $widthTotal = 0;
				   $lineIdx    = 0;
				} else {
				   $lineIdx = $lineIdx + 1;
				}

				if ($object['Value']==$valueCurrent) {
					$color = $association['Color'];
					if ($color==-1) {
					   $color = 150*256*256+150*256+150;
					}
				} else {
					$color = 60*256*256+60*256+60;
				}
				$red    = floor($color/256/256);
				$green  = floor(($color-$red*256*256)/256);
				$blue   = floor(($color-$red*256*256-$green*256));
				$object['Color']  =  $color;
				$object['Red']    =  $red;
				$object['Green']  =  $green;
				$object['Blue']   =  $blue;

				$this->objectList[] = $object;

		   }
		}
		
		private function AddObjectVariable($link, $id, $name, $position) {
			$value        = GetValue($id);
			$variable     = IPS_GetVariable($id);
			$action       = $variable['VariableCustomAction'] ;
			$type         = $variable['VariableValue']['ValueType'];
			$profile      = $variable['VariableCustomProfile'];
			if ($profile=='') return;
			$profileData  = IPS_GetVariableProfile($profile);
			$associations = $profileData['Associations'];
			$color        = -1;

			$object = array();
			$object['Id']             = $id;
			$object['Link']           = $link;
			$object['Name']           = $name;
			$object['Position']       = $position;
			$object['ValueFormatted'] = GetValueFormatted($id);
			$object['ObjectType']     = 'Variable';
			$object['DisplayType']    = 'Text';
			$object['BlockBegin']     = true;
			$object['BlockEnd']       = true;
			$object['Width']          = 100;
			$object['LineIdx']        = 0;
			$object['Suffix']         = $profileData['Suffix'];
			$object['Prefix']         = $profileData['Prefix'];
			$object['MaxValue']       = $profileData['MaxValue'];
			$object['MinValue']       = $profileData['MinValue'];
			$object['StepSize']       = $profileData['StepSize'];

			$object['Farbe']    	= $this->GetDisplayAttributte($object['Link'], 'Color', '8');  

			switch($type) {
			   case 0: // Boolean
					$object['DisplayType'] = 'Switch';
				   $value = $value ? 1 : 0;
				   $object['Value'] = $value;
					if (array_key_exists($value, $associations)) $color = $associations[$value]['Color'];
			      break;
			   case 1: // Integer
					$object['Value']          = $value;
			      if ($object['Suffix'] == '%') {
						$object['DisplayType']    =  'BarGraph';
				   } else if (count($profileData['Associations']) > 0) {
						$object['DisplayType'] = $this->GetDisplayAttributte($link, 'DisplayType', 'Switch');
						$object['Value']       = ""; // Call Edit Mode
						if ($object['DisplayType']=='Inline' or $object['DisplayType']=='Block'or $object['DisplayType']=='Select') {      
						   $this->AddObjectVariableValues($object, $associations, $value, 'Variable');
						   return;
						}
				   } else {
					}
					if (array_key_exists($value, $associations)) $color = $associations[$value]['Color'];
			      break;
			   case 2: // Float
					$object['Value']          = floatval($value);
			      break;
			   case 3: // String
					$object['Value']          = $value;
					if ($profile=='~HTMLBox') return; // Text
			      break;
			   default: // Unsupported Datatype
			}
			
			$object['DisplayType'] = $this->GetDisplayAttributte($link, 'DisplayType', $object['DisplayType']);
			if ($action==0 and $object['DisplayType']<>'Text' and $object['DisplayType']<>'BigText') {
				$object['DisplayType'] = 'Text';
			}

			if ($color==-1) $color = 150*256*256+150*256+150;
			$red    = floor($color/256/256);
			$green  = floor(($color-$red*256*256)/256);
			$blue   = floor(($color-$red*256*256-$green*256));
			$object['Color']  =  $color;
			$object['Red']    =  $red;
			$object['Green']  =  $green;
			$object['Blue']   =  $blue;
			$this->objectList[] = $object;

			if (GetValue($this->objectEditId)==$id) {
				$this->AddObjectVariableValues($object, $associations, $value, 'Edit');
			}
		}

		private function AddObjects() {
			$childrenIds = IPS_GetChildrenIDs($this->currentId);
			foreach ($childrenIds as $idx=>$childrenId) {
				$object     = IPS_GetObject($childrenId);
				$name       = IPS_GetName($childrenId);
				$position   = $object['ObjectPosition'];
				$linkId     = $childrenId;
				if ($object['ObjectType']==6) { // Link
					$link = IPS_GetLink($childrenId);
					$childrenId = $link['LinkChildID'];
					$object     = IPS_GetObject($childrenId);
				}
				switch($object['ObjectType']) {
					case 0: // Category
					case 1: // Instance
//						echo 'Found Category '.$name."\n";                                                           
						$this->AddObjectCategory($linkId, $childrenId, $name, $position);
						break;
					case 2: // Variable
//						echo 'Found Variable '.$name."\n";                                                           
						$this->AddObjectVariable($linkId, $childrenId, $name, $position);
						break;
					case 3: // Script
//						echo 'Found Script '.$name."\n";                                                           	
						$this->AddObjectScript($linkId, $childrenId, $name, $position);
						break;
					default:
					   // Unsupported Object ...
				}
			}
		}

		private function OrderObjects() {
			usort($this->objectList, 'IPSEDIP_CompareObjects');
			$cmd   = 30;
			$graph = 2;
			foreach ($this->objectList as $idx=>$object) {
			   if ($object['DisplayType'] == 'BarGraph') {
					$this->objectList[$idx]['Cmd'] = $graph;
					$graph++;
			   } else {
					$this->objectList[$idx]['Cmd'] = $cmd;
					$cmd++;
			   }
			}
		}

		/**
       * @public
		 *
		 * Refresh der Anzeige
		 *
		 */
		public function RefreshDisplay() {
		   IPSLogger_Trc(__file__, 'Refresh EDIP Display '.IPS_GetName($this->instanceId));
		   $this->AddObjects();
		   $this->OrderObjects();
			$this->StoreObjectData();
			$this->ReadNotify();

			$this->messageArray = array();
			$this->AddMessageHeader();
			$this->AddMessageCategories();
			$this->AddMessageVariables();
			$this->AddMessageValueEdit();
			$this->AddMessageNotify();                                                        	
			$this->sendArray($this->messageArray);
		}


		private function ReceiveCodeSpecial($code) {
			IPSLogger_Trc(__file__, 'Received SpecialCode='.$code.' from EDIP');
			switch ($code) {
				case 1: // Navigate Back
					if (GetValue($this->objectEditId)<>0) {
						SetValue($this->objectEditId,0);
					} elseif ($this->currentId <> $this->rootId) {
						$this->currentId = IPS_GetParent($this->currentId);
						SetValue(IPS_GetObjectIDbyIdent(EDIP_VAR_CURRENT, $this->instanceId), $this->currentId);
					} else {
					}
					break;
				case 2: // Refresh
					break;
				case 3: // NotifyQuitt
					SetValueString(IPS_GetObjectIDbyIdent(EDIP_VAR_NOTIFY, $this->instanceId),'');     															
					break;
			}
		}

		private function ReceiveCodeCategory($object) {
			IPSLogger_Trc(__file__, 'Received CategoryCode='.$object['Cmd'].' for CategoryId='.$object['Id'].' from EDIP');
			$this->currentId = (int)$object['Id'];
			SetValue(IPS_GetObjectIDbyIdent(EDIP_VAR_CURRENT, $this->instanceId), $this->currentId);

				$edipName 		= IPS_GetName( $this->instanceId);				                                                							
				$EdipConfig   	= IPSEDIP_GetConfiguration();                                                      											
				if ( $this->currentId <> $this->rootId and $EdipConfig[$edipName][EDIP_CONFIG_ROOT_TIMER] > 0 ){                                                         
						$timerId   = @IPS_GetEventIdByName($EdipConfig[$edipName][EDIP_CONFIG_NAME].'_Root_Timer' ,EDIP_ID_TIMERSCRIPT);                                 	
						IPS_SetEventCyclicTimeBounds($timerId, mktime(date('H'), date('i',time() +($EdipConfig[$edipName][EDIP_CONFIG_ROOT_TIMER]*60)), date('s')), 0);  	
						IPS_SetEventActive($timerId,true);                                                      												
				}

		}

		private function ReceiveCodeScript($object) {
			IPSLogger_Trc(__file__, 'Received CategoryCode='.$object['Cmd'].' for ScriptId='.$object['Id'].' from EDIP');
			IPS_RunScriptWaitEx((int)$object['Id'], array( 'IPS_SENDER'=>'WebFront', 'IPS_VALUE'=>null, 'IPS_VARIABLE'=>null, 'REMOTE_ADDR'=>null));
		}

		private function ReceiveCodeVariable($object) {
			$variableId   = (int)$object['Id'];
			$variable     = IPS_GetVariable($variableId);
			$value        = GetValue($variableId);
			$action       = $variable['VariableCustomAction'] ;
			$type         = $variable['VariableValue']['ValueType'];
			$profile      = $variable['VariableCustomProfile'];
			$profileData  = IPS_GetVariableProfile($profile);
			$associations = $profileData['Associations'];

			if ($profile=='' or $action==0) return;

			if (GetValue($this->objectEditId)<>0) {
				SetValue($this->objectEditId, 0);
			}

			switch($type) {
				case 0: // Boolean
					IPSLogger_Dbg(__file__, 'Execute Action '.$action);
					IPS_RunScriptWaitEx($action, array( 'SENDER'=>'WebFront', 'VALUE'=>!$value, 'VARIABLE'=>$variableId, 'REMOTE_ADDR'=>'localhost'));
					break;
				case 1: // Integer
					if ($object['Value']=="") {
						SetValue($this->objectEditId, $variableId);
					} else {
						IPS_RunScriptWaitEx($action, array( 'SENDER'=>'WebFront', 'VALUE'=>(int)$object['Value'], 'VARIABLE'=>$variableId, 'REMOTE_ADDR'=>'localhost'));
					}
					break;
				case 2: // Float
					break;
				case 3: // String
					break;
				default: // Unsupported Datatype
			}
		}

		/**
       * @public
		 *
		 * Empfang von Daten
		 *
	    * @param string $string - Empfangene Daten vom Display
	    * @param boolean $useEvents - Anlegen von Events f�r jede visualisierte Variable
		 */
		public function ReceiveText($string, $useEvents=true) {
		   if ($useEvents) {
				$this->DropEvents();
			}
			if (substr($string,0,1)==chr(27)) {
				switch(substr($string,1,1)) {
					case 'A': // Button Code received
						$cmd = ord(substr($string,3));
						$object = $this->GetObjectDataByCmd($cmd);
						if ($object===false) {
							$this->ReceiveCodeSpecial($cmd);
							break;
						}

						$objectData = IPS_GetObject((int)$object['Id']);
						switch($objectData['ObjectType']) {
							case 0: // Category
							case 1: // Instance
								$this->ReceiveCodeCategory($object);
								break;
							case 2: // Variable
								$this->ReceiveCodeVariable($object);
								break;
							case 3: // Script
								$this->ReceiveCodeScript($object);
								break;
							default:
								// Unsupported Object ...
						}
						break;

					case 'B': // Bargraph Value received
						$graph = ord(substr($string,3,1));
						$value = ord(substr($string,4));
						$object = $this->GetObjectDataByCmd($graph);
						$object['Value'] = (int)$value-10; // Correct Value (BarGraph 0..100 doesnt work, 10..110 works???)
						$this->ReceiveCodeVariable($object);
						break;
					default:
						// Unsupported Message Type
				}
			}
			$this->Backlight();                                                  																						
			$this->RefreshDisplay();

		   if ($useEvents) {
				$this->GenerateEvents();
			}
		}
		
		private function Backlight() {                                                      																		
				$edipName  = IPS_GetName($this->instanceId);                                                      												
				$edipNr	  = (int)substr($edipName,5,1);                                                      													
				$EdipConfig   	= IPSEDIP_GetConfiguration();                                                      												
				$BL 				= $EdipConfig[$edipName][EDIP_CONFIG_BACKLIGHT_HIGH];                                                      				
				$BlId 			= IPS_GetObjectIDbyIdent(EDIP_VAR_BACKLIGHT, $this->instanceId);                                                      
				if ($EdipConfig[$edipName][EDIP_CONFIG_BACKLIGHT_LOW] == GetValue($BlId)) SetValue($BlId, $BL);    											
				if ($EdipConfig[$edipName][EDIP_CONFIG_BACKLIGHT_TIMER] >0){                                                      						
						$timerId   = @IPS_GetEventIdByName($EdipConfig[$edipName][EDIP_CONFIG_NAME].'_Backlight_Timer' ,EDIP_ID_TIMERSCRIPT);                                 
						IPS_SetEventCyclicTimeBounds($timerId, mktime(date('H'), date('i',time() +($EdipConfig[$edipName][EDIP_CONFIG_BACKLIGHT_TIMER]*60)), date('s')), 0);  
						IPS_SetEventActive($timerId,true);                                                      													
				}                                                      																										
		}                                                      																												

		private function ReadNotify() {                                                      																		
			$NotifyId	=	IPS_GetObjectIDbyIdent(EDIP_VAR_NOTIFY, $this->instanceId);   																		            					   
			$this->NotifyMessage = GetValueString($NotifyId);                                                 													
		}                                                      																												


		private function SendArray($messageArray) {
			$messagePackage = '';
			foreach ($messageArray as $idx=>$message) {
				$messagePackage .='#'.$message.chr(13);
				if (strlen($messagePackage) >= 100) {
					$this->SendText($messagePackage);
					$messagePackage = '';
				}
			}
			if (strlen($messagePackage) > 0) {
				$this->SendText($messagePackage);
			}
		}
		
		/**
       * @public
		 *
		 * Senden von Daten
		 *
	    * @param string $string - Daten, die gesendet werden sollen
		 */
	   public function SendText($string){

			// Translate special Characters
			$string = str_replace("�", "\x8E", $string);
			$string = str_replace("�", "\x84", $string);
			$string = str_replace("�", "\x99", $string);
			$string = str_replace("�", "\x94", $string);
			$string = str_replace("�", "\x81", $string);
			$string = str_replace("�", "\x9A", $string);
			$string = str_replace("�", "\xE1", $string);
			//$string = str_replace(",", "\xFB", $string);
			$string = str_replace("�", "\xF8", $string);

			// Build Message
			$string = chr(17).chr(strlen($string)).$string; //Build Message <DC1><Len><DataBytes> 
			$checkSum = 0; // Calc Checksum
			for($i = 0; $i < strlen($string); $i++) {
				$checkSum = $checkSum + ord(substr($string, $i, 1));
			}
			$string .= chr($checkSum % 256);

			//IPSLogger_Com(__file__,'Send Msg to EDIP: '.$string);
			RegVar_SendText($this->registerId, $string);
			ips_sleep($this->sendDelay);
		}
	}


	function IPSEDIP_CompareObjects($object1, $object2) {
		if ($object1['Position'] == $object2['Position']) {
		   if (array_key_exists('Idx',$object1) and array_key_exists('Idx',$object2)) {
				if ($object1['Idx'] == $object2['Idx']) {
					return 0;
				} else {
					return ($object1['Idx'] < $object2['Idx']) ? -1 : 1;
				}
		   }
			return 0;
		} else {
			return ($object1['Position'] < $object2['Position']) ? -1 : 1;
		}
	}

	/** @}*/
?>