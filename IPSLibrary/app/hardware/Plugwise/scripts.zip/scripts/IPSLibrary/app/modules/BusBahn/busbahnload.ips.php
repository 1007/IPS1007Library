<?

	$remoteRepository = 'https://raw.github.com/1007/IPSLibrary/BusBahn/';

   $component = 'BusBahn';

	load($remoteRepository,$component);

function load($remoteRepository,$component)
	{
	IPSUtils_Include ("IPSModuleManager.class.php", "IPSLibrary::install::IPSModuleManager");
   $moduleManager = new IPSModuleManager($component,$remoteRepository);
   $moduleManager->LoadModule($remoteRepository);
	}


?>