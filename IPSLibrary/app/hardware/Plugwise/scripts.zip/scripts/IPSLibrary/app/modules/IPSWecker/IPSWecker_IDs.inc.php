<?
	/**@addtogroup ipsedip
	 * @{
	 *
	 * EDIP ID Konstanten
	 *
	 * @file        IPSWecker_IDs.inc.php
	 * @author      Andr� Czwalina
	 * @version
	* Version 1.00.1, 22.04.2012<br/>
	 *
	 */

	// EWecker Weckzeiten ID
	define ('WECKER_ID_WECKZEITEN',16413 );
	define ('WECKER_ID_TIMER',54267 );

	/** @}*/
?>