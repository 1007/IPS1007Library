<?
	/**@defgroup busbahn_configuration BusBahn Konfiguration
	 * @ingroup busbahn
	 * @{
	 *
	 * Konfiguration BusBahn
	 *
	 * @file          Default\BusBahn_Configuration.inc.php
	 * @author        1007
	 * @version
	 * Version 1.0.0, 05.03.2012
	 */

  //****************************************************************************
  //  Debug und Logging
  //****************************************************************************
  define  ( 'DEBUG_MODE'  , FALSE );
  define  ( 'LOG_MODE'    , FALSE );

  //****************************************************************************
  //  Stationen definieren.
  //  Um den genauen Namen der Haltestelle zu finden auf die Seite
  //  http://reiseauskunft.bahn.de/bin/bhftafel.exe gehen und dort
  //  den Namen suchen.
  //  Parameter 1 ist der Name ( Alias ) fuer die Station
	//  Parameter 2 ist der Bahnhof oder die Haltestelle
  //  Parameter 3 ist die Art der Tafel: "Abfahrt" oder "Ankunft"
  //  Parameter 4 ist die Wegezeit zur Station in Minuten ( farbliche Anzeige )
  //  Parameter 5 - 13 . Hier koennen bestimmte Verkehrsmittel ausgeschlossen werden
  //  Parameter 5  Verkehrsmittel ICE
  //  Parameter 6  Verkehrsmittel IC/EC
  //  Parameter 7  Verkehrsmittel Interregie/Schnellzuege
  //  Parameter 8  Verkehrsmittel Nahverkehr/Sonstiges
  //  Parameter 9  Verkehrsmittel SBahn
  //  Parameter 10 Verkehrsmittel Bus
  //  Parameter 11 Verkehrsmittel Faehren
  //  Parameter 12 Verkehrsmittel UBahn
  //  Parameter 13 Verkehrsmittel Tram
      
  //****************************************************************************
	GLOBAL $stationen;
	$stationen = array (
	//***************************************************************************
	//		Name			    Station 				    RICHTUNG ,Weg,ICE,IC/EC,IR,NV,SBAHN,BUS,FAEHRE,UBAHN,TRAM
	//***************************************************************************

	array("NameTab1",		"Frankfurt(M) Hbf",	"Abfahrt",10 ,true,true,true,true,true,true,true,true,true),
	array("NameTab2",		"Frankfurt(M) Hbf",	"Ankunft",10 ,true,true,true,true,true,true,true,true,true),
	array("NameTab3",		"",	                "Abfahrt",0  ,true,true,true,true,true,true,true,true,true),
	array("NameTab4",		"",	                "Ankunft",0  ,true,true,true,true,true,true,true,true,true),
	array("NameTab5",		"",	                "Abfahrt",0  ,true,true,true,true,true,true,true,true,true),
	array("NameTab6",		"",	                "Ankunft",0  ,true,true,true,true,true,true,true,true,true),


	//***************************************************************************
	array("",			"",						""			,0  ,false,false,false,false,false,false,false,false,false));
	//***************************************************************************
	
  //****************************************************************************
  //  Sonstiges
  //****************************************************************************
  define  ( 'MAX_LINES'    , 12 );    // maximale Eintraege pro Seite
  define  ( 'REFRESH_TIME' , 300 );   // wie oft sollen Daten aktualisiert werden ( Minuten )
  //****************************************************************************
  //  PROXY SERVER
  //****************************************************************************
  define  ( 'PROXY_SERVER'    , "" ); 

  define  ( 'REPOSITRY' ,  'https://raw.github.com/1007/IPSLibrary/BusBahn/') ;
  
   /** @}*/
?>