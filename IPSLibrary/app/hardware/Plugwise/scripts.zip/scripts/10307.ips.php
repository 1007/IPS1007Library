<?

                require_once IPS_GetScriptID("Verwaltung.Email").".ips.php";
                email_send("subject","Anwesenheitsaenderung");


?>