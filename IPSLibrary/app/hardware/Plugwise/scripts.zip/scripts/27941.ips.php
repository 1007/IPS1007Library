<?


 	$root_id = IPS_GetObjectIDByName("DASHBOARD",IPS_GetObjectIDByName("DATEN",0));
	$time_id = IPS_GetObjectIDByName("GRAPHEN_TIME",$root_id);
	$url_id  = IPS_GetObjectIDByName("GRAPHEN_URL",$root_id);
	$var_id  = IPS_GetObjectIDByName("GRAPHEN_ID",$root_id);
	

	
//$IPS_COMPONENT = 28905;

	if ( $IPS_COMPONENT == "day" )   { SetValueString($time_id,"day") ;   }
	if ( $IPS_COMPONENT == "week" )  { SetValueString($time_id,"week") ;  }
	if ( $IPS_COMPONENT == "month" ) { SetValueString($time_id,"month") ; }
	if ( $IPS_COMPONENT == "year" )  { SetValueString($time_id,"year") ;  }
	if ( is_numeric($IPS_COMPONENT)) { SetValueInteger($var_id,intval($IPS_COMPONENT));}

	$time = GetValueString($time_id);
	$var  = GetValueInteger($var_id);

	$url = "http://barebone:82/dashboard.php";
	$url = $url . "?VariableID=$var";
	$url = $url . "&showMinMax=false";
	$url = $url . "&showControls=false";
	$url = $url . "&timeName=$time";
	$url = $url . "&showExtrema=false";
	$url = $url . "&tsStart=0";
	
	IPS_LogMessage("........", $url);


	SetValueString($url_id, $url);





?>