<?
// Wird alle x Sekunden aufgerufen
// zum refresh der edip-displays


define (COM8 , 55153);
define (COM7 , 58653);

define ('CR',chr(13));

	// Welches Menu ist im edip aktiv ?
	$menu = GetValueInteger("EDIP7.MENU");
	refresh(COM7,$menu);
	$menu = GetValueInteger("EDIP8.MENU");
	refresh(COM8,$menu);


 
function refresh($com,$menu)
	{
	switch ($menu)
		{
		case 0:
    		menu_0($com);
    		break;
		case 1:
    		menu_1($com);
    		break;
		case 2001:	menu_2001($com);	break;
		case 2002:                    break;
		case 2003:	menu_2003($com);	break;
		case 4:
    		menu_4($com);
    		break;
		case 5:
    		menu_5($com);
    		break;
		case 6:
    		menu_6($com);
    		break;

		}
	}


function text($com,$font,$x,$y,$gx,$gy,$text)
	{

	COMPort_SendText($com, "#ZF ".$font.CR);
	COMPort_SendText($com, "#ZZ ".$gx.",".$gy.CR);
	COMPort_SendText($com, "#ZL,".$x.",".$y.",".$text.CR);

	}
	
	
function menu_0($com)
	{

	

	}

function menu_1($com)
	{
	// Hauptmenu
	COMPort_SendText($com, "#ZL,10,100,"."test".CR);

	}
function menu_2001($com)
	{

	heizung_data($com,"ARBEIT",30);
	heizung_data($com,"WOHNEN",60);
	heizung_data($com,"BAD",	90);
	heizung_data($com,"SCHLAF",120);
	heizung_data($com,"TREPPE",150);
	heizung_data($com,"AUSSEN",180);

	}
	
function menu_2003($com)
	{
	profile_data($com,"ARBEIT",30);
	profile_data($com,"WOHNEN",60);
	profile_data($com,"BAD",	90);
	profile_data($com,"SCHLAF",120);
	profile_data($com,"TREPPE",150);
	profile_data($com,"AUSSEN",180);
	}



function menu_3($com)
	{
	// Status
	$anwesend = GetValueBoolean("STATUS.ANWESEND.STATUS");
	$wach     = GetValueBoolean("STATUS.WACH.STATUS");

	text($com,5, 10,50,1,1,"Anwesend");
	text($com,5,100,50,2,2,$anwesend);
	
	text($com,5, 10,100,1,1,"Wach");
	text($com,5,100,100,2,2,$wach);


	}

function menu_4($com)
	{
	// DBox

	}

function menu_5($com)
	{
	// Multimedia
	

	}



function menu_6($com)
	{
	// Status
	$anwesend = GetValueBoolean("STATUS.ANWESEND.STATUS");
	$wach     = GetValueBoolean("STATUS.WACH.STATUS");

	//text($com,5, 10,50,1,1,"Anwesend");
	//text($com,5,100,50,2,2,$anwesend);

	$song = GetValueString("WINAMP.TRACKTITEL");
	
	$song = $song."++++++++++++++++";
	
	text($com,5, 10,100,1,1,$song);
	//text($com,5,100,100,2,2,$wach);


	}
//*************************************************************************
// Ende Menu
//*************************************************************************



function heizung_data($com,$raum,$y)
	{

	$font = 5;
	$raumt 				= $raum.".TF.TEMPERATUR";
	$raumf 				= $raum.".TF.FEUCHTIGKEIT";
	$raumb 				= $raum.".TF.BATTERIE";
	$raums  				= $raum.".SOLL.TEMPERATUR";
	$raumein  			= "HEIZUNG.".$raum.".EIN.STATUS";
	$raumauto       	= "HEIZUNG.".$raum.".AUTOMATIK";
	$raumsteuerung  	= "HEIZUNG.".$raum.".STEUERUNG.EIN";
	$raumerror       	= "HEIZUNG.".$raum.".ERROR";

	$s = number_format(GetValueFloat  ($raums),1);
	$t = number_format(GetValueFloat  ($raumt),1);
	$f = number_format(GetValueFloat  ($raumf),1);
	$t = substr(" ".$t,-4);
	$f = substr(" ".$f,-4);
	$b	= GetValueBoolean($raumb);
	if ($b)	$bat = "Bat"; else $bat ="   ";
	$e	= GetValueBoolean($raumein);
	//$e = true;
	if ($e)	$ein = chr(127); else $ein =" ";

	$st	= GetValueBoolean($raumsteuerung);
	if ($st)	$steuerung = "   "; else $steuerung ="off";
	$au	= GetValueBoolean($raumauto);
	if ($au)	$auto = "    "; else $auto ="/off";
	$er	= GetValueBoolean($raumerror);
	if ($er)	$f = "ERROR";


	$x=10;
	text($com, $font, $x,  		$y   ,1,1,$raum);
	text($com, $font, $x+130, 	$y-10,1,1,chr(248));
	text($com, $font, $x+180, 	$y   ,1,1,"%");
	text($com, $font, $x+70,  	$y-10,2,2,$t);
	text($com, $font, $x+150, 	$y   ,1,1,$f);

	text($com, 3	 , $x+200, 	$y   ,1,1,$steuerung);
	text($com, 3	 , $x+220, 	$y   ,1,1,$auto);

	text($com, 4	 , $x+245, 	$y   ,1,1,$ein);
	text($com, 3	 , $x+260, 	$y   ,1,1,$s);
	text($com, 3	 , $x+285, 	$y   ,1,1,$bat);


	}


function profile_data($com,$raum,$y)
	{

	$font = 5;

	$raump 		= GetValueString("PROFIL.".$raum.".String");
	
	$x=10;
	text($com, $font, $x,  		$y ,1,1,$raum);
	text($com, $font, $x+100, 	$y	,1,1,$raump);


	}







?>