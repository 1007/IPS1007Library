<?
/*
*******************************
 IP-SYMCON Event Scripting
*******************************
File     : Anwesenheit.Verwaltung.ips.php
Trigger  : 
Interval : 
*/

IPS_LogMessage("Anwesenhtung","RUN");
 
 $x1 = GetValueBoolean("FLUR.EINGANG.ANWESEND1.STATUS.Ein");
 $x2 = GetValueBoolean("FLUR.EINGANG.ANWESEND2.STATUS.Ein");

 if ( $x1 == true )
      {
      IPS_LogMessage("Anwesenheitsverwaltung","Anwesend");
      SetValueBoolean("STATUS.Anwesend",true);
      SetValueBoolean("STATUS.Abwesend",false);
      $anwesend = true;
      }
 else
      {
      IPS_LogMessage("Anwesenheitsverwaltung","Abwesend");
      SetValueBoolean("STATUS.Abwesend",true);
      SetValueBoolean("STATUS.Anwesend",false);
      $anwesend = false;
      }
      

if ( $anwesend == true )
      {
      FS20_SwitchMode(19669,true);
      sleep(2);
      //FS20_SwitchMode(14689,true);
      sleep(2);
      FS20_SwitchMode(49666,true);
      sleep(2);

      FS20_SwitchMode(58210,true);
      sleep(2);
      FS20_SwitchMode(56017,true);
      sleep(2);


      }
else
      {
      FS20_SwitchMode(19669,false);
      sleep(2);
      FS20_SwitchMode(14689,false);
      sleep(2);
      FS20_SwitchMode(49666,false);
      sleep(2);

      FS20_SwitchMode(58210,false);
      sleep(2);
      FS20_SwitchMode(56017,false);
      sleep(2);

      
      }
      
      


?>
