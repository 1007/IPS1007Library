<?
	//***************************************************************************
	// Nachtstrom ab 22:30 bis 06:30 ??   ( 390 - 1350 )
	//
	$ns_beginn = 1350;
	$ns_ende   = 390;
	//
	// Stand xx
	$keller_zaehler_kwh_hoch_start   = 15583.8;
	$keller_zaehler_kwh_nieder_start = 49582.9;
	$treppe_zaehler_kwh_start 			= 738.9;
	//
	// Strompreis
	$preis_niedertarif = 0.1057;
	$preis_hochtarif   = 0.1639;
	//
	//***************************************************************************
	
	
   $root_ekm   = IPS_GetObjectIDByName("EKM",IPS_GetObjectIDByName("SYSTEM",0));
  
   $root_daten    = IPS_GetObjectIDByName("STROM",IPS_GetObjectIDByName("DATEN",0));
   $root_monat    = IPS_GetObjectIDByName("MONAT",$root_daten);
   $root_monat_m1 = IPS_GetObjectIDByName("MONAT-1",$root_daten);
   $root_zaehler  = IPS_GetObjectIDByName("ZAEHLER",$root_daten);
   $root_tag      = IPS_GetObjectIDByName("TAG",$root_daten);
   $root_tag_m1   = IPS_GetObjectIDByName("TAG-1",$root_daten);

	$tag_impulse_n  = GetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_tag));
	$tag_impulse_h  = GetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_tag));

	$monat_impulse_n  = GetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_monat));
	$monat_impulse_h  = GetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_monat));

	$counter = GetValueInteger(IPS_GetVariableIDByName("Counter",$root_ekm));
	$current = GetValueFloat(IPS_GetVariableIDByName("Current",$root_ekm));

	$counter_old = GetValueInteger(IPS_GetVariableIDByName("Counter_old",$root_daten));
	$counter_neu = GetValueInteger(IPS_GetVariableIDByName("Counter_akt",$root_daten));
	
	$t_z_impulse   = GetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse",$root_zaehler));
	$t_z_impulse_n = GetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse_Niedertarif",$root_zaehler));
	$t_z_impulse_h = GetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse_Hochtarif",$root_zaehler));

	$heute = getdate();

	$akt_stunde   = $heute["hours"];
	$akt_minute   = $heute["minutes"];
	$akt_timecode = ($akt_stunde * 60 ) + $akt_minute;

	$hochtarif = true;
	if ( $akt_timecode < $ns_ende or $akt_timecode > $ns_beginn )
	   $hochtarif = false;
	   
	if ( $hochtarif )
		$preis = $preis_hochtarif;
	else
		$preis = $preis_niedertarif;

	// Differenz berechnen . Counterneustart abfangen
	if ( $counter >= $counter_old )
	   $diff = $counter - $counter_old ;
	else
	   $diff = $counter;
	
	$diff_h = 0;
	$diff_n = 0;
	
	$t_z_impulse = $t_z_impulse + $diff ;
	if ( $hochtarif )
	   {
		$t_z_impulse_h = $t_z_impulse_h + $diff ;
		$diff_h = $diff;
		}
	else
		{
		$t_z_impulse_n = $t_z_impulse_n + $diff ;
		$diff_n = $diff;
		}
	
	$akt_kosten = ($current/1000) * $preis;
	
	$counter_neu = $counter_neu + $diff ;
	
//	$verbrauch = ($counter_neu/800);

//	$kosten_niedertarif = $verbrauch * $preis_niedertarif;


	$t_z_gesamt   = $treppe_zaehler_kwh_start        + ($t_z_impulse/800);
	$k_z_gesamt_h = $keller_zaehler_kwh_hoch_start   + ($t_z_impulse_h/800);
	$k_z_gesamt_n = $keller_zaehler_kwh_nieder_start + ($t_z_impulse_n/800);
	$k_z_gesamt   = $k_z_gesamt_h + $k_z_gesamt_n ;

	$tag_impulse_n = $tag_impulse_n + $diff_n;
	$tag_impulse_h = $tag_impulse_h + $diff_h;

	$monat_impulse_n = $monat_impulse_n + $diff_n;
	$monat_impulse_h = $monat_impulse_h + $diff_h;


   $tag_verbrauch_n = $tag_impulse_n/800;
   $tag_verbrauch_h = $tag_impulse_h/800;

	$tag_kosten_n = $tag_verbrauch_n * $preis_niedertarif ;
	$tag_kosten_h = $tag_verbrauch_h * $preis_hochtarif ;


	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_tag),$tag_impulse_n);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_tag),$tag_impulse_h);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_monat),$monat_impulse_n);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_monat),$monat_impulse_h);


	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_tag),$tag_verbrauch_n);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_tag),$tag_verbrauch_h);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_tag),$tag_verbrauch_h+$tag_verbrauch_n);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_tag),$tag_kosten_h);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_tag),$tag_kosten_n);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_tag),$tag_kosten_n+$tag_kosten_h);


	SetValueFloat(IPS_GetVariableIDByName("Treppen_Zaehler_kwh_Gesamt",$root_zaehler),$t_z_gesamt);
	SetValueFloat(IPS_GetVariableIDByName("Keller_Zaehler_kwh_Hochtarif",$root_zaehler),$k_z_gesamt_h);
	SetValueFloat(IPS_GetVariableIDByName("Keller_Zaehler_kwh_Niedertarif",$root_zaehler),$k_z_gesamt_n);
	SetValueFloat(IPS_GetVariableIDByName("Keller_Zaehler_kwh_Gesamt",$root_zaehler),$k_z_gesamt);

	SetValueFloat(IPS_GetVariableIDByName("Treppen_Zaehler_kwh_Start",$root_zaehler),$treppe_zaehler_kwh_start);
	SetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse",$root_zaehler),$t_z_impulse);
	SetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse_Niedertarif",$root_zaehler),$t_z_impulse_n);
	SetValueInteger(IPS_GetVariableIDByName("Treppen_Zaehler_Impulse_Hochtarif",$root_zaehler),$t_z_impulse_h);

	SetValueFloat(IPS_GetVariableIDByName("Keller_Zaehler_kwh_Niedertarif_Start",$root_zaehler),$keller_zaehler_kwh_nieder_start);
	SetValueFloat(IPS_GetVariableIDByName("Keller_Zaehler_kwh_Hochtarif_Start",$root_zaehler),$keller_zaehler_kwh_hoch_start);

	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_aktuell",$root_daten),$current);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_aktuell",   $root_daten),$akt_kosten);
	SetValueInteger(IPS_GetVariableIDByName("Counter_old",    $root_daten),$counter);
	SetValueInteger(IPS_GetVariableIDByName("Counter_akt",    $root_daten),$counter_neu);
	SetValueBoolean(IPS_GetVariableIDByName("Tarif",          $root_daten),$hochtarif);

	


?>