<?

	require_once(IPS_GetScriptID("Funcpool.Roomba").".ips.php");

	go_home();


?>