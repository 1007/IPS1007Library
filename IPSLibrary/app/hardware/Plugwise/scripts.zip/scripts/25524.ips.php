<?


// Dieses Skript legt eine Kontrolldatei fr IPSWatchDog an.
// Es muss alle 15 Sekunden ausgefhrt werden

define("DateiName", "..\alive.ips"); //Dateiname fr alive Datei definieren
// normalerweise wrde die Datei im Verzeichnis \IPS-SYMCON\SCRIPTS angelegt
// durch ..\ wird sie jedoch im Wurzelverchnis von IPS erstellt, also dort, wo auch ips.exe und IPSWatchDog.exe liegen

//Datei vorhanden?
$dateifehlt = !file_exists(DateiName);

//falls die Datei fehlt, neu anlegen
if ($dateifehlt) {
		$inhalt = date("d.m.y - H:i"); // Ich habe nur zu Kontrollzwecken etwas in die Datei geschrieben. Sie kann aber auch leer bleiben
		$datei = fopen(DateiName, "a");
		fwrite ($datei, $inhalt);
		fclose($datei);
		}


?>