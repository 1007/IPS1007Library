<?

	require_once(IPS_GetScriptID("Funcpool.DBox").".ips.php");

//	refresh(DBOX2_IP,"DBOX2");
	
//refresh(DBOX3_IP,"DBOX3");



//dbox_status();


function background($ip)
	{

	$string = "lock=1&clear=1&png=/tmp/ips1007.png";
	$status = dbox_control($ip,DBOXCONTROL_LCD,$string,0);
	$zeit = date('H:i:s') ;
	$string = rawurlencode("IP-Symcon  $zeit");
	$string = "xpos=3&ypos=10&size=10&font=0&text=$string&update=1";
	dbox_control($ip,DBOXCONTROL_LCD,$string,0);


	//echo "\nBackground:$status";

	if ( $status == "error" )
		{
		dbox_upload($ip,"ips1007.png");
		//dbox_control($ip,DBOXCONTROL_LCD,$string,0);
	   }
	}

function refresh($ip,$i)
	{

	background($ip);

	$string 	= "$i.DATA";
	$standby = "$i.STATUS.STANDBY";
	$online 	= "$i.STATUS.ONLINE";

   dbox_control($ip,DBOXCONTROL_STANDBY,"",0);
   $status = GetValueString($string);
	$stb    = GetValueInteger($standby);
	$status = preg_replace('/(\r|\n)/','',$status);

	if ( $status == "on" ) 	SetValueInteger($standby,$stb+1);
	if ( $status == "off" ) SetValueInteger($standby,0);


	//echo "\nStandbytimer: $stb ";
	// EPG Zappen waere moeglich !
	if ( $stb > 2 )
	   {
		$status = GetValueBoolean($online);
		if ( $status == 1 )
		   {
		   // Testen ob Aufnahme laeuft
   		dbox_control($ip,DBOXCONTROL_SETMODE,"status",0);
   		$status = GetValueString($string);
			$status = preg_replace('/(\r|\n)/','',$status);
			//echo "\nStatus: $status";
			if ( $status == "off" ) // keine aufnahme laeuft
				{
	      	//echo "\nkein Aufnahme";
	      	//dbox_control($ip,DBOXCONTROL_RCEM,"KEY_DOWN",0);
	      	}
			else
				{
				//echo "\nAufnahme";
				SetValueInteger($standby,0);
				}
	      }
	   }



	$aussen = number_format(GetValueFloat("AUSSEN.TF.TEMPERATUR"),1);
	$arbeit = number_format(GetValueFloat("ARBEIT.TF.TEMPERATUR"),1);
	$wohnen = number_format(GetValueFloat("WOHNEN.TF.TEMPERATUR"),1);
	$schlaf = number_format(GetValueFloat("SCHLAF.TF.TEMPERATUR"),1);
	$treppe = number_format(GetValueFloat("TREPPE.TF.TEMPERATUR"),1);
	$bad    = number_format(GetValueFloat("BAD.TF.TEMPERATUR"),1);

	$aussen = rawurlencode($aussen);
	$arbeit = rawurlencode($arbeit);
	$wohnen = rawurlencode($wohnen);
	$schlaf = rawurlencode($schlaf);
	$treppe = rawurlencode($treppe);
	$bad    = rawurlencode($bad);


	$string = "xpos=4&ypos=48&size=38&font=2&text=$aussen&update=1";
	dbox_control($ip,DBOXCONTROL_LCD,$string,0);

	$s = rawurlencode("$arbeit  $schlaf");
	$string = "xpos=55&ypos=45&size=12&font=0&text=$s&update=1";
	dbox_control($ip,DBOXCONTROL_LCD,$string,0);

	$s = rawurlencode("$wohnen  $bad");
	$string = "xpos=55&ypos=30&size=12&font=0&text=$s&update=1";
	dbox_control($ip,DBOXCONTROL_LCD,$string,0);

	$string = "xpos=70&ypos=58&size=12&font=0&text=$treppe&update=1";
	dbox_control($ip,DBOXCONTROL_LCD,$string,0);


	}


function dbox_status()
	{
	
			$debug = false;

		/*
	 	$offline = GetValueInteger("DBOX2.STATUS.OFFLINE.TIMESTAMP.DIFF");
   	$status = GetValueBoolean("DBOX2.STATUS.ONLINE");
	 	if ($debug)echo "\nDBOX2 $offline [$status]";

	   if ( $status == false and $offline > 600 )
	      {
	   	//SetValueInteger("AUSGANG.ARBEIT.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.ARBEIT.TV.STATUS.SOLL",false);
	      }
	   if ( $status == true and $offline < 360 )
	      {
	   	//SetValueInteger("AUSGANG.ARBEIT.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.ARBEIT.TV.STATUS.SOLL",true);
	      }

	*/
	
	
	 	$offline = GetValueInteger("DBOX3.STATUS.OFFLINE.TIMESTAMP.DIFF");
	 	$status = GetValueBoolean("DBOX3.STATUS.ONLINE");
		if ($debug) echo "\nDBOX3 $offline [$status]";

	   if ( $status == false and $offline > 600 )
	      {
	   	//SetValueInteger("AUSGANG.WOHNEN.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.WOHNEN.TV.STATUS.SOLL",false);
	      }
	   if ( $status == true and $offline < 360 )
	      {
	   	//SetValueInteger("AUSGANG.WOHNEN.TV.TIMER",0);
	 		SetValueBoolean("AUSGANG.WOHNEN.TV.STATUS.SOLL",true);
	      }

	
	}
	

?>