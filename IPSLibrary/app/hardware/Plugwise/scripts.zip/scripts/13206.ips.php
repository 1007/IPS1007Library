<?
	
	require_once IPS_GetScriptID("Verwaltung.Email").".ips.php";
  

	$root_id = IPS_GetObjectIDByName("DATEN",0);
	$root_id_ausgaenge = IPS_GetObjectIDByName("AUSGAENGE",0);


	keller_verwaltung($root_id,"WASCHMASCHINE");
	keller_verwaltung($root_id,"TROCKNER");

	wach_anwesend_verwaltung($root_id,$root_id_ausgaenge);

	piri13_verwaltung();

// Setzt den Eingangsstatus der PIRI13 Eingaenge zurueck
function piri13_verwaltung()
	{

	$now = time();
	
   $inst = IPS_GetObjectIDByName("WOHNEN",IPS_GetObjectIDByName("EINGAENGE",0));
   $inst = IPS_GetObjectIDByName("EINGANG.WOHNEN.PIRI13",$inst);
   $in1  = IPS_GetObjectIDByName("EINGANG.WOHNEN.PIRI13.EINGANG1.VISU",$inst);
   $in2  = IPS_GetObjectIDByName("EINGANG.WOHNEN.PIRI13.EINGANG2.VISU",$inst);


	$count = GetValueInteger($in1);
	if ( $count > 0 ) { $count = $count - 1; SetValueInteger($in1,$count); }
	
	$count = GetValueInteger($in2);
	if ( $count > 0 ) { $count = $count - 1; SetValueInteger($in2,$count); }

	
	}
	
function wach_anwesend_verwaltung($root_id,$root_id_ausgaenge)
	{

	
	$wach_id     = IPS_GetObjectIDByName("STATUS.WACH",IPS_GetObjectIDByName("STATUS",$root_id));
	$wach        = GetValueBoolean($wach_id);
	$anwesend_id  = IPS_GetObjectIDByName("STATUS.ANWESEND",IPS_GetObjectIDByName("STATUS",$root_id));
	$anwesend    = GetValueBoolean($anwesend_id);

	
	
	
	$dreambox_id = IPS_GetObjectIDByName("ARBEIT",$root_id_ausgaenge);
	$dreambox_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.DBOX",$dreambox_id);
	$dreambox_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.DBOX.STATUS.SOLL",$dreambox_id);

	$toshiba_id = IPS_GetObjectIDByName("ARBEIT",$root_id_ausgaenge);
	$toshiba_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.TV",$toshiba_id);
	$toshiba_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.TV.STATUS.SOLL",$toshiba_id);

	$panasonic_id = IPS_GetObjectIDByName("WOHNEN",$root_id_ausgaenge);
	$panasonic_id = IPS_GetObjectIDByName("AUSGANG.WOHNEN.TV",$panasonic_id);
	$panasonic_id = IPS_GetObjectIDByName("AUSGANG.WOHNEN.TV.STATUS.SOLL",$panasonic_id);

	$monitor_id = IPS_GetObjectIDByName("ARBEIT",$root_id_ausgaenge);
	$monitor_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.MONITOR",$monitor_id);
	$monitor_id = IPS_GetObjectIDByName("AUSGANG.ARBEIT.MONITOR.STATUS.SOLL",$monitor_id);

	
	if ( $wach AND $anwesend )
	   {
	   SetValueBoolean($dreambox_id,true);
	   SetValueBoolean($toshiba_id,true);
	   SetValueBoolean($panasonic_id,true);
	   SetValueBoolean($monitor_id,true);

		}
	else
		{
		//SetValueBoolean($dreambox_id,false);
		SetValueBoolean($toshiba_id,false);
	   SetValueBoolean($panasonic_id,false);
	   SetValueBoolean($monitor_id,false);

		}


	
	
	
	}
	
	


//*******************************************************************
// Waschmaschine und Trockner
//*******************************************************************
function keller_verwaltung($root_id,$geraet)
	{
	$debug = false;
	
	$raum_id     = IPS_GetObjectIDByName("KELLER",$root_id);
	$geraet_id   = IPS_GetObjectIDByName($geraet,$raum_id);
	
	$start_id    = IPS_GetObjectIDByName($geraet.".START",$geraet_id);
	$ende_id     = IPS_GetObjectIDByName($geraet.".ENDE",$geraet_id);
	$laufzeit_id = IPS_GetObjectIDByName($geraet.".LAUFZEIT",$geraet_id);
	$laeuft_id   = IPS_GetObjectIDByName($geraet.".LAEUFT",$geraet_id);
	$eingang_id  = IPS_GetObjectIDByName($geraet.".EINGANG",$geraet_id);
   $laeuft      = GetValueBoolean($laeuft_id);
   $eingang     = GetValueBoolean($eingang_id);


   $t1 = time() / 60;    // aktuelle Zeit in Minuten

   $array = IPS_GetVariable($eingang_id);

   $t2 = $array["VariableUpdated"]/60;
	$diff = $t1 - $t2;


	$laufzeit = GetValueInteger($laufzeit_id);

	
	if ( $laeuft )
	   {
	   
		$start = GetValueString($start_id);
		$start = substr($start,3,2)."/".substr($start,0,2)."/".substr($start,8,2)." ".substr($start,11,8);
		
		$start = strtotime($start);
		$heute = getdate($start);
		$now = time();
		
		$diff = round(($now-$start)/60,0);
		SetValueInteger($laufzeit_id,$diff);
		}


		
		$ende = GetValueString($ende_id);
		
		
		if ( strlen($ende) > 0 and !$eingang and $laeuft)
		   {
		$ende = substr($ende,3,2)."/".substr($ende,0,2)."/".substr($ende,8,2)." ".substr($ende,11,8);

		$ende = strtotime($ende);
		$heute = getdate($ende);
		$now = time();

		$diff = round(($now-$ende)/60,0);
		//echo "\n$diff";
		
	if ( $diff >= 10 and !$eingang and $laeuft )
		{
		$now = date("d.m.Y H:i:s");

		SetValueBoolean($laeuft_id,$eingang);
		SetValueString($ende_id,$now);

      email_send($geraet,"Fertig um $now nach $laufzeit Minuten");
		}

		
		}
		
		

	
	}
	



?>