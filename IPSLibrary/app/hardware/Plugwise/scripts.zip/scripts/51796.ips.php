<?

 /*
*******************************
IP-SYMCON Event Scripting
*******************************
File : Display_Switch.ips.php
Trigger :
Interval :
*/
//Konstanten definieren
define ('XMAX',chr(240));
define ('YMAX',chr(128));
define ('ESC',chr(27));
define ('CR',chr(13));
define ('LF',chr(10));
define ('FF',chr(12));
define ('STH',chr(1));
define ('DC1',chr(17));
define ('DC2',chr(18));
define ('ACK',chr(6));
define ('NAK',chr(21));
define ('NEXTLINE',chr(124));
define ('NULL',chr(00));
define ('A',chr(65));
define ('B',chr(66));
define ('C',chr(67));
define ('D',chr(68));
define ('E',chr(69));
define ('F',chr(70));
define ('G',chr(71));
define ('H',chr(72));
define ('I',chr(73));
define ('J',chr(74));
define ('K',chr(75));
define ('L',chr(76));
define ('M',chr(77));
define ('N',chr(78));
define ('O',chr(79));
define ('P',chr(80));
define ('Q',chr(81));
define ('R',chr(82));
define ('S',chr(83));
define ('T',chr(84));
define ('U',chr(85));
define ('V',chr(86));
define ('W',chr(87));
define ('X',chr(88));
define ('Y',chr(89));
define ('Z',chr(90));
define ('GRAD',chr(248));
define ('PROZ',chr(37));
// Common eDip defines
//include_once("eDip_Global.ips.php");
// Variablen definieren
//include_once("Display.WZ_Global.ips.php");
// Display lschen und Hauptmenu-Button anzeigen
define (COM , 55153);

$datum = "1112";

COMPort_SendText(COM, "#AA1".CR);
COMPort_SendText(COM, "#DL".CR);  // Alle Pixel aus
//COMPort_SendText(COM, ESC.M.N.MnClrReturn2HauptMenu);
COMPort_SendText(COM, "#AZ2,3".CR);
COMPort_SendText(COM, "#AI1".CR);
COMPort_SendText(COM, "#ZL,8,2,".$datum.CR);
//COMPort_SendText(COM, ESC.Z.R.chr(230).chr(2).$Zeit.CR);
// Touchbutton anzeigen

//COMPort_SendText(COM, "#RR1,1,240,100,15".CR);
//COMPort_SendText(COM, "#AT1,1,24,10,1,2,test".NULL.CR);
COMPort_SendText(COM, "#BU1,100,10,50,50,0,10,0,5".CR);
COMPort_SendText(COM, "#BA1,5".CR);
COMPort_SendText(COM, "#AB1".CR);
//COMPort_SendText(COM, ESC.G.D.chr(50).chr(00).chr(50).chr(15).CR);
//COMPort_SendText(COM, ESC.Z.C.chr(120).chr(02)."Wohnzimmer:".CR);
//COMPort_SendText(COM, ESC.R.R.chr(00).chr(15).chr(240).chr(15).CR);
//COMPort_SendText(COM, ESC.G.D.chr(190).chr(00).chr(190).chr(15).CR);
// Button Deckenleuchte Strassenseite


	//SetValueString(53730, chr(27)."ZV". $Wochentag.chr(5));

// $string = chr(27)."DL" ;
// COMPort_SendText(55153,$string);
 
$string = "#ZL,10,11,JukeBox".chr(13) ;
$string = "#SV".chr(13);
 COMPort_SendText(55153 ,$string);
  

?>