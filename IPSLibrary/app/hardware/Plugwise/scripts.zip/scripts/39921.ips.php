<?
	// Wird aufgerufen wenn inputvariable edips sich aendern

	// I_EDIP7_INPUT

	require_once("DEF_INSTANCEN.ips.php");

	if ( isset($IPS_VARIABLE))  $c = $IPS_VARIABLE ;  else $c = "?";
	//IPS_LogMessage("Verwaltung.edip","$c");

	if ( $c == "?" ) return;
	if ( $c == I_EDIP7_INPUT ) $id = "EDIP7" ;
	if ( $c == I_EDIP8_INPUT ) $id = "EDIP8"  ;

	input_auswertung($id);
	

function input_auswertung($id)
	{
	
	$command = 0;
	$input = GetValueString( $id.".input");
	if ( $input[0] == chr(27) )
	if ( $input[1] == chr(65) )
	if ( $input[2] == chr(1)  )
		$command = ord($input[3]);


	if ( substr($input,0,5) == "MENU_")
	   {
	   $menu = intval(substr($input,5));
	   SetValueInteger($id.".MENU",$menu);
	   }
	
	if ( $command > 0 )
	   {
		SetValueInteger($id.".COMMAND",$command);
	   }



	//echo $command;
	switch ($command) {

		case 100:
    				//Reset Batterien
					SetValueInteger($id.".COMMAND.OLD",$command);
					SetValueInteger($id.".COMMAND",0);
    				$s  = IPS_GetScript(IPS_GetScriptID("Temperatur.ResetErrors"));
					require_once($s['ScriptFile']);
    				break;

		}
	


// **********************************************************
   $s  = IPS_GetScript(IPS_GetScriptID("edip_zyklisch"));
   require_once($s['ScriptFile']);

	}
	
	
?>