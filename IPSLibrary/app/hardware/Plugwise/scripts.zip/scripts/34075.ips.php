<?
		require_once(IPS_GetScriptID("Funcpool").".ips.php");

		$s = $heute = date("D M j G:i:s T Y");
		
		echo $s . " lebt";
	   
      email($s);



?>