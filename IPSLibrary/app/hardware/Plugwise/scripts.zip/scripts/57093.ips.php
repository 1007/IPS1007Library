<?

	require_once(IPS_GetScriptID("Funcpool").".ips.php");


	
	
	$id = 27149;
	$id_grabber = 22716;
	// fahre Position 1 an
	// http://192.168.10.18/decoder_control.cgi?user=admin&pwd=k7pmde&command=31

	WWWReader_RetrievePage($id,"http://192.168.10.18/decoder_control.cgi?user=admin&pwd=k7pmde&command=31");
	
	IPS_Sleep(3000);

	IG_UpdateImage($id_grabber);

	IPS_Sleep(1000);

   email("Es hat geklingelt.","C:\\Programme\\IP-SYMCON2\\cams\\22716.jpg");


?>