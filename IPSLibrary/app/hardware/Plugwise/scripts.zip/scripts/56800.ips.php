<?

//IPS_Sleep(3000);

slim_text("00:04:20:1e:92:31", "H", "I", 10);

slim_text("00:04:20:27:ae:ac", "H", "I", 0);

function slim_text($box , $text1 , $text2 , $time)
{
$TX_BUF = $box." display " .rawurlencode($text1)." ".rawurlencode($text2)." ".rawurlencode($time) .chr(10);

//$TX_BUF = $box." display "."Hello 1 20".chr(13);

//$TX_BUF = $box." show line1:Hello "."line2:Hello "."duration:20 "."centered:1 ".chr(10);


//Etwas �ber den COM Port senden
$result = CSCK_SendText(40623, $TX_BUF);
}


?>