<?

 	$instance =53848  ;
	$xbee_id = 2;
	$string = "";

	$command[0] = 149;
	$command[1] = 1;
	$command[2] = 100;

	
	for ( $x = 0 ; $x< sizeof($command) ; $x++)
	   {
	   $c = chr($command[$x]);
	   $string =  $string . $c   ;
	   }

	XBee_SendBuffer($instance,$xbee_id,$string);




?>