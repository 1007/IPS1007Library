<?

	require_once(IPS_GetScriptID("Funcpool").".ips.php");

	meldung("add","textttttttt",0,true);

	//meldung("removeall",0,"",0,true);

?>