<?

 //F�gen Sie hier ihren Skriptquellcode ein

   require_once("squeeze_func.ips.php");

 	$ScriptID = IPS_GetScriptID("FUNCPOOL");

   require_once("DEF_INSTANCEN.ips.php");
   require_once("FUNCPOOL.ips.php");

	//say("Mit atemberaubendem Tempo-Fu�ball");
   
   $Text = "Hallo. Batterie im zimmer ist leer";
   $dateiname = "test.";
	$pfad = IPS_GetKernelDir();
	$file = $pfad . "voicereader\\" . $dateiname ."mp3" ;
	unlink($file);
	
   IPS_ExecuteEx("C:/Programme/IP-Symcon2/voicereader/voicereader.exe","Save"." "."\"" .$Text. "\""." ".$dateiname,false,TRUE,0);

	$timeout = 80;
	while(true)
	   {
		if (file_exists($file))
	      break;
		IPS_Sleep(100);
		$timeout = $timeout - 1;
		if ( $timeout <= 0)
		   break;
		   
	   }
   
   echo $timeout;
   sleep(1);
   if (file_exists($file)) {
    print "The file $file exists";
} else {
    print "The file $filename does not exist";
}
	$playerid = "00:04:20:1e:92:31";
	$command = "$playerid play ?".chr(10);
	$command = "subscribe playlist newsong".chr(10);

	$command = "00:04:20:1e:92:31 playlist play file:///" . $file . "".chr(10);


	$result = squeeze($command);

   
   
?>