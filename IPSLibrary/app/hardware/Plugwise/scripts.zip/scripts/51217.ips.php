<?
	
 	include "52920.ips.php";               			// Include Roomba Funcpool


	reset_data();
	
   command(START,0);

	//go_test_1();
	
	//sleep(10);
	
	//go_test_2();

	//sleep(10);

	
	//go_clean();
	


	//reset_data();
	//startzeit();
	
	//endzeit();
	
	//laufzeit();
	
	return;
	


	go_wartung();

   sleep(10);
   
   go_home();
   
 	return;
 	
 	sleep(10);

   command(SAFE,0);
	command(START,0);
	command(SEEK_DOCK,0);


	 //command(SAFE,0);
 	
 	//command(SAFE,0);
	//command(SPOT,0);
	
	
   //command(SAFE,0);
	//sleep(10);
 	//command(SAFE,0);
	//command(SEEK_DOCK,0);

	return;
	 command(SAFE,0);
 	command(START,0);
 	command(SAFE,0);
 
 	
	//command(SAFE,0);
	//command(START,0);
	//go_wartung();
	

//	$song = decode(0,"Muppet:d=4,o=5,b=250:c6,c6,a,b,8a,b,g,p,c6,c6,a,8b,8a,8p,g.,p,e,e,g,f,8e,f,8c6,8c,8d,e,8e,8e,8p,8e,g,2p,c6,c6,a,b,8a,b,g,p,c6,c6,a,8b,a,g.,p,e,e,g,f,8e,f,8c6,8c,8d,e,8e,d,8d,c");


	$song = decode(0,"DasBoot:d=4,o=5,b=100:d#.4,8d4,8c4,8d4,8d#4,8g4,a#.4,8a4,8g4,8a4,8a#4,8d,2f.,p,f.4,8e4,8d4,8e4,8f4,8a4,c.,8b4,8a4,8b4,8c,8e,2g.,2p");

	$song0 = decode(0,"Flntstn:d=4,o=5,b=200:g#,c#,8p,c#6,8a#,g#,c#,8p,g#,8f#,8f,8f,8f#,8g#,c#,d#,2f,2p,g#,c#,8p,c#6,8a#,g#,c#,8p,g#,8f#,8f,8f,8f#,8g#,c#,d#,2c#");
	$song1 = decode(1,"YMCA:d=4,o=5,b=160:8c#6,8a#,2p,8a#,8g#,8f#,8g#,8a#,c#6,8a#,c#6,8d#6,8a#,2p,8a#,8g#,8f#,8g#,8a#,c#6,8a#,c#6,8d#6,8b,2p,8b,8a#,8g#,8a#,8b,d#6,8f#6,d#6,f.6,d#.6,c#.6,b.,a#,g#");
	$song0 = decode(0,"Muppet:d=4,o=5,b=250:c6,c6,a,b,8a,b,g,p,c6,c6,a,8b,8a,8p,g.,p,e,e,g,f,8e,f,8c6,8c,8d,e,8e,8e,8p,8e,g,2p,c6,c6,a,b,8a,b,g,p,c6,c6,a,8b,a,g.,p,e,e,g,f,8e,f,8c6,8c,8d,e,8e,d,8d,c");
	$song0 = decode(0,"BarbieGirl:d=4,o=5,b=125:8g#,8e,8g#,8c#6,a,p,8f#,8d#,8f#,8b,g#,8f#,8e,p,8e,8c#,f#,c#,p,8f#,8e,g#,f#");
	$song4 = decode(4,"Popcorn:d=4,o=5,b=112:8c6,8a#,8c6,8g,8d#,8g,c,8c6,8a#,8c6,8g,8d#,8g,c,8c6,8d6,8d#6,16c6,8d#6,16c6,8d#6,8d6,16a#,8d6,16a#,8d6,8c6,8a#,8g,8a#,c6");

	$song5 = decode(0,"Entertainer:d=4,o=5,b=140:8d,8d#,8e,c6,8e,c6,8e,2c.6,8c6,8d6,8d#6,8e6,8c6,8d6,e6,8b,d6,2c6,p,8d,8d#,8e,c6,8e,c6,8e,2c.6,8p,8a,8g,8f#,8a,8c6,e6,8d6,8c6,8a,2d6");
	//$song0 = decode(0,"DasBoot:d=4,o=5,b=100:d#.4,8d4,8c4,8d4,8d#4,8g4,a#.4,8a4,8g4,8a4,8a#4,8d,2f.,p,f.4,8e4,8d4,8e4,8f4,8a4,c.,8b4,8a4,8b4,8c,8e,2g.,2p");
	$song7 = decode(0,"aadams:d=4,o=5,b=160:8c,f,8a,f,8c,b4,2g,8f,e,8g,e,8e4,a4,2f,8c,f,8a,f,8c,b4,2g,8f,e,8c,d,8e,1f,8c,8d,8e,8f,1p,8d,8e,8f#,8g,1p,8d,8e,8f#,8g,p,8d,8e,8f#,8g,p,8c,8d,8e,8f");

	$song8 = decode(0,"Flntstn:d=4,o=5,b=200:g#,c#,8p,c#6,8a#,g#,c#,8p,g#,8f#,8f,8f,8f#,8g#,c#,d#,2f,2p,g#,c#,8p,c#6,8a#,g#,c#,8p,g#,8f#,8f,8f,8f#,8g#,c#,d#,2c#");

	$song9 = decode(0,"Imperial:d=4,o=5,b=200:e,e,e,8c,16p,16g,e,8c,16p,16g,e,p,b,b,b,8c6,16p,16g,d#,8c,16p,16g,e,8p");

   command(SAFE,0);
   command(SONG,$song7);         // Lied ueberspielen
   print_r($song0);
//   command(SONG,$song1);         // Lied ueberspielen
//   command(SONG,$song2);         // Lied ueberspielen
//   command(SONG,$song3);         // Lied ueberspielen
//   command(SONG,$song4);         // Lied ueberspielen

	//command(SONG,$song);
 	command(PLAY,array(0));   		// Melodie ausgeben

	return;
	sleep(10);                    // Warte bis Lied vorbei

	//exit;
	
	command(START,0);

	//return;
	
	command(START,0);
	
	go_wartung();
	
	exit;
	
	sleep (5);
	
	go_home();

function decode($nr,$s)
	{
	
	$song 	= array($nr,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	$s 		= str_replace(':',',',$s);
	$array 	= explode(',',$s);
	
	$titel 	= $array[0];
	$duration= intval(strrev($array[1]));
	$scale 	= intval(strrev($array[2]));
	$beats 	= $array[3];

	$beats = preg_replace('![^0-9]!','',$beats);
	$beats   = $beats/60;
	$counter = 2;
	
	for ( $x=4;$x<20;$x++ )
	   {
		$d = $duration;
		$s = $scale;
		$n = $array[$x];
		$b1 = intval($n);
		$s1 = intval(strrev($n));
		if ( $b1 > 0 ) $d = $b1;
		if ( $s1 > 0 ) $s = intval($s1);
   	$n1 = preg_replace('/[^A-Za-z#]*/','',strtoupper($n));
		$b1 = note($s,$n1);
		$song[$counter] = $b1;
		$counter++;
		$song[$counter] = intval($d*$beats);
		$counter++;
	   }

	return $song;
	}
	
function note($scale,$note)
	{

	$b = 0;

	if ( $note == "C" ) $b = 0;
	if ( $note == "C#" )$b = 1;
	if ( $note == "D" ) $b = 2;
	if ( $note == "D#" )$b = 3;
	if ( $note == "E" ) $b = 4;
	if ( $note == "F" ) $b = 5;
	if ( $note == "F#" )$b = 6;
	if ( $note == "G" ) $b = 7;
	if ( $note == "G#" )$b = 8;
	if ( $note == "A" ) $b = 9;
	if ( $note == "A#" )$b = 10;
	if ( $note == "B" ) $b = 11;

	$b = ($scale*12) + $b;

	if ( $note == "P" ) $b = 0;

	$b = intval($b);

	return $b;
	}

?>