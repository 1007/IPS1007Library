<?

   require_once IPS_GetScriptID("Funcpool.Profildefinitionen").".ips.php";
 	require_once IPS_GetScriptID("Funcpool.Raumdefinitionen").".ips.php";

 	$root_profile = IPS_GetObjectIDByName("PROFIL",IPS_GetObjectIDByName("DATEN",0));

	$debug = false;

	$heute = getdate();

	$akt_stunde   = $heute["hours"];
	$akt_minute   = $heute["minutes"];
	$akt_wochentag= $heute["wday"];
	$akt_tickcount= $heute[0];
	$akt_uhrzeit  = "$akt_stunde:$akt_minute";
	$akt_timecode = ($akt_stunde * 60 ) + $akt_minute;
	//Erster Wochenanfang seit UNIX-Epoche berechnen
	$x = (floor(($akt_tickcount + (86400*3) )/(60*60*24*7)))/2;
	if  ( floor($x) == $x)
		{ $akt_woche = 1; }
	else
		{ $akt_woche = 2; }

	if ( $debug ) echo "\nWoche:$akt_woche-$root_profile";



	profil_raum($root_profile,"BAD",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"TREPPE",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"FLUR",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"KUECHE",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"SCHLAF",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"WOHNEN",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"ARBEIT",$akt_woche,$akt_wochentag);
	profil_raum($root_profile,"AUSSEN",$akt_woche,$akt_wochentag);





function profil_raum($root_profile,$raum,$akt_woche,$akt_wochentag)
	{
	
	auto_profil($root_profile,$raum,$akt_woche,$akt_wochentag);
	
	}

//******************************************************************************
// fuellt alle Raumprofile die auf AUTO stehen mit dem erechneten Profil
//******************************************************************************
function auto_profil($root_instance,$raum,$akt_woche,$akt_wochentag)
	{
	$raum_instance = IPS_GetVariableIDByName("PROFIL.".$raum,$root_instance);
	$auto_instance = IPS_GetVariableIDByName("PROFIL.".$raum.".AUTOMATIK",$root_instance);

	$auto_alle_instance   = IPS_GetVariableIDByName("PROFIL.ALLE.AUTOMATIK",$root_instance);
	$profil_alle_instance = IPS_GetVariableIDByName("PROFIL.ALLE",$root_instance);


	$auto = GetValueBoolean($auto_instance);
	$auto_alle = GetValueBoolean($auto_alle_instance);

	if ( !$auto_alle )
		SetValueInteger($raum_instance,GetValueInteger($profil_alle_instance));
		
		
	if ($auto and $auto_alle)
	   {	
	   		// Wochenende
		if ( $akt_wochentag == 6 or $akt_wochentag == 0 )
		   {
			SetValueInteger($raum_instance,PROFIL_WOCHENENDE);
			}
		else
		   {
	   	if ( $akt_woche == 1 )
				{
				SetValueInteger($raum_instance,PROFIL_FRUEHSCHICHT);
				}
			if ( $akt_woche == 2 )
		   	{
				SetValueInteger($raum_instance,PROFIL_SPAETSCHICHT);
				}
			}
		}
	   
	//echo "\n$raum_instance - $auto_instance [$auto] ";
		
	}
	

?>