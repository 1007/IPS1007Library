<?

 	$debug = true;

	if ( $IPS_SENDER == 'Execute' ); $debug = true;

	$now     		=  time();

 	$root_licht = IPS_GetObjectIDByName("LICHT",0);
 	$array = IPS_GetChildrenIDs($root_licht);

	if (!isset($IPS_VARIABLE)) $IPS_VARIABLE=0 ;


	$id = $IPS_VARIABLE;
	echo $id;
   $parent = IPS_GetParent($id);
   echo $parent;



	// gehe alle Raeume durch
	foreach ( $array as $raum_instance )
	   {
	   $raum_name = IPS_GetName($raum_instance);
	   if ($debug)echo "\n[".$raum_instance."]". $raum_name;
	   $subarray = IPS_GetChildrenIDs($raum_instance);

		foreach ( $subarray as $object_instance )
	   	{
	   	$object_name = IPS_GetName($object_instance);
	   	//print_r(IPS_GetInstance($object_instance));
			if ($debug)echo "\n      +---------[" . $object_instance ."]". $object_name;
			
			$soll       = IPS_GetVariable(IPS_GetVariableIDByName("$object_name.STATUS.SOLL",$object_instance));
			$soll_value = $soll['VariableValue']['ValueBoolean'];
			$time       = GetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER.SOLL",$object_instance));
			$ist        = IPS_GetVariable(IPS_GetVariableIDByName("$object_name.STATUS",$object_instance));
			$ist_value  = $ist['VariableValue']['ValueBoolean'];
			$typ        = IPS_GetInstance($object_instance);
			$typ        = $typ['ModuleInfo']['ModuleName'];

			if ($debug)echo "\n                      +---------";
			//if ($debug)echo "[$diff]$soll_value";
			if ($debug)
				{
				echo "Soll[" ;
				if ( $soll_value ) $s = "EIN"; else $s = "AUS";
				echo $s;
				echo "]->Ist:[";
				if ( $ist_value ) $s = "EIN"; else $s = "AUS";
				echo $s;
				echo "]-->Timer[".$time."]";
				}


			//*********************************************************************
			// Timerwert soll gestartet werden
			//*********************************************************************
			if ( $time > 0 )
			   {
				if ( $debug )
					{
					echo "\n                                                        +---------";
					echo "-Timer starten-[" . $typ."]";
					}
				SetValueInteger(IPS_GetVariableIDByName("$object_name.TIMER.SOLL",$object_instance),0);
				FS20_SwitchDuration($object_instance, TRUE,$time);
			   }

			//*********************************************************************
			// kein Timerwert direkt ein oder aus schalten
			//*********************************************************************
			if ( $time == 0 )
				{
				if ( $debug )
					{
					echo "\n                                                        +---------";
					echo "-Kein Timer starten-[".$typ."]";
					}
					
				if ( $soll_value != $ist_value )
				   {
					//FS20_SwitchMode($object_instance,$soll_value);
					}


			   }

			}

	   }


?>