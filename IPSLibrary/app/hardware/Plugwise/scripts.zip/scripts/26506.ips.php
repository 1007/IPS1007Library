<?

	$archivID = @IPS_GetInstanceIDByName("Archive Handler", 0);


	$vars = AC_GetAggregationVariables($archivID,true);

	//print_r($vars);

	foreach($vars as $var)
		{
		$id = $var['VariableID'];
		$exists = IPS_VariableExists($id);
		
		if (! $exists )
		   {
 			echo "\n".$id." gibt es nicht";
			AC_DeleteVariableData($archivID,$id,0,time());

		   }
		}
?>