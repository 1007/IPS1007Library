<?
//********************************************************************************
// Temperatur.Sollwertberechnung.ips.php
//********************************************************************************

	$debug = false;

   $script = IPS_GetScriptID("Funcpool.Raumdefinitionen");
	require_once "$script.ips.php";

   $script = IPS_GetScriptID("Funcpool.Profildefinitionen");
	require_once "$script.ips.php";

   $script = IPS_GetScriptID("Temperatur.Sollwerte");
	require_once "$script.ips.php";


	$roottemp = IPS_GetObjectIDByName("TEMPERATUR",0);
	$rootdata = IPS_GetObjectIDByName("DATEN",0);

 	$root_status = IPS_GetObjectIDByName("STATUS",IPS_GetObjectIDByName("DATEN",0));
	$wach        = GetValueBoolean(IPS_GetObjectIDByName("STATUS.WACH",$root_status));
	$anwesend    = GetValueBoolean(IPS_GetObjectIDByName("STATUS.ANWESEND",$root_status));

	$absenkung = false;
	if ( !$wach  OR !$anwesend)
			$absenkung = true;
			

	soll($roottemp,$rootdata,"BAD",   $t_daten,$absenkung,$debug);
	soll($roottemp,$rootdata,"WOHNEN",$t_daten,$absenkung,$debug);
	soll($roottemp,$rootdata,"ARBEIT",$t_daten,$absenkung,$debug);






function soll ($roottemp,$rootdata,$raum,$t_daten,$absenkung,$debug)
	{

	$raum_instance   = IPS_GetObjectIDByName($raum,$roottemp);
	$status_instance = IPS_GetObjectIDByName("STATUS",$raum_instance);

	$profil_instance = IPS_GetObjectIDByName("PROFIL",$rootdata);
   $instance_profil = IPS_GetVariableIDByName ("PROFIL.$raum",$profil_instance);

	$instance_autotemp 	= IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR.AUTOMATIK",$status_instance);

	if ($debug) echo "\n$profil_instance -$instance_profil";


	$raumid = get_raum_id($raum);

	$soll = 0;

	$heute = getdate();

	$akt_stunde   = $heute["hours"];
	$akt_minute   = $heute["minutes"];
	$akt_uhrzeit  = "$akt_stunde:$akt_minute";
	$akt_timecode = ($akt_stunde * 60 ) + $akt_minute;

	if ($debug)echo "\n".$akt_timecode."-".$raumid ."Absenkung:".$absenkung;

	// aktuelles Profil fuer diesen Raum
	$akt_profil = GetValueInteger($instance_profil);
	if ($debug)echo "\nAkt Profil:$akt_profil";


	// Liste durchgehen
	foreach ($t_daten as $data)
		{

		$profile    = $data[0];
		$raum1       = $data[1];
		$uhrzeit    = $data[2];
		$temperatur = $data[3];
		$reserve1   = $data[4];
		$reserve2   = $data[5];

		if ( $akt_profil == $profile and $raumid == $raum1 )
			{
			if ($debug)echo "\n$profile-$raum-$uhrzeit-$temperatur";

			$timecode = (substr($uhrzeit,0,2) * 60 ) + substr($uhrzeit,3,2);
			if ( $timecode <= $akt_timecode)
				$soll = $temperatur;


			}
		}


	if ($debug)echo "\nSoll:$soll-$instance_autotemp";
	if ( $absenkung ) $soll = $soll - 2 ;
	if ($debug)echo "\nSoll:$soll-$instance_autotemp";

	// Wenn Solltemperatur == 0 dann kein Eintrag in Liste gefunden
	// aktuelle Werte dann nicht ueberschreiben !
	// auch bei aktuellem Profile 0 ( DEFAULT )

	if ( $soll <> 0 ) SetValueFloat($instance_autotemp,$soll);



	//echo "Raum:$raum -> Profil:$akt_profil -> Soll:$soll ";
	}


?>