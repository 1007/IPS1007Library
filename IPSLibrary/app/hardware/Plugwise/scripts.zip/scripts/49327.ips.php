<?
	IPSUtils_Include ("Plugwise_Configuration.inc.php","IPSLibrary::config::hardware::Plugwise");
	IPSUtils_Include("IPSInstaller.inc.php",    "IPSLibrary::install::IPSInstaller");
	IPSUtils_Include ("Plugwise_Configuration.inc.php","IPSLibrary::config::hardware::Plugwise");

	$CategoryIdApp = @get_ObjectIDByPath('Program.IPSLibrary.data.hardware.Plugwise.Circles',true);
	if ( !$CategoryIdApp ) return;
	

	$childs = IPS_GetChildrenIDs($CategoryIdApp);
	
	foreach ( $childs as $child )
	   {
	   $id = IPS_GetObjectIDByName("Leistung",$child);
		$x = rand(50,500);
		SetValue($id,$x);

	   $id = IPS_GetObjectIDByName("LastMessage",$child);
		SetValue($id,"1");

	   $id = IPS_GetObjectIDByName("Gesamtverbrauch",$child);
		$x = Getvalue($id);
		$x = $x + 1;
		SetValue($id,$x);


	   }


		$x = rand(5000,10000);

      SetValue(49998,$x);


?>