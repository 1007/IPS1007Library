<?

$mpServer = "localhost"; //anpassen!
$mpDB = "MpTvDb";
$mpDBUser = "root";
$mpDBPass = "k7pmde"; //Standard MP database password



$texts    = array(40557,
                  43757,
                  35240,
                  34595,
                  12464);
$problems = array(50068,
                  24393,
                  49579,
                  11535,
                  56782);

$handle = mysql_connect($mpServer, $mpDBUser, $mpDBPass)
    or die("Verbindung zur Mediaportal DB fehlgeschlagen" .  $myServer);

$selected = mysql_select_db($mpDB, $handle)
    or die("Kann Mediaportal DB nicht �ffnen" . $mpDB);

$schedules = mysql_query("SELECT name, startTime, endTime, programName, ".
                         "preRecordInterval, postRecordInterval ".
                         "FROM schedule INNER JOIN channel ".
                         "ON (schedule.idChannel = channel.idChannel) ".
                         "ORDER BY startTime ASC;");

$count = 0;
$lastEnd = 0;
$row = mysql_fetch_object($schedules);

print_r($row);

while($row && $count<5)
{
  $start = strtotime($row->startTime);
  $end   = strtotime($row->endTime);

  // Checke auf Ueberlappung
  if($lastEnd + 60*$row->preRecordInterval > $start)
  {
       SetValueBoolean($problems[$count], true);
       if($count!=0)
           SetValueBoolean($problems[$count-1], true);
  } else {
       SetValueBoolean($problems[$count], false);
  }
  $newLastEnd = $end + 60*$row->postRecordInterval;
  if($newLastEnd > $lastEnd)
  {
          $lastEnd = $newLastEnd;
  }

  // Baue den Text zusammen
  $text = GetDateTimeStr($start)."-".GetTimeStr($end)." ".
                         "[".$row->name."] ".$row->programName;
  SetValueString($texts[$count], $text);

  // Weiter mit der n�chsten Aufnahme
  $row = mysql_fetch_object($schedules);
  $count++;
}

// Wenn wir mehr als f�nf Aufnahmen haben checke �berlappung 5.-6. Aufnahme
if($row && count==5)
{
  $start = strtotime($row->startTime);
  if($lastEnd + 60*$row->preRecordInterval > $start)
  {
      SetValueBoolean($problems[4], true);
  }
}

// Wenn wir keine f�nf Aufnahmen haben, l�sche die Inhalte der �brigen Variablen
while($count<5)
{
  SetValueString($texts[$count], "");
  SetValueBoolean($problems[$count], false);
  $count++;
}

mysql_close($handle);

// ---------------------------------------------------------------------------



function GetDateTimeStr($date)
{
    return date("d.m. H:i", $date);
}

function GetTimeStr($date)
{
    return date("H:i", $date);
}


?>