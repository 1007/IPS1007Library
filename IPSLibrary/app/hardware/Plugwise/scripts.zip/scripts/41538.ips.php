<?

 // Raeume definieren
 
 
	define ("RAUM_BAD"   	, 1);
	define ("RAUM_WOHNEN"	, 2);
	define ("RAUM_ARBEIT"	, 3);
	define ("RAUM_SCHLAF"	, 4);
	define ("RAUM_TREPPE"	, 5);
	define ("RAUM_FLUR"		, 6);
	define ("RAUM_KUECHE"	, 7);
	define ("RAUM_WOHNEN1"	, 8);
	define ("RAUM_WOHNEN2"	, 9);
	define ("RAUM_AUSSEN"	, 10);


function get_raum_id($raum)
   {
   $id = 0;

   if ( $raum == "BAD" ) 		$id = RAUM_BAD;
   if ( $raum == "WOHNEN" ) 	$id = RAUM_WOHNEN;
   if ( $raum == "ARBEIT" ) 	$id = RAUM_ARBEIT;
   if ( $raum == "SCHLAF" ) 	$id = RAUM_SCHLAF;
   if ( $raum == "TREPPE" ) 	$id = RAUM_TREPPE;
   if ( $raum == "FLUR" ) 		$id = RAUM_FLUR;
   if ( $raum == "KUECHE" ) 	$id = RAUM_KUECHE;
   if ( $raum == "WOHNEN1" ) 	$id = RAUM_WOHNEN1;
   if ( $raum == "WOHNEN2" ) 	$id = RAUM_WOHNEN2;
   if ( $raum == "AUSSEN"  ) 	$id = RAUM_AUSSEN;

   return $id;
   }


function get_raum_string($raum)
   {
   $string = "";

   if ( $raum == RAUM_BAD ) 		$string = "BAD";
   if ( $raum == RAUM_WOHNEN ) 	$string = "WOHNEN";
   if ( $raum == RAUM_ARBEIT ) 	$string = "ARBEIT";
   if ( $raum == RAUM_SCHLAF ) 	$string = "SCHLAF";
   if ( $raum == RAUM_TREPPE ) 	$string = "TREPPE";
   if ( $raum == RAUM_FLUR ) 		$string = "FLUR";
   if ( $raum == RAUM_KUECHE ) 	$string = "KUECHE";
   if ( $raum == RAUM_WOHNEN1 ) 	$string = "WOHNEN1";
   if ( $raum == RAUM_WOHNEN2 ) 	$string = "WOHNEN2";
   if ( $raum == RAUM_AUSSEN  ) 	$string = "AUSSEN";

   return $string;
   }


?>