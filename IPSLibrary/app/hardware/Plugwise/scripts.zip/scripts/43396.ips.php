<?

//******************************************************************************
// 	wird alle Minute ausgefuehrt durch OB1
//******************************************************************************

  	require_once IPS_GetScriptID("Funcpool.IPSLogger").".ips.php";

	require_once(IPS_GetScriptID("Funcpool").".ips.php");
	require_once(IPS_GetScriptID("Iphone").".ips.php");

	$scriptname = IPS_GetName($IPS_SELF);

	$root = IPS_GetObjectIDByName("TEMPERATUR",0);
	$root_daten = IPS_GetObjectIDByName("DATEN",0);


	heizung_ein($root,"ARBEIT",false,$scriptname);
	heizung_ein($root,"WOHNEN",false,$scriptname);
	heizung_ein($root,"BAD"   ,false,$scriptname);

	heizung_fuehlerueberwachung($root,"ARBEIT","AUFLADUNG",false,$scriptname);
	heizung_fuehlerueberwachung($root,"WOHNEN","AUFLADUNG",false,$scriptname);

	heizung_fuehlerueberwachung($root,"AUSSEN","",false,$scriptname);
	heizung_fuehlerueberwachung($root,"BAD"	,"",false,$scriptname);
	heizung_fuehlerueberwachung($root,"TREPPE","",false,$scriptname);
	heizung_fuehlerueberwachung($root,"SCHLAF","",false,$scriptname);
	heizung_fuehlerueberwachung($root,"WOHNEN","",false,$scriptname);
	heizung_fuehlerueberwachung($root,"ARBEIT","",false,$scriptname);

	heizung_aufladung($root,$root_daten,"ARBEIT",false,0,$scriptname);
	heizung_aufladung($root,$root_daten,"WOHNEN",false,0,$scriptname);




function heizung_aufladung($root,$root_daten,$raum,$debug,$offset,$scriptname)
	{

	$debug = true;

	$now = getdate();

	$akt_stunde    = $now["hours"];
	$akt_minute    = $now["minutes"];
	$akt_wochentag = $now["wday"];
	$minuten = ($akt_stunde*60)+$akt_minute;

	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN",$root);
	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN.TF",$aussen_instance);
	$aussen_instance   = IPS_GetObjectIDByName("AUSSEN.TF.TEMPERATUR",$aussen_instance);

	$raum_instance     = IPS_GetObjectIDByName($raum,$root);
	$status_instance   = IPS_GetObjectIDByName("STATUS",$raum_instance);
	$stufe_instance    = IPS_GetVariableIDByName($raum.".AUFLADUNG.STUFE",$status_instance);
   $fuehler_instance  = IPS_GetInstanceIDByName($raum.".AUFLADUNG.TF",$raum_instance);
	$temp_instance     = IPS_GetVariableIDByName($raum.".AUFLADUNG.TF.TEMPERATUR",$fuehler_instance);
	$leer_instance     = IPS_GetVariableIDByName($raum.".AUFLADUNG.LEER",$status_instance);
	$steuerung_instance= IPS_GetVariableIDByName($raum.".AUFLADUNG.STEUERUNG.EIN",$status_instance);

   $ein_instance  	 = IPS_GetInstanceIDByName($raum.".AUFLADUNG.EIN",$raum_instance);

	$aussen_temperatur = GetValueFloat($aussen_instance);
	$ofen_temperatur   = GetValueFloat($temp_instance);
	$steuerung_ein     = GetValueBoolean($steuerung_instance);


	$on = false;
	$refresh = false;

	$soll_minute = 271;
	if ( $aussen_temperatur < 15 ) $soll_minute = 241 ;
	if ( $aussen_temperatur < 10 ) $soll_minute = 181 ;
	if ( $aussen_temperatur <  5 ) $soll_minute = 121 ;
	if ( $aussen_temperatur <  0 ) $soll_minute =  61 ;
	if ( $aussen_temperatur < -5 ) $soll_minute =   1 ;

	//echo "\nAktuelle Stunde:$akt_stunde-$akt_minute = $minuten#$soll_minute [ $aussen_temperatur ]";


	if ( $steuerung_ein )
	   { 
		// Jede Stunde einschalten
		if ( $akt_stunde <= 8 and $akt_minute == 0 and $minuten > $soll_minute )
			{ $on = true; $refresh = true; echo "\nSteuerung ein " . $raum;}
		// Zur errechneten Zeit einschalten
		if ( $akt_stunde <= 8 and $minuten == $soll_minute )
			{ $on = true; $refresh = true; echo "\nSteuerung ein " . $raum;}
		}

	// Nach 11 Uhr Mittags immer ausschalten ( jede Stunde )
	if ( $akt_stunde >= 11 and $akt_minute == 0 ){ $on = false; $refresh = true; }


	if ( $refresh )
		{
		FS20_SwitchMode($ein_instance, $on );
	   //echo "ON [$on]";
	   }


	// Ofentemp 35 bedeutet leer
	$leer = false;
	if ( $ofen_temperatur < 30 ) $leer = true;

	if ( !GetValueBoolean($leer_instance) and $leer )
	   {
	   $text = "Ofen leer " . $raum;
		//email("Nachricht von Sam",$text);
		ipslog("ERROR",$scriptname,$text);
	   }
	   
	SetValueBoolean($leer_instance,$leer);




	}



function heizung_fuehlerueberwachung($root,$raum,$aufladung,$debug,$scriptname)
	{

	//$debug = true;
	
	if ( $aufladung == "" ) $fuehlerstring = $raum .".TF";
	if ( $aufladung == "AUFLADUNG" ) $fuehlerstring = $raum .".AUFLADUNG.TF";

	$raum_instance     = IPS_GetObjectIDByName($raum,$root);
	$status_instance   = IPS_GetObjectIDByName("STATUS",$raum_instance);
	$fuehler_instance  = IPS_GetInstanceIDByName($fuehlerstring,$raum_instance);
	$error_instance 	 = IPS_GetVariableIDByName($fuehlerstring.".ERROR",$status_instance);
	$bat_instance      = IPS_GetVariableIDByName($fuehlerstring.".TEMPERATUR",$fuehler_instance);

	if($debug) echo "\nFuehlerueberwachung: $root - $raum_instance - $fuehler_instance";

   $t1 = time() / 60;    // aktuelle Zeit in Minuten

   $array = IPS_GetVariable($bat_instance);

   $t2 = $array["VariableUpdated"]/60;
	$diff = $t1 - $t2;

	if ( $debug ) echo "\n$fuehler_instance: $t1 - $t2 =$diff";

   if (($t1 - $t2) > 30)
      {
      $string = "TF $raum ausgefallen";
		if ( 	GetValueBoolean($error_instance)  == false )
      	{
         email($string);
			}
      SetValueBoolean($error_instance , true);
      if ( $debug ) echo "\n$string";
      IPS_LogMessage("Heizungssteuerung: ",$string);

      }
	else
	   {
	   SetValueBoolean($error_instance , false);
		}

	}



function heizung_ein($root,$raum,$debug,$scriptname)
	{

	$now     		=  time();

	$debug = false;


	$raum_instance   = IPS_GetObjectIDByName($raum,$root);
	$status_instance = IPS_GetObjectIDByName("STATUS",$raum_instance);





	$instance_ausgang    =  IPS_GetInstanceIDByName ("$raum.HEIZUNG.EIN",$raum_instance);
	$instance_control    =  IPS_GetInstanceIDByName ("$raum.HEIZUNG.CONTROL",$raum_instance);
	$instance_ein 	      = 	IPS_GetVariableIDByName ("$raum.HEIZUNG.CONTROL.EIN",$instance_control);

	$instance_solltemp   = IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR",$status_instance);
	$instance_soll			= IPS_GetVariableIDByName ("$raum.HEIZUNG.CONTROL.SOLL",$instance_control);
	$instance_autotemp 	= IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR.AUTOMATIK",$status_instance);
	$instance_handtemp 	= IPS_GetVariableIDByName ("$raum.HEIZUNG.SOLLTEMPERATUR.HAND",$status_instance);
	$instance_auto    	= IPS_GetVariableIDByName ("$raum.HEIZUNG.AUTOMATIK",$status_instance);



	// Automatik oder Handtemperaturen
	$handtemp = GetValueFloat($instance_handtemp);
	$autotemp = GetValueFloat($instance_autotemp);
	$auto     = GetValueBoolean($instance_auto);


	// Handeinstellung nur fuer x Minuten
	$array = IPS_GetVariable($instance_auto);
	$diff = $now  - $array['VariableUpdated'];
	//echo "\nDiff=$diff";
	if ( !$auto and $diff > 3600)
	   {
	   $auto = true;
		//echo "\n$raum-$diff";

	   echo "\nHandeinstellungszeit ist abgelaufen";
	   SetValueBoolean($instance_auto,$auto);
	   }




	$soll = GetValueFloat($instance_handtemp);
	if ( $auto)  $soll = GetValueFloat($instance_autotemp);

	SetValueFloat($instance_solltemp,$soll);

	if ($debug) echo "\n$raum-$instance_control: [$auto] Hand:$handtemp - Auto:$autotemp - SollControl:$soll";

	$i = 99;
	
	
	
	$i = HC_TargetValue($instance_control,$soll);


	// Heizung einschalten
	if ( GetValueBoolean($instance_ein) == TRUE )
   	{
      FS20_SwitchDuration($instance_ausgang, TRUE,100);
		//if ($debug) echo "\nEin";
		}




	}




?>