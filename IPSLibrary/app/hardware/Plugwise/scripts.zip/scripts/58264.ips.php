<?
//***************************************************
// ausfuehren an jedem Monatsbeginn
//***************************************************


	strom_copy_monat();



function strom_copy_monat()
	{
	
   $root_daten  	= IPS_GetObjectIDByName("STROM",IPS_GetObjectIDByName("DATEN",0));
   $root_monat    = IPS_GetObjectIDByName("MONAT",$root_daten);
   $root_monat_m1 = IPS_GetObjectIDByName("MONAT-1",$root_daten);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Gesamt",$root_monat),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Hochtarif",$root_monat),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Kosten_Niedertarif",$root_monat),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Hochtarif",$root_monat),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Niedertarif",$root_monat),0);

	$data = GetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_monat));
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_monat_m1),$data);
	SetValueFloat(IPS_GetVariableIDByName("Verbrauch_Gesamt",$root_monat),0);

	$data = GetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_monat));
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_monat_m1),$data);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Niedertarif",$root_monat),0);

	$data = GetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_monat));
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_monat_m1),$data);
	SetValueInteger(IPS_GetVariableIDByName("Impulse_Hochtarif",$root_monat),0);


	}
	
 

?>