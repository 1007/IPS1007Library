<?

$sqc = 25941;
$no1box = "00:04:20:1e:92:31";





//TTS_GenerateFile(38365,"Ofentemperatur zu nie drig","c:/test.wav",0);

   $Text = "Ofentemperatur zu nie drig";
   $dateiname = "test.";
   IPS_ExecuteEx("C:/Programme/IP-Symcon2/voicereader/voicereader.exe","Save"." "."\"" .$Text. "\""." ".$dateiname,false,TRUE,0);

	$pfad = "C:/Programme/IP-SYMCON2/VoiceReader/";

	$meldung = $pfad . $dateiname ."mp3";
	
	echo $meldung;
	$titel = rawurlencode($meldung);

	CSCK_SendText($sqc, $no1box.' playlist play '.$titel.chr(13));

//slim_text("00:04:20:1e:92:31", "Temperatur im Wohnzimmer:", 20, 20);

function slim_text($box , $text1 , $text2 , $time)
{
$TX_BUF = $box." display " .rawurlencode($text1)." ".rawurlencode($text2.chr(186).chr(67))." ".$time.chr(13);
//Etwas �ber den COM Port senden
$result = CSCK_SendText(25941, $TX_BUF);
}

?>