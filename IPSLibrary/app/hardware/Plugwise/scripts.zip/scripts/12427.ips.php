<?


	$f1 = 1.12345678901234567890;
	$f1= round($f1,14);
	
	echo "\n[".$f1."]";

	SetValueString(39944,$f1);

	
	$s = GetValueString(39944);
	echo "\n[".$s."]" .strlen($s);

	$s = strtr ( $s, ',', '.' );
	echo "\n[".$s."]" .strlen($s);

	

	$f2 = floatval($s);
	echo "\n[".$f2."]";

	if ( $f1 == $f2 )
	   {
	   echo "\nbeide gleich";
	   $diff = $f2-$f1;
	   echo "\nDiff:".$diff."]";
		}
	else
		{
		echo "\nbeide ungleich";
		$diff = $f2-$f1;
		echo "\nDiff:[".$diff."]";
		}
		
	
?>