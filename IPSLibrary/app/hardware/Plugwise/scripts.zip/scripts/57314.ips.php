<?
  GLOBAL $CircleGroups;


	if (!isset($moduleManager)) {
		IPSUtils_Include ('IPSModuleManager.class.php', 'IPSLibrary::install::IPSModuleManager');

		
		$moduleManager = new IPSModuleManager('Plugwise');
	}

  $moduleManager->VersionHandler()->CheckModuleVersion('IPS','2.50');
	$moduleManager->VersionHandler()->CheckModuleVersion('IPSModuleManager','2.50.1');
  $moduleManager->VersionHandler()->SetModuleVersion("1.0.0");

  IPSUtils_Include ("IPSInstaller.inc.php",                "IPSLibrary::install::IPSInstaller");
	IPSUtils_Include ("IPSMessageHandler.class.php",         "IPSLibrary::app::core::IPSMessageHandler");
	IPSUtils_Include ("Plugwise_Configuration.inc.php",      "IPSLibrary::config::hardware::Plugwise");
	IPSUtils_Include ("Plugwise_Include.ips.php",      "IPSLibrary::app::hardware::Plugwise");

	$AppPath        = "Program.IPSLibrary.app.hardware.Plugwise";
	$DataPath       = "Program.IPSLibrary.data.hardware.Plugwise";
	$ConfigPath     = "Program.IPSLibrary.config.hardware.Plugwise";
	$VisuPath       = "Visualization.WebFront.Hardware.Plugwise";
	$MobilePath     = "Visualization.Mobile.Hardware.Plugwise";
  $HardwarePath   = "Hardware.Plugwise";
	$CircleDataPath = "Program.IPSLibrary.data.hardware.Plugwise.Circles";

  $CategoryIdData   = CreateCategoryPath($DataPath);
	$CategoryIdApp    = CreateCategoryPath($AppPath);
	$CategoryIdVisu   = CreateCategoryPath($VisuPath);
	$CategoryIdMobile = CreateCategoryPath($MobilePath,100);
	$CategoryIdHw     = CreateCategoryPath($HardwarePath);
  $CategoryIdCData  = CreateCategoryPath($CircleDataPath);




 	echo "\n--- Create Webfront -----------------------------------------------\n";
  $WFC_Enabled        = $moduleManager->GetConfigValue('Enabled', 		 'WFC10');
  $WFC_Path           = $moduleManager->GetConfigValue('Path', 			   'WFC10');
  $WFC_WebFrontID     = $moduleManager->GetConfigValueInt('WebFrontID','WFC10');
  $WFC_TabPaneParent  = $moduleManager->GetConfigValue('TabParent', 	 'WFC10');
  $WFC_TabPaneName    = $moduleManager->GetConfigValue('TabName', 		 'WFC10');
  $WFC_TabPaneItem    = $moduleManager->GetConfigValue('TabItem', 		 'WFC10');
  $WFC_TabPaneIcon    = $moduleManager->GetConfigValue('TabIcon', 		 'WFC10');
  $WFC_TabPaneOrder   = $moduleManager->GetConfigValueInt('TabOrder',  'WFC10');
  $WFC_ConfigId       = $moduleManager->GetConfigValueIntDef('ID', 	   'WFC10', GetWFCIdDefault());
	if ( $WFC_WebFrontID > 0 )
      $WFC_ConfigId = $WFC_WebFrontID;

  $ItemList = WFC_GetItems($WFC_ConfigId);
	foreach ($ItemList as $Item)
    {
    $pos = strpos($Item['ID'], $WFC_TabPaneItem);
    if ($pos === false)
	 	 {//echo "\nNicht gefunden".$Item['ID'];
		  }
	 else
	 	{	DeleteWFCItem($WFC_ConfigId, $Item['ID']);
		}
	 }

	if ($WFC_Enabled)
	{
    
   $VisuID_menu  = CreateCategory("MENU",$CategoryIdVisu,10);
   $VisuID_data1 = CreateCategory("DATA1",$CategoryIdVisu,10);
   $VisuID_data2 = CreateCategory("DATA2",$CategoryIdVisu,10);

   $IDGroups    = CreateDummyInstance("Gruppen",$VisuID_menu,10);
	$IDCircles   = CreateDummyInstance("Circles",$VisuID_menu,20);

	CreateWFCItemSplitPane ($WFC_ConfigId, $WFC_TabPaneItem, $WFC_TabPaneParent , 20 , $WFC_TabPaneName   , ''  , 1 /*Horizontal*/, 30 /*Width*/, 0 /*Target=Pane1*/, 0 /*UsePercentage*/, 'true');
	CreateWFCItemCategory  ($WFC_ConfigId, $WFC_TabPaneItem."-MENU", $WFC_TabPaneItem, 10, "Titel", $Icon="", $VisuID_menu, $BarBottomVisible='true' , $BarColums=9, $BarSteps=5, $PercentageSlider='true');

	CreateWFCItemSplitPane ($WFC_ConfigId, $WFC_TabPaneItem."-SPLITDATA", $WFC_TabPaneItem , 20 , $WFC_TabPaneName   , ''  , 0 , 50 /*Width*/, 0 /*Target=Pane1*/, 0 /*UsePercentage*/, 'true');
	CreateWFCItemSplitPane ($WFC_ConfigId, $WFC_TabPaneItem."-SPLITDATA1", $WFC_TabPaneItem."-SPLITDATA" , 20 , $WFC_TabPaneName   , ''  , 1 , 50 /*Width*/, 0 /*Target=Pane1*/, 0 /*UsePercentage*/, 'true');
	CreateWFCItemCategory  ($WFC_ConfigId, $WFC_TabPaneItem."-DATA1", $WFC_TabPaneItem."-SPLITDATA1", 30, "Titel", $Icon="", $VisuID_data1, $BarBottomVisible='true' , $BarColums=9, $BarSteps=5, $PercentageSlider='true');
	CreateWFCItemCategory  ($WFC_ConfigId, $WFC_TabPaneItem."-DATA2", $WFC_TabPaneItem."-SPLITDATA1", 40, "Titel", $Icon="", $VisuID_data2, $BarBottomVisible='true' , $BarColums=9, $BarSteps=5, $PercentageSlider='true');


	CreateProfile_Associations ("Plugwise_MenuItem", array(
												0	=> "",
												1 	=> "����"
												),
												'', array(
												0  =>	0x666666,
												1  =>	0x99FFCC
												));


  $ActionScriptId = IPS_GetScriptIDByName('Plugwise_Webfront', $CategoryIdApp );

	//***************************************************************************
	// Gruppenmenu erstellen
	//***************************************************************************
	$groups = $CircleGroups[2];
	$groups = array_unique($groups);
   $array = array();
   foreach ( $CircleGroups as $group ) array_push($array,$group[2]);
   $groups = array_unique($array);
	$x = 10;
   foreach ( $groups as $group )
   	{
      if ( $group != "" )
      	{
         $id = CreateVariable($group, 1, $IDGroups, 0, "Plugwise_MenuItem", $ActionScriptId, false);
         $x = $x + 10;
         }
      }

	//***************************************************************************
	// Circlesmenu erstellen
	//***************************************************************************
	$x = 10;
	foreach ( $CircleGroups as $circle )
		{
		if ( $circle[1] != "" )
		   {
         $id = CreateVariable($circle[1], 1, $IDCircles, 0, "Plugwise_MenuItem", $ActionScriptId, false);
         IPS_SetInfo($id,$circle[0]);
			IPS_SetHidden($id,true);
         $x = $x + 10;
		   }
		}

	//***************************************************************************
	// Scriptlinks erstellen
	//***************************************************************************
		$ScriptId = IPS_GetScriptIDByName('Plugwise_Recalibrate', $CategoryIdApp );
      $id = CreateLink("Kalibrierung starten",$ScriptId,$VisuID_data1,10);
      IPS_SetInfo($id,"Script");
		$ScriptId = IPS_GetScriptIDByName('Plugwise_Circlesearch', $CategoryIdApp );
      $id = CreateLink("Circlesuche starten",$ScriptId,$VisuID_data1,20);
      IPS_SetInfo($id,"Script");
		$ScriptId = IPS_GetScriptIDByName('Plugwise_ReadTime', $CategoryIdApp );
      $id = CreateLink("Circlezeit auslesen",$ScriptId,$VisuID_data1,30);
      IPS_SetInfo($id,"Script");
		$ScriptId = IPS_GetScriptIDByName('Plugwise_SetTime', $CategoryIdApp );
      $id = CreateLink("Circlezeit setzen",$ScriptId,$VisuID_data1,40);
      IPS_SetInfo($id,"Script");
		$ScriptId = IPS_GetScriptIDByName('Plugwise_ReadBuffer', $CategoryIdApp );
      $id = CreateLink("Circlebuffer lesen",$ScriptId,$VisuID_data1,50);
      IPS_SetInfo($id,"Script");

		$ScriptId = IPS_GetScriptIDByName('Plugwise_IPSModulupdaten', $CategoryIdApp );
      $id = CreateLink("Plugwise Onlineupdate",$ScriptId,$VisuID_data2,50);
      IPS_SetInfo($id,"Script");

	//***************************************************************************
	// HTMLCircledaten linken
	//***************************************************************************
	$x = 100;
	foreach ( $CircleGroups as $circle )
		{
		if ( $circle[1] != "" )
		   {
			echo "\n". $circle[0]."-".$CategoryIdCData;
         $parent = @IPS_GetObjectIDByName($circle[0],$CategoryIdCData);
			if ( $parent )
			   {
			   $id = @IPS_GetObjectIDByName("WebData1",$parent);
			   if ( $id )
			      {
      			$id = CreateLink($circle[1],$id,$VisuID_data1,$x);
					IPS_SetHidden($id , true );
					IPS_SetInfo($id,$circle[0]);
      			$x = $x + 10;
			      }
			   $id = IPS_GetObjectIDByName("Status",$parent);
			   if ( $id )
			      {
      			$id = CreateLink($circle[1]." Status",$id,$VisuID_data1,$x+200);
					IPS_SetHidden($id , true );
					IPS_SetInfo($id,$circle[0]);
			      }

			   $id = @IPS_GetObjectIDByName("WebData2",$parent);
			   if ( $id )
			      {
      			$id = CreateLink($circle[1],$id,$VisuID_data2,$x);
					IPS_SetHidden($id , true );
					IPS_SetInfo($id,$circle[0]);
      			$x = $x + 10;
			      }

			   }
			}
		}




    }



  ReloadAllWebFronts() ;


?>